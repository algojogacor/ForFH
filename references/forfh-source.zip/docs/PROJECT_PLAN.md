# PROJECT PLAN

## Goal
Build a production-oriented web/PWA “College OS” that reduces academic cognitive load and keeps all user-owned data isolated.

## Current database decision
Development uses a project-local SQLite database only (`./data/forfh.sqlite` by default). Turso is intentionally not used for ForFH because the supplied Turso database belongs to another project.

## Phases
- [x] A — Foundation source architecture, config, schema, docs
- [x] B — Credential auth/session/rate limiting architecture
- [x] C — Academic terms, courses, recurring weekly schedules
- [x] D — Tasks, subtasks, priority/status/progress/reminders
- [x] E — Dashboard and calendar/agenda domain
- [x] F — Notes, search, Quick Capture UI foundation
- [x] G — Provider-independent AI router and AI features
- [x] H — Web Push + QStash reminder worker
- [x] I — Central Google Drive integration + quota/ownership
- [x] J — PWA, service worker, IndexedDB/outbox
- [x] K — Pasal.id legal search/bookmarks + grounded AI endpoint
- [x] L — Readings, exams, attendance, grades baseline APIs/UI

## Non-goals
No native Android, exact Android alarms, home-screen widgets, group chat, payments, citation manager, Zotero clone, or unnecessary microservices.
