# FUTURE ANDROID

The current product is a web/PWA. It intentionally does **not** fake native Android capabilities.

Planned class at 10:00 native reminder sequence:
- 06:00 — exact/high-priority alarm
- 08:00 — light reminder
- 08:30 — light reminder
- 09:00 — light reminder
- 09:30 — light reminder
- 09:40 — light reminder

Later Android implementation should evaluate AlarmManager, exact-alarm permission, notification channels, legitimate full-screen intent usage, ringtone, vibration, snooze and dismiss.

Planned widgets:
- NEXT CLASS
- TODAY
- TASKS
- LARGE DASHBOARD

The backend APIs and domain services are kept outside React UI so a native client can reuse them.
