# BUILD STATUS

## Implemented in source
- [x] Phase A — Foundation
- [x] Phase B — Auth architecture
- [x] Phase C — Academic core
- [x] Phase D — Task core
- [x] Phase E — Dashboard/calendar
- [x] Phase F — Notes/search/quick capture
- [x] Phase G — AI routing
- [x] Phase H — Push/reminders
- [x] Phase I — Drive storage
- [x] Phase J — PWA/offline
- [x] Phase K — Legal
- [x] Phase L — Secondary academic baseline

## Database override
- [x] ForFH does not use Turso/libSQL remote database credentials.
- [x] Local SQLite uses Node `node:sqlite` + Drizzle.
- [x] `DB_FILE_NAME` defaults to `./data/forfh.sqlite`.
- [x] SQLite database/WAL/SHM files are git-ignored.
- [x] `npm run db:verify:local` checks required tables and SQLite integrity.

## Offline/PWA hardening
- [x] Installable manifest and service worker shell.
- [x] IndexedDB mutation outbox for core task/note mutations.
- [x] Automatic replay on reconnect plus visible pending-sync state.
- [x] Offline outbox is scoped by authenticated user ID to prevent cross-user replay.
- [x] Quick Capture manual save can queue offline.

## Test coverage added
- [x] Deterministic task overdue/progress tests.
- [x] Asia/Jakarta timezone conversion tests.
- [x] Username normalization tests.
- [x] Cross-user task/note authorization integration tests.
- [x] Cross-user course relationship rejection tests.

## Quality checks completed in this sandbox
- [x] Local SQLite integrity check passes.
- [x] Source audit passes with no Turso/libSQL runtime dependency/reference.
- [x] `@/` source import paths resolve to existing project files.
- [x] Non-TSX TypeScript/ESM parser checks pass with the installed Node runtime.
- [ ] npm dependency installation (sandbox package registry returns 404 for public packages such as Next.js).
- [ ] full `tsc`, ESLint, Vitest and `next build` (blocked here until dependencies can be installed).

Run `npm install && npm run quality` in a normal npm-enabled development/CI environment before deployment.
