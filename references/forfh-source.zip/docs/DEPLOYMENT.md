# DEPLOYMENT

1. Add all required environment variables in Vercel. Keep server secrets server-only.
2. For local development, use SQLite via `DB_FILE_NAME` (default `./data/forfh.sqlite`) and run the local migrations. Do not configure or connect this project to Turso.
3. Before production deployment, choose a separate persistent database/storage strategy that is compatible with the hosting environment; do not reuse another project's database credentials.
4. Generate VAPID/security secrets once; do not rotate them casually without planning session/push impact.
5. Deploy to Vercel and set `NEXT_PUBLIC_APP_URL` to the canonical HTTPS URL.
6. Run the QStash bootstrap script once to create the five-minute schedule.
7. Enable browser notifications from the Settings/onboarding explanation flow.
8. Google Drive uses one administrator account and OAuth refresh token; end users do not connect Drive.
9. Use `/api/health/public` for non-sensitive status; keep the internal diagnostic endpoint protected.

Before production: `npm run quality`.
