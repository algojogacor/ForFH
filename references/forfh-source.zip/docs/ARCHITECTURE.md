# ARCHITECTURE

## Runtime
A single Next.js App Router application targets Vercel Node.js runtime. Route Handlers expose reusable HTTP APIs suitable for the current PWA and a future native Android client.

## Boundaries
- `src/lib/auth`: password/session/rate limit and authorization
- `src/lib/db`: local SQLite (`node:sqlite`)/Drizzle schema and database client
- `src/lib/services`: user-scoped domain services
- `src/lib/ai`: provider-independent model routing
- `src/lib/google-drive`: OAuth, folders, uploads, ownership
- `src/lib/notifications`: Web Push and reminder calculations
- `src/lib/pasal`: Indonesian legal API proxy client
- `src/lib/offline`: browser IndexedDB outbox/cache helpers

## Security model
Every user-owned read/update/delete is constrained by both entity ID and authenticated `user_id`. Browser-supplied user IDs are ignored. Session cookies hold only a high-entropy raw token; SQLite stores its SHA-256 hash.

## Serverless design
No long-running process is required. QStash calls one signed worker endpoint every five minutes. AI providers are called only for language/planning features; deterministic calculations stay in code.
