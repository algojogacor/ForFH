# AI ROUTING

Provider order:
1. Healthy Groq slot (round-robin slot 1/2)
2. Other healthy Groq slot
3. Healthy Ollama Cloud slot
4. Other healthy Ollama Cloud slot
5. Ollama last-resort model
6. Controlled “AI unavailable” response

Rules:
- Technical failures (429, timeout, network, 5xx, temporary unavailable) trigger provider fallback.
- 429 honors `Retry-After` when available and places the slot in cooldown.
- Structured data is always validated by Zod.
- Groq uses JSON Schema mode for supported workloads.
- Ollama strict JSON gets one repair attempt.
- No raw prompt bodies or API keys are written to `ai_usage`.
- Retrieved notes/files/law snippets are explicitly treated as untrusted data, not instructions.
