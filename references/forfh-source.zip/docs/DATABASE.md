# DATABASE

## Current development database
ForFH currently uses a project-local SQLite database only. The default path is:

`./data/forfh.sqlite`

The path can be changed with `DB_FILE_NAME`. The server opens SQLite through Node's built-in `node:sqlite` driver and Drizzle ORM. Foreign keys, WAL journal mode, and a busy timeout are enabled when the application opens the database.

## Important isolation decision
Do not configure this project with the Turso credentials from the original pasted specification. Those credentials belong to a different project. ForFH must not connect to that database during this development phase.

A future production database can be selected later behind the database/service boundary without reusing the other project's credentials.

## Local commands
- `npm run db:init:local` — apply the checked-in initial SQL migration using Node's SQLite driver.
- `npm run db:verify:local` — check required tables and `PRAGMA integrity_check`.
- `npm run setup:local` — generate missing local secrets and initialize SQLite.

Database files and their `-wal` / `-shm` companions are ignored by Git.

## Ownership rule
Every user-owned table carries `user_id`. Service queries for user data constrain both the entity ID and authenticated user ID. Cross-user ownership behavior is covered by integration tests in `tests/authorization.integration.test.ts`.
