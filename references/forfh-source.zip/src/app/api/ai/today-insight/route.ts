import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { consumeRateLimit, requestIpHashKey } from "@/lib/auth/rate-limit";
import { generateStructured } from "@/lib/ai/router";
import { todayInsightJsonSchema, todayInsightSchema } from "@/lib/ai/schemas";
import { DATA_SAFETY } from "@/lib/ai/prompts/base";
import { getDashboard } from "@/lib/services/dashboard";
import { AppError } from "@/lib/errors";
import { jsonError } from "@/lib/http";

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const rate = await consumeRateLimit(requestIpHashKey(request, "ai-today", user.id), { max: 12, windowMs: 60 * 60_000, blockMs: 15 * 60_000 });
    if (!rate.allowed) throw new AppError("RATE_LIMITED", "Saran AI terlalu sering diminta. Coba lagi nanti.", 429);
    const dashboard = await getDashboard(user.id);
    const facts = {
      nextClass: dashboard.nextClass ? { courseName: dashboard.nextClass.courseName, occurrence: dashboard.nextClass.occurrence?.toISOString(), room: dashboard.nextClass.room } : null,
      todayTasks: dashboard.todayTasks.map((task) => ({ title: task.title, dueAt: task.dueAt, priority: task.priority, progress: task.progress })),
      overdue: dashboard.overdue.slice(0, 5).map((task) => ({ title: task.title, dueAt: task.dueAt, priority: task.priority, progress: task.progress })),
      nearestDeadlines: dashboard.nearestDeadlines.map((task) => ({ title: task.title, dueAt: task.dueAt, priority: task.priority, progress: task.progress })),
    };
    const result = await generateStructured(user.id, {
      requestType: "today_insight",
      system: `${DATA_SAFETY}\nBerikan satu saran singkat dan actionable dalam Bahasa Indonesia. Maksimal 2 kalimat. Jangan menakut-nakuti pengguna.`,
      prompt: `Data akademik hari ini: ${JSON.stringify(facts)}`,
      schema: todayInsightJsonSchema,
      schemaName: "today_insight",
      timeoutMs: 12_000,
    }, todayInsightSchema);
    return NextResponse.json({ insight: result.data.insight });
  } catch (error) { return jsonError(error); }
}
