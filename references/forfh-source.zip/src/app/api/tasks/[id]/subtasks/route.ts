import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createSubtask, listSubtasks } from "@/lib/services/tasks";
import { subtaskSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  try { const user = await requireUser(); const { id } = await params; return NextResponse.json({ subtasks: await listSubtasks(user.id, id) }); }
  catch (error) { return jsonError(error); }
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    assertSameOrigin(request); const user = await requireUser(); const { id } = await params;
    const parsed = subtaskSchema.omit({ completed: true, version: true }).safeParse(await request.json());
    if (!parsed.success) throw new AppError("VALIDATION_ERROR", parsed.error.issues[0]?.message ?? "Sub-tugas tidak valid.", 400);
    const subtask = await createSubtask(user.id, id, parsed.data);
    if (!subtask) throw new AppError("NOT_FOUND", "Tugas tidak ditemukan.", 404);
    return NextResponse.json({ subtask }, { status: 201 });
  } catch (error) { return jsonError(error); }
}
