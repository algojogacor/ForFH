import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { deleteSubtask, updateSubtask } from "@/lib/services/tasks";
import { subtaskSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";

export async function PATCH(request:Request,{params}:{params:Promise<{id:string;subtaskId:string}>}){
  try{
    assertSameOrigin(request);const user=await requireUser(),{id,subtaskId}=await params;
    const parsed=subtaskSchema.partial().omit({version:true}).safeParse(await request.json());
    if(!parsed.success)throw new AppError("VALIDATION_ERROR",parsed.error.issues[0]?.message??"Sub-tugas tidak valid.",400);
    const subtask=await updateSubtask(user.id,id,subtaskId,parsed.data);
    if(!subtask)throw new AppError("NOT_FOUND","Sub-tugas tidak ditemukan.",404);
    return NextResponse.json({subtask});
  }catch(error){return jsonError(error);}
}

export async function DELETE(request:Request,{params}:{params:Promise<{id:string;subtaskId:string}>}){
  try{assertSameOrigin(request);const user=await requireUser(),{id,subtaskId}=await params;if(!(await deleteSubtask(user.id,id,subtaskId)))throw new AppError("NOT_FOUND","Sub-tugas tidak ditemukan.",404);return NextResponse.json({ok:true});}
  catch(error){return jsonError(error);}
}
