import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { getTask, softDeleteTask, updateTask } from "@/lib/services/tasks";
import { taskSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){try{const u=await requireUser(),{id}=await params,t=await getTask(u.id,id); if(!t)throw new AppError("NOT_FOUND","Tugas tidak ditemukan.",404); return NextResponse.json({task:t});}catch(e){return jsonError(e);} }
export async function PATCH(request:Request,{params}:{params:Promise<{id:string}>}){try{assertSameOrigin(request);const u=await requireUser(),{id}=await params; const p=taskSchema.partial().safeParse(await request.json()); if(!p.success)throw new AppError("VALIDATION_ERROR",p.error.issues[0]?.message??"Data tidak valid.",400); const t=await updateTask(u.id,id,p.data); if(!t)throw new AppError("NOT_FOUND","Tugas tidak ditemukan.",404);return NextResponse.json({task:t});}catch(e){return jsonError(e);} }
export async function DELETE(request:Request,{params}:{params:Promise<{id:string}>}){try{assertSameOrigin(request);const u=await requireUser(),{id}=await params;if(!(await softDeleteTask(u.id,id)))throw new AppError("NOT_FOUND","Tugas tidak ditemukan.",404);return NextResponse.json({ok:true});}catch(e){return jsonError(e);} }
