import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth/session";
import { listTaskReminders, replaceTaskReminders } from "@/lib/services/tasks";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";

const schema=z.object({offsets:z.array(z.number().int().positive().max(525600)).max(10)});
export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){try{const user=await requireUser(),{id}=await params;const reminders=await listTaskReminders(user.id,id);if(!reminders)throw new AppError("NOT_FOUND","Tugas tidak ditemukan.",404);return NextResponse.json({reminders});}catch(error){return jsonError(error);}}
export async function PUT(request:Request,{params}:{params:Promise<{id:string}>}){try{assertSameOrigin(request);const user=await requireUser(),{id}=await params,parsed=schema.safeParse(await request.json());if(!parsed.success)throw new AppError("VALIDATION_ERROR","Pengingat tidak valid.",400);const reminders=await replaceTaskReminders(user.id,id,parsed.data.offsets);if(!reminders)throw new AppError("NOT_FOUND","Tugas tidak ditemukan.",404);return NextResponse.json({reminders});}catch(error){return jsonError(error);}}
