import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createTask, listTasks } from "@/lib/services/tasks";
import { taskSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";
export async function GET(){ try{const u=await requireUser(); return NextResponse.json({tasks:await listTasks(u.id)});}catch(e){return jsonError(e);} }
export async function POST(request:Request){try{assertSameOrigin(request); const u=await requireUser(); const p=taskSchema.safeParse(await request.json()); if(!p.success) throw new AppError("VALIDATION_ERROR",p.error.issues[0]?.message??"Data tugas tidak valid.",400); return NextResponse.json({task:await createTask(u.id,p.data)},{status:201});}catch(e){return jsonError(e);} }
