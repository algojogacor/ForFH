import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { createReading, listReadings } from "@/lib/services/secondary";
import { readingSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";
export async function GET(){try{const u=await requireUser();return NextResponse.json({readings:await listReadings(u.id)});}catch(e){return jsonError(e)}}
export async function POST(r:Request){try{assertSameOrigin(r);const u=await requireUser(),p=readingSchema.safeParse(await r.json());if(!p.success)throw new AppError("VALIDATION_ERROR",p.error.issues[0]?.message??"Data bacaan tidak valid.",400);return NextResponse.json({reading:await createReading(u.id,p.data)},{status:201});}catch(e){return jsonError(e)}}
