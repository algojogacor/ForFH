import { NextResponse } from "next/server";import { requireUser } from "@/lib/auth/session";import { getLaw } from "@/lib/pasal/client";import { jsonError } from "@/lib/http";
export async function GET(_:Request,{params}:{params:Promise<{frbr:string[]}>}){try{await requireUser();const {frbr}=await params;return NextResponse.json(await getLaw(frbr.join("/")))}catch(e){return jsonError(e)}}
