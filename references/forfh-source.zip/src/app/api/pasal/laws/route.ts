import { NextResponse } from "next/server";import { requireUser } from "@/lib/auth/session";import { listLaws } from "@/lib/pasal/client";import { jsonError } from "@/lib/http";
export async function GET(r:Request){try{await requireUser();const p=new URL(r.url).searchParams;return NextResponse.json(await listLaws(Object.fromEntries(p.entries())))}catch(e){return jsonError(e)}}
