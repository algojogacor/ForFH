import { NextResponse } from "next/server";
import { destroySession } from "@/lib/auth/session";
import { assertSameOrigin, jsonError } from "@/lib/http";
export async function POST(request: Request) { try { assertSameOrigin(request); await destroySession(); return NextResponse.json({ ok: true }); } catch (e) { return jsonError(e); } }
