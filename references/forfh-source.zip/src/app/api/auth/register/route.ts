import { NextResponse } from "next/server";
import { createSession } from "@/lib/auth/session";
import { consumeRateLimit, requestIpHashKey } from "@/lib/auth/rate-limit";
import { registerUser } from "@/lib/services/auth";
import { normalizeUsername } from "@/lib/auth/username";
import { registerSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const raw = await request.json();
    const parsed = registerSchema.safeParse(raw);
    if (!parsed.success) throw new AppError("VALIDATION_ERROR", parsed.error.issues[0]?.message ?? "Data tidak valid.", 400);
    const key = requestIpHashKey(request, "register", normalizeUsername(parsed.data.username));
    const rate = await consumeRateLimit(key, { max: 5, windowMs: 15 * 60_000, blockMs: 30 * 60_000 });
    if (!rate.allowed) throw new AppError("RATE_LIMITED", "Terlalu banyak percobaan. Coba lagi nanti.", 429);
    let user;
    try { user = await registerUser(parsed.data.username, parsed.data.password); }
    catch (e) { if (e instanceof Error && e.message === "USERNAME_TAKEN") throw new AppError("VALIDATION_ERROR", "Username sudah digunakan.", 409); throw e; }
    await createSession(user.id);
    return NextResponse.json({ user }, { status: 201 });
  } catch (e) { return jsonError(e); }
}
