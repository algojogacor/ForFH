import { NextResponse } from "next/server";
import { createSession } from "@/lib/auth/session";
import { clearRateLimit, consumeRateLimit, requestIpHashKey } from "@/lib/auth/rate-limit";
import { authenticateUser } from "@/lib/services/auth";
import { normalizeUsername } from "@/lib/auth/username";
import { loginSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";
import { assertSameOrigin, jsonError } from "@/lib/http";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const raw = await request.json();
    const parsed = loginSchema.safeParse(raw);
    if (!parsed.success) throw new AppError("VALIDATION_ERROR", "Username atau password salah.", 400);
    const key = requestIpHashKey(request, "login", normalizeUsername(parsed.data.username));
    const rate = await consumeRateLimit(key, { max: 8, windowMs: 15 * 60_000, blockMs: 30 * 60_000 });
    if (!rate.allowed) throw new AppError("RATE_LIMITED", "Terlalu banyak percobaan. Coba lagi nanti.", 429);
    const user = await authenticateUser(parsed.data.username, parsed.data.password);
    if (!user) throw new AppError("INVALID_SESSION", "Username atau password salah.", 401);
    await clearRateLimit(key);
    await createSession(user.id);
    return NextResponse.json({ user });
  } catch (e) { return jsonError(e); }
}
