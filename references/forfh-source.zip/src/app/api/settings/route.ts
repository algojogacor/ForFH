import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth/session";
import { assertSameOrigin, jsonError } from "@/lib/http";
import { AppError } from "@/lib/errors";
import { getSettings, updateProfile, updateSettings } from "@/lib/services/settings";

const patchSchema = z.object({
  displayName: z.string().trim().max(120).nullable().optional(),
  timezone: z.string().trim().min(1).max(80).optional(),
  locale: z.string().trim().min(2).max(20).optional(),
  theme: z.enum(["system", "light", "dark"]).optional(),
  defaultTaskReminders: z.array(z.number().int().positive()).max(10).optional(),
  defaultClassReminders: z.array(z.number().int().positive()).max(10).optional(),
  primaryClassAlertMinutes: z.number().int().min(0).max(10080).optional(),
  deadlineBufferMinutes: z.number().int().min(0).max(10080).optional(),
  aiEnabled: z.boolean().optional(),
});

export async function GET() {
  try {
    const user = await requireUser();
    return NextResponse.json({ user, settings: await getSettings(user.id) });
  } catch (error) { return jsonError(error); }
}

export async function PATCH(request: Request) {
  try {
    assertSameOrigin(request);
    const user = await requireUser();
    const parsed = patchSchema.safeParse(await request.json());
    if (!parsed.success) throw new AppError("VALIDATION_ERROR", parsed.error.issues[0]?.message ?? "Pengaturan tidak valid.", 400);
    const { displayName, ...settingsPatch } = parsed.data;
    const profile = displayName !== undefined ? await updateProfile(user.id, { displayName }) : user;
    const settings = Object.keys(settingsPatch).length ? await updateSettings(user.id, settingsPatch) : await getSettings(user.id);
    return NextResponse.json({ user: profile, settings });
  } catch (error) { return jsonError(error); }
}
