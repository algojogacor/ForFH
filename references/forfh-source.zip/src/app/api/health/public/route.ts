import { sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { integrations } from "@/lib/env";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let database = false;
  try {
    await db().run(sql`select 1`);
    database = true;
  } catch {
    database = false;
  }

  const configured = integrations();
  return Response.json({
    status: database ? "ok" : "degraded",
    database,
    features: {
      ai: configured.groq || configured.ollama,
      legal: configured.pasal,
      drive: configured.drive,
      push: configured.push,
      reminders: configured.qstash,
    },
    time: new Date().toISOString(),
  }, { status: database ? 200 : 503, headers: { "Cache-Control": "no-store" } });
}
