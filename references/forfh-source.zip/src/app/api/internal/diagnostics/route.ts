import { timingSafeEqual } from "node:crypto";
import { sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { env, integrations } from "@/lib/env";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function authorized(request: Request) {
  const expected = env().INTERNAL_DIAGNOSTIC_TOKEN;
  if (!expected) return false;
  const header = request.headers.get("authorization");
  if (!header?.startsWith("Bearer ")) return false;
  const received = header.slice("Bearer ".length);
  const a = Buffer.from(received);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function GET(request: Request) {
  if (!authorized(request)) {
    return Response.json({ error: "NOT_FOUND", message: "Tidak ditemukan." }, { status: 404, headers: { "Cache-Control": "no-store" } });
  }

  const checks: Record<string, boolean> = {};
  try {
    await db().run(sql`select 1`);
    checks.database = true;
  } catch {
    checks.database = false;
  }

  const configured = integrations();
  return Response.json({
    status: Object.values(checks).every(Boolean) ? "ok" : "degraded",
    checks,
    integrations: {
      groq: configured.groq,
      ollama: configured.ollama,
      pasal: configured.pasal,
      qstash: configured.qstash,
      drive: configured.drive,
      push: configured.push,
    },
    runtime: {
      node: process.version,
      environment: env().NODE_ENV,
      database: "local-sqlite",
    },
    time: new Date().toISOString(),
  }, { headers: { "Cache-Control": "no-store" } });
}
