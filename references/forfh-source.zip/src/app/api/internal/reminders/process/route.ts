import { verifySignatureAppRouter } from "@upstash/qstash/nextjs";import { processReminders } from "@/lib/scheduler/reminders";
async function handler(){return Response.json(await processReminders())}
export const POST=verifySignatureAppRouter(handler);
