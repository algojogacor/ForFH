import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth/session";
import { getDashboard } from "@/lib/services/dashboard";
import { jsonError } from "@/lib/http";
export async function GET(){try{const user=await requireUser();return NextResponse.json(await getDashboard(user.id));}catch(error){return jsonError(error);}}
