import { redirect } from "next/navigation";import { getCurrentUser } from "@/lib/auth/session";import { AppShell } from "@/components/navigation/app-shell";
export const runtime="nodejs";
export default async function ProtectedLayout({children}:{children:React.ReactNode}){const user=await getCurrentUser();if(!user)redirect('/login');return <AppShell user={user}>{children}</AppShell>}
