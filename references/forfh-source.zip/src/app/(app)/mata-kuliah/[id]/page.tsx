import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, isNull } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { db } from "@/lib/db";
import { classSchedules, exams, files, notes, tasks } from "@/lib/db/schema";
import { getCourse } from "@/lib/services/academic";
import { listAttendance, listGrades, listReadings } from "@/lib/services/secondary";
import { Card } from "@/components/ui/card";
import { formatIdDateTime } from "@/lib/domain/time";

export const dynamic = "force-dynamic";

export default async function CourseDetail({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser(); const { id } = await params; const course = await getCourse(user.id, id); if (!course) notFound();
  const [taskRows, noteRows, scheduleRows, examRows, fileRows, readingRows, attendanceRows, gradeRows] = await Promise.all([
    db().select().from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.courseId, id), isNull(tasks.deletedAt))).orderBy(asc(tasks.dueAt)),
    db().select().from(notes).where(and(eq(notes.userId, user.id), eq(notes.courseId, id), isNull(notes.deletedAt))).orderBy(desc(notes.updatedAt)),
    db().select().from(classSchedules).where(and(eq(classSchedules.userId, user.id), eq(classSchedules.courseId, id))).orderBy(asc(classSchedules.dayOfWeek), asc(classSchedules.startTime)),
    db().select().from(exams).where(and(eq(exams.userId, user.id), eq(exams.courseId, id))).orderBy(asc(exams.examAt)),
    db().select().from(files).where(and(eq(files.userId, user.id), eq(files.courseId, id), isNull(files.deletedAt))).orderBy(desc(files.createdAt)),
    listReadings(user.id), listAttendance(user.id, id), listGrades(user.id, id),
  ]);
  const courseReadings = readingRows.filter(r => r.courseId === id); const attended = attendanceRows.filter(r => r.status === "PRESENT").length;
  const attendancePct = attendanceRows.length ? Math.round(attended / attendanceRows.length * 100) : null;
  return <div className="page">
    <header className="page-head"><div><Link className="text-link" href="/mata-kuliah">← Mata kuliah</Link><h1>{course.name}</h1><p className="muted">{course.code || "Tanpa kode"} · {course.credits ?? "-"} SKS · {course.lecturer || "Dosen belum diisi"}</p></div><span className="course-swatch" style={{ background: course.color || "var(--accent)" }} /></header>
    <div className="course-tabs"><a href="#overview">Overview</a><a href="#tugas">Tugas</a><a href="#catatan">Catatan</a><a href="#bacaan">Bacaan</a><a href="#ujian">Ujian</a><a href="#berkas">Berkas</a></div>
    <div className="content-grid" id="overview">
      <Card><h2>Jadwal</h2><div className="list">{scheduleRows.map(s => <div className="list-row" key={s.id}><strong>Hari {s.dayOfWeek}</strong><div><b>{s.startTime}–{s.endTime}</b><small>{s.room || "Ruang belum diisi"}</small></div></div>)}{!scheduleRows.length && <div className="empty">Belum ada jadwal.</div>}</div></Card>
      <Card><div className="card-head"><h2>Kehadiran</h2><Link className="text-link" href="/kehadiran">Kelola →</Link></div>{attendancePct == null ? <div className="empty">Belum ada data.</div> : <><div className="big-number">{attendancePct}%</div><p className="muted">{attended} hadir dari {attendanceRows.length} pertemuan tercatat.</p></>}</Card>
      <Card id="tugas"><div className="card-head"><h2>Tugas</h2><Link className="text-link" href="/tugas">Semua →</Link></div><div className="list">{taskRows.slice(0, 8).map(t => <Link className="list-row" href={`/tugas/${t.id}`} key={t.id}><div><b>{t.title}</b><small>{t.dueAt ? formatIdDateTime(t.dueAt) : "Tanpa deadline"}</small></div><span className="badge">{t.progress}%</span></Link>)}{!taskRows.length && <div className="empty">Belum ada tugas.</div>}</div></Card>
      <Card id="catatan"><div className="card-head"><h2>Catatan</h2><Link className="text-link" href="/catatan">Semua →</Link></div><div className="list">{noteRows.slice(0, 8).map(n => <Link className="list-row" href={`/catatan/${n.id}`} key={n.id}><div><b>{n.title}</b><small>{formatIdDateTime(n.updatedAt)}</small></div></Link>)}{!noteRows.length && <div className="empty">Belum ada catatan.</div>}</div></Card>
      <Card id="bacaan"><div className="card-head"><h2>Bacaan</h2><Link className="text-link" href="/bacaan">Tracker →</Link></div><div className="list">{courseReadings.slice(0, 8).map(r => <div className="list-row" key={r.id}><div><b>{r.title}</b><small>{r.status}{r.currentPage ? ` · hal. ${r.currentPage}` : ""}</small></div></div>)}{!courseReadings.length && <div className="empty">Belum ada bacaan.</div>}</div></Card>
      <Card id="ujian"><div className="card-head"><h2>Ujian</h2><Link className="text-link" href="/ujian">Semua →</Link></div><div className="list">{examRows.map(e => <Link href={`/ujian/${e.id}`} className="list-row" key={e.id}><div><b>{e.type} · {e.name}</b><small>{formatIdDateTime(e.examAt)}</small></div></Link>)}{!examRows.length && <div className="empty">Belum ada ujian.</div>}</div></Card>
      <Card><div className="card-head"><h2>Nilai</h2><Link className="text-link" href="/nilai">Kelola →</Link></div><div className="list">{gradeRows.slice(0, 6).map(g => <div className="list-row" key={g.id}><div><b>{g.componentName}</b><small>{g.score ?? "—"} · {g.letterGrade ?? "belum ada huruf"}</small></div></div>)}{!gradeRows.length && <div className="empty">Belum ada nilai.</div>}</div></Card>
      <Card className="span-2" id="berkas"><h2>Berkas</h2><div className="list">{fileRows.map(f => <a className="list-row" href={`/api/files/${f.id}/download`} key={f.id}><div><b>{f.name}</b><small>{f.mimeType} · {Math.round(f.sizeBytes / 1024)} KB</small></div></a>)}{!fileRows.length && <div className="empty">Belum ada berkas.</div>}</div></Card>
    </div>
  </div>;
}
