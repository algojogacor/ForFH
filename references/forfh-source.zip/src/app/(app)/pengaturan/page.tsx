import { requireUser } from "@/lib/auth/session";
import { getSettings } from "@/lib/services/settings";
import { storageUsage } from "@/lib/google-drive/storage";
import { env, browserEnv } from "@/lib/env";
import { Card } from "@/components/ui/card";
import { SettingsForm } from "@/components/settings/settings-form";
import { PushButton } from "@/components/settings/push-button";
import { InstallButton } from "@/components/pwa/install-button";

export const dynamic = "force-dynamic";

function mb(bytes: number) {
  return `${(bytes / 1024 / 1024).toFixed(bytes >= 10 * 1024 * 1024 ? 1 : 2)} MB`;
}

export default async function SettingsPage() {
  const user = await requireUser();
  const [settings, usedBytes] = await Promise.all([getSettings(user.id), storageUsage(user.id)]);
  if (!settings) return null;
  const limitBytes = env().DEFAULT_USER_STORAGE_QUOTA_MB * 1024 * 1024;
  const percent = Math.min(100, Math.round((usedBytes / limitBytes) * 100));

  return <div className="page">
    <header className="page-head"><div><span className="eyebrow">Preferensi pribadi</span><h1>Pengaturan</h1><p className="muted">Tema, timezone, AI, pengingat, notifikasi, dan PWA.</p></div></header>
    <div className="content-grid">
      <Card><h2>Profil & preferensi</h2><SettingsForm displayName={user.displayName || ""} settings={settings} /></Card>
      <div className="stack">
        <Card><h2>Notifikasi kelas & tugas</h2><p className="muted">Web Push bersifat best-effort. Peringatan 4 jam sebelum kelas bukan alarm Android yang dijamin berbunyi.</p><PushButton publicKey={browserEnv.vapidPublicKey} /></Card>
        <Card><h2>Penyimpanan</h2><div className="task-meta"><span>{mb(usedBytes)} digunakan</span><b>{mb(limitBytes)}</b></div><div className="mini-progress"><i style={{ width: `${percent}%` }} /></div><p className="muted small">Kuota dihitung dari metadata berkas milik akunmu di penyimpanan pusat.</p></Card>
        <Card><h2>Pasang aplikasi</h2><p className="muted">ForFH dapat dipasang sebagai PWA di browser yang mendukung.</p><InstallButton /></Card>
        <Card><h2>Database development</h2><p className="muted">Saat ini project menggunakan SQLite lokal melalui Node <code>node:sqlite</code>. Tidak ada koneksi Turso.</p></Card>
      </div>
    </div>
  </div>;
}
