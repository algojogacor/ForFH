"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { mutateWithOfflineQueue } from "@/lib/offline/client";

type Course = { id: string; name: string };

export function NoteCreateForm({ courses }: { courses: Course[] }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setInfo("");
    setBusy(true);

    const form = event.currentTarget;
    const data = new FormData(form);
    const body = {
      title: String(data.get("title") || ""),
      courseId: String(data.get("courseId") || "") || null,
      content: "",
      pinned: false,
    };

    try {
      const result = await mutateWithOfflineQueue("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (result.queued) {
        form.reset();
        setInfo("Catatan baru masuk antrean offline dan akan dibuat saat koneksi kembali.");
        return;
      }

      const responseData = await result.response.json();
      if (!result.response.ok) throw new Error(responseData.message || "Gagal membuat catatan.");
      router.push(`/catatan/${responseData.note.id}`);
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Gagal membuat catatan.");
    } finally {
      setBusy(false);
    }
  }

  return <form className="stack" onSubmit={submit}>
    <Field label="Judul"><Input name="title" required /></Field>
    <Field label="Mata kuliah"><Select name="courseId"><option value="">Tanpa mata kuliah</option>{courses.map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</Select></Field>
    {info && <p className="hint-box" role="status">{info}</p>}
    {error && <p className="form-error" role="alert">{error}</p>}
    <Button disabled={busy}>{busy ? "Membuat…" : "Buat catatan"}</Button>
  </form>;
}
