"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Input, Textarea } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { mutateWithOfflineQueue } from "@/lib/offline/client";

type Note = { id: string; title: string; content: string; pinned: boolean };

export function NoteEditor({ note }: { note: Note }) {
  const router = useRouter();
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [pinned, setPinned] = useState(note.pinned);
  const [state, setState] = useState("Tersimpan");
  const [preview, setPreview] = useState(false);
  const first = useRef(true);

  useEffect(() => {
    if (first.current) { first.current = false; return; }
    setState("Menyimpan…");
    const timer = window.setTimeout(async () => {
      try {
        const result = await mutateWithOfflineQueue(`/api/notes/${note.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title, content, pinned }),
        });
        if (result.queued) { setState("Tersimpan offline"); return; }
        setState(result.response.ok ? "Tersimpan" : "Gagal menyimpan");
      } catch { setState("Gagal menyimpan"); }
    }, 700);
    return () => window.clearTimeout(timer);
  }, [title, content, pinned, note.id]);

  async function remove() {
    if (!confirm("Hapus catatan ini?")) return;
    const result = await mutateWithOfflineQueue(`/api/notes/${note.id}`, { method: "DELETE" });
    if (!result.queued && !result.response.ok) { setState("Gagal menghapus"); return; }
    router.push("/catatan");
    router.refresh();
  }

  return <div className="stack">
    <div className="editor-toolbar">
      <span className="muted small" role="status">{state}</span>
      <div className="row-wrap"><Button variant="ghost" type="button" onClick={() => setPreview((value) => !value)}>{preview ? "Edit Markdown" : "Preview"}</Button><label className="check-row"><input type="checkbox" checked={pinned} onChange={(event) => setPinned(event.target.checked)} /> Pin</label><Button variant="danger" type="button" onClick={() => void remove()}>Hapus</Button></div>
    </div>
    <Input value={title} onChange={(event) => setTitle(event.target.value)} className="note-title-input" />
    {preview
      ? <article className="markdown-preview"><ReactMarkdown remarkPlugins={[remarkGfm]}>{content || "_Catatan masih kosong._"}</ReactMarkdown></article>
      : <Textarea value={content} onChange={(event) => setContent(event.target.value)} className="note-editor-area" placeholder="Tulis Markdown di sini…" />}
  </div>;
}
