"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setLoading(true);
    const form = new FormData(event.currentTarget);
    const body = { username: String(form.get("username") || ""), password: String(form.get("password") || ""), ...(mode === "register" ? { confirmPassword: String(form.get("confirmPassword") || "") } : {}) };
    try {
      const response = await fetch(`/api/auth/${mode}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message || "Tidak dapat melanjutkan.");
      router.replace(mode === "register" ? "/onboarding" : "/beranda"); router.refresh();
    } catch (e) { setError(e instanceof Error ? e.message : "Terjadi kesalahan."); }
    finally { setLoading(false); }
  }
  return <form onSubmit={submit} className="stack" style={{ width: "100%" }}>
    <Field label="Username"><Input name="username" autoComplete="username" minLength={3} maxLength={32} required placeholder="mis. aryapratama" /></Field>
    <Field label="Password"><Input name="password" type="password" autoComplete={mode === "register" ? "new-password" : "current-password"} minLength={mode === "register" ? 8 : 1} required /></Field>
    {mode === "register" && <Field label="Konfirmasi password"><Input name="confirmPassword" type="password" autoComplete="new-password" minLength={8} required /></Field>}
    {error && <p role="alert" className="form-error">{error}</p>}
    <Button type="submit" disabled={loading}>{loading ? "Memproses…" : mode === "login" ? "Masuk" : "Buat akun"}</Button>
  </form>;
}
