"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { formatIdDateTime, localDateTimeToUtc } from "@/lib/domain/time";

type Course = { id: string; name: string };
type Exam = { id: string; name: string; type: string; examAt: string; location: string | null; courseName: string };

export function ExamManager({ courses, exams, timezone }: { courses: Course[]; exams: Exam[]; timezone: string }) {
  const router = useRouter();
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const local = String(data.get("examAt") || "");
    const [date, time] = local.split("T");
    if (!date || !time) { setError("Tanggal dan waktu ujian tidak valid."); return; }
    const body = {
      courseId: String(data.get("courseId") || ""),
      name: String(data.get("name") || ""),
      type: String(data.get("type") || "OTHER"),
      examAt: localDateTimeToUtc(date, time, timezone).toISOString(),
      location: String(data.get("location") || "") || null,
      notes: String(data.get("notes") || "") || null,
    };
    const response = await fetch("/api/exams", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const result = await response.json();
    if (!response.ok) { setError(result.message || "Gagal menambah ujian."); return; }
    form.reset();
    setError("");
    router.refresh();
  }

  return <div className="split-layout">
    <section className="surface panel"><h2>Tambah ujian</h2><form className="stack" onSubmit={submit}>
      <Field label="Mata kuliah"><Select name="courseId" required><option value="">Pilih mata kuliah</option>{courses.map((course) => <option value={course.id} key={course.id}>{course.name}</option>)}</Select></Field>
      <div className="form-grid"><Field label="Nama ujian"><Input name="name" required placeholder="UTS / Quiz Bab 3" /></Field><Field label="Jenis"><Select name="type"><option>UTS</option><option>UAS</option><option>QUIZ</option><option>OTHER</option></Select></Field></div>
      <Field label="Tanggal & waktu"><Input type="datetime-local" name="examAt" required /></Field>
      <Field label="Lokasi"><Input name="location" /></Field>
      <Field label="Catatan"><Textarea name="notes" /></Field>
      {error && <p className="form-error" role="alert">{error}</p>}<Button>Tambah ujian</Button>
    </form></section>
    <section className="stack">{exams.map((exam) => { const days = Math.ceil((new Date(exam.examAt).getTime() - Date.now()) / 86400000); return <Link href={`/ujian/${exam.id}`} className="surface exam-card" key={exam.id}><div className="card-head"><span className="badge">{exam.type}</span><span className={days < 0 ? "danger-text" : "muted"}>{days < 0 ? "Lewat" : days === 0 ? "Hari ini" : `${days} hari lagi`}</span></div><h3>{exam.courseName} · {exam.name}</h3><p>{formatIdDateTime(exam.examAt, timezone)}</p><small className="muted">{exam.location || "Lokasi belum diisi"}</small></Link>; })}{!exams.length && <div className="surface empty">Belum ada ujian.</div>}</section>
  </div>;
}
