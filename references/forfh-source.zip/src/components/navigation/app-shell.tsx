import Link from "next/link";
import { BarChart3, BookOpen, CalendarDays, CheckSquare2, ClipboardList, FileText, Gavel, GraduationCap, Home, Search, Settings, TimerReset } from "lucide-react";
import { QuickCaptureButton } from "@/components/quick-capture/quick-capture-button";
import { LogoutButton } from "@/components/navigation/logout-button";
import { OfflineStatus } from "@/components/offline/offline-status";

const nav = [
  ["/beranda", "Beranda", Home], ["/kalender", "Kalender", CalendarDays], ["/tugas", "Tugas", ClipboardList], ["/mata-kuliah", "Mata Kuliah", GraduationCap], ["/catatan", "Catatan", FileText], ["/bacaan", "Bacaan", BookOpen], ["/ujian", "Ujian", TimerReset], ["/kehadiran", "Kehadiran", CheckSquare2], ["/nilai", "Nilai", BarChart3], ["/hukum", "Hukum", Gavel], ["/cari", "Cari", Search], ["/pengaturan", "Pengaturan", Settings],
] as const;

export function AppShell({ children, user }: { children: React.ReactNode; user: { id: string; username: string; displayName: string | null } }) {
  return <div className="app-shell">
    <aside className="sidebar">
      <Link href="/beranda" className="brand"><span className="brand-mark">F</span><span><strong>ForFH</strong><small>College OS</small></span></Link>
      <nav className="side-nav" aria-label="Navigasi utama">{nav.map(([href,label,Icon]) => <Link key={href} href={href}><Icon size={18}/><span>{label}</span></Link>)}</nav>
      <div className="sidebar-user"><div className="avatar">{(user.displayName || user.username).slice(0,1).toUpperCase()}</div><div><strong>{user.displayName || user.username}</strong><small>@{user.username}</small></div></div><LogoutButton/>
    </aside>
    <main className="app-main"><OfflineStatus userId={user.id} />{children}</main>
    <nav className="bottom-nav" aria-label="Navigasi bawah">
      <Link href="/beranda"><Home size={20}/><span>Beranda</span></Link>
      <Link href="/kalender"><CalendarDays size={20}/><span>Kalender</span></Link>
      <QuickCaptureButton compact />
      <Link href="/tugas"><ClipboardList size={20}/><span>Tugas</span></Link>
      <Link href="/mata-kuliah"><GraduationCap size={20}/><span>Lainnya</span></Link>
    </nav>
    <div className="desktop-quick"><QuickCaptureButton /></div>
  </div>;
}
