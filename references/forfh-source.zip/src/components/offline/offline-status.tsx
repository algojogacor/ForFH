"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CloudOff, RefreshCw } from "lucide-react";
import { flushOutbox, outboxCount, setOfflineOwner } from "@/lib/offline/client";

export function OfflineStatus({ userId }: { userId: string }) {
  const router = useRouter();
  const [online, setOnline] = useState(true);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const refreshPending = useCallback(async () => {
    try { setPending(await outboxCount()); } catch { setPending(0); }
  }, []);

  const sync = useCallback(async () => {
    if (typeof navigator !== "undefined" && !navigator.onLine) return;
    setSyncing(true);
    try {
      const result = await flushOutbox();
      if (result.sent > 0) router.refresh();
    } finally {
      setSyncing(false);
      await refreshPending();
    }
  }, [refreshPending, router]);

  useEffect(() => {
    setOfflineOwner(userId);
    setOnline(navigator.onLine);
    void refreshPending();

    const onOnline = () => { setOnline(true); void sync(); };
    const onOffline = () => setOnline(false);
    const onOutbox = () => void refreshPending();

    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    window.addEventListener("forfh:outbox-changed", onOutbox);
    void sync();

    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("forfh:outbox-changed", onOutbox);
    };
  }, [refreshPending, sync, userId]);

  if (online && pending === 0) return null;

  return <div className={`offline-banner ${online ? "pending" : "offline"}`} role="status">
    <CloudOff size={17} />
    <span>{online ? `${pending} perubahan menunggu sinkronisasi.` : `Kamu sedang offline${pending ? ` · ${pending} perubahan tersimpan di perangkat` : ""}.`}</span>
    {online && pending > 0 && <button type="button" onClick={() => void sync()} disabled={syncing}>
      <RefreshCw size={15} /> {syncing ? "Menyinkronkan…" : "Sinkronkan"}
    </button>}
  </div>;
}
