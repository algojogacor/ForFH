"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { FileUpload } from "@/components/forms/file-upload";

type Subtask = { id: string; title: string; completed: boolean; estimatedMinutes: number | null };
type Task = { id: string; title: string; status: string; progress: number; courseId: string | null; dueAt: string | null; estimatedMinutes: number | null };
type BreakdownProposal = { kind: "breakdown"; data: { subtasks: { title: string; estimatedMinutes: number | null }[] } };
type DeadlineProposal = { kind: "deadline"; data: { internalTargetAt: string | null; milestones: { title: string; scheduledAt: string; estimatedMinutes: number }[]; rationale: string } };
type Proposal = BreakdownProposal | DeadlineProposal | null;

export function TaskDetailClient({ task, subtasks: initial }: { task: Task; subtasks: Subtask[] }) {
  const router = useRouter();
  const [subs, setSubs] = useState(initial);
  const [status, setStatus] = useState(task.status);
  const [progress, setProgress] = useState(task.progress);
  const [error, setError] = useState("");
  const [proposal, setProposal] = useState<Proposal>(null);
  const [busy, setBusy] = useState(false);

  async function patchTask(patch: Record<string, unknown>) {
    const response = await fetch(`/api/tasks/${task.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Gagal memperbarui tugas.");
    router.refresh();
    return data.task;
  }

  async function changeStatus(value: string) {
    setStatus(value);
    try { const updated = await patchTask({ status: value }); setProgress(updated.progress); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Gagal memperbarui."); }
  }

  async function addSub(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const title = String(data.get("title") || "").trim();
    if (!title) return;
    const response = await fetch(`/api/tasks/${task.id}/subtasks`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title, estimatedMinutes: null, orderIndex: subs.length }) });
    const result = await response.json();
    if (!response.ok) { setError(result.message || "Gagal menambah sub-tugas."); return; }
    setSubs([...subs, result.subtask]);
    form.reset();
    router.refresh();
  }

  async function toggle(subtask: Subtask, completed: boolean) {
    const response = await fetch(`/api/tasks/${task.id}/subtasks/${subtask.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ completed }) });
    const data = await response.json();
    if (!response.ok) { setError(data.message || "Gagal memperbarui sub-tugas."); return; }
    const next = subs.map((item) => item.id === subtask.id ? { ...item, completed } : item);
    setSubs(next);
    if (next.length) setProgress(Math.round(next.filter((item) => item.completed).length / next.length * 100));
    router.refresh();
  }

  async function aiBreakdown() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/ai/breakdown", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: task.title, estimatedMinutes: task.estimatedMinutes }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "AI tidak tersedia.");
      setProposal({ kind: "breakdown", data: data.proposal });
    } catch (cause) { setError(cause instanceof Error ? cause.message : "AI tidak tersedia."); }
    finally { setBusy(false); }
  }

  async function applyBreakdown() {
    if (!proposal || proposal.kind !== "breakdown") return;
    setBusy(true); setError("");
    try {
      for (const [index, item] of proposal.data.subtasks.entries()) {
        const response = await fetch(`/api/tasks/${task.id}/subtasks`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: item.title, estimatedMinutes: item.estimatedMinutes, orderIndex: subs.length + index }) });
        if (!response.ok) throw new Error("Sebagian rencana tidak dapat diterapkan.");
      }
      setProposal(null);
      router.refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Gagal menerapkan rencana."); }
    finally { setBusy(false); }
  }

  async function smartDeadline() {
    if (!task.dueAt) { setError("Isi deadline dulu untuk membuat Smart Deadline."); return; }
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/ai/smart-deadline", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: task.title, dueAt: task.dueAt, estimatedMinutes: task.estimatedMinutes, progress }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "AI tidak tersedia.");
      setProposal({ kind: "deadline", data: data.proposal });
    } catch (cause) { setError(cause instanceof Error ? cause.message : "AI tidak tersedia."); }
    finally { setBusy(false); }
  }

  async function applyDeadline() {
    if (!proposal || proposal.kind !== "deadline") return;
    setBusy(true); setError("");
    try {
      if (proposal.data.internalTargetAt) await patchTask({ internalTargetAt: proposal.data.internalTargetAt });
      for (const [index, milestone] of proposal.data.milestones.entries()) {
        const response = await fetch(`/api/tasks/${task.id}/subtasks`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: milestone.title, estimatedMinutes: milestone.estimatedMinutes, dueAt: milestone.scheduledAt, orderIndex: subs.length + index }),
        });
        if (!response.ok) throw new Error("Sebagian milestone tidak dapat diterapkan.");
      }
      setProposal(null);
      router.refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Gagal menerapkan Smart Deadline."); }
    finally { setBusy(false); }
  }

  return <div className="stack">
    <div className="form-grid">
      <Field label="Status"><Select value={status} onChange={(event) => void changeStatus(event.target.value)}><option value="NOT_STARTED">Belum mulai</option><option value="IN_PROGRESS">Dikerjakan</option><option value="REVISION">Revisi</option><option value="DONE">Selesai</option></Select></Field>
      <Field label="Progress"><Input type="number" min={0} max={100} value={progress} onChange={(event) => setProgress(Number(event.target.value))} onBlur={() => void patchTask({ progress }).catch(() => setError("Gagal memperbarui progress."))} /></Field>
    </div>

    <section><div className="card-head"><h3>Sub-tugas</h3><span className="badge">{subs.filter((item) => item.completed).length}/{subs.length}</span></div>
      <div className="check-list">{subs.map((subtask) => <label key={subtask.id}><input type="checkbox" checked={subtask.completed} onChange={(event) => void toggle(subtask, event.target.checked)} /><span className={subtask.completed ? "done" : ""}>{subtask.title}</span></label>)}</div>
      <form className="inline-form" onSubmit={addSub}><Input name="title" placeholder="Tambah langkah kecil…" /><Button variant="secondary">Tambah</Button></form>
    </section>

    <div className="row-wrap"><Button type="button" variant="secondary" onClick={() => void aiBreakdown()} disabled={busy}>Pecah tugas dengan AI</Button><Button type="button" variant="secondary" onClick={() => void smartDeadline()} disabled={busy}>Smart Deadline</Button></div>

    {proposal?.kind === "breakdown" && <div className="proposal-box"><h4>Usulan sub-tugas</h4><ol>{proposal.data.subtasks.map((item, index) => <li key={`${item.title}-${index}`}>{item.title}{item.estimatedMinutes ? ` · ${item.estimatedMinutes} menit` : ""}</li>)}</ol><div className="row-wrap"><Button type="button" onClick={() => void applyBreakdown()} disabled={busy}>Terapkan rencana</Button><Button type="button" variant="ghost" onClick={() => setProposal(null)}>Batalkan</Button></div></div>}

    {proposal?.kind === "deadline" && <div className="proposal-box"><h4>Usulan rencana kerja</h4><p>{proposal.data.rationale}</p>{proposal.data.internalTargetAt && <p className="hint-box">Target internal: {new Date(proposal.data.internalTargetAt).toLocaleString("id-ID")}</p>}<ol>{proposal.data.milestones.map((milestone, index) => <li key={`${milestone.title}-${index}`}><b>{milestone.title}</b> · {new Date(milestone.scheduledAt).toLocaleString("id-ID")} · {milestone.estimatedMinutes} menit</li>)}</ol><p className="muted small">Belum ada perubahan sampai kamu menerapkannya.</p><div className="row-wrap"><Button type="button" onClick={() => void applyDeadline()} disabled={busy}>Terapkan rencana</Button><Button type="button" variant="ghost" onClick={() => setProposal(null)}>Batalkan</Button></div></div>}

    <section><h3>Lampiran</h3><FileUpload courseId={task.courseId} category="assignment" onDone={() => router.refresh()} /></section>
    {error && <p className="form-error" role="alert">{error}</p>}
  </div>;
}
