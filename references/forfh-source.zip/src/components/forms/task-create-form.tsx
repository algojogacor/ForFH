"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/input";
import { mutateWithOfflineQueue } from "@/lib/offline/client";
import { localDateTimeToUtc } from "@/lib/domain/time";

type Course = { id: string; name: string };

export function TaskCreateForm({ courses, timezone }: { courses: Course[]; timezone: string }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setInfo("");

    const form = event.currentTarget;
    const data = new FormData(form);
    const date = String(data.get("date") || "");
    const time = String(data.get("time") || "23:59");
    const body = {
      title: String(data.get("title") || ""),
      courseId: String(data.get("courseId") || "") || null,
      description: String(data.get("description") || "") || null,
      type: String(data.get("type") || "assignment"),
      priority: String(data.get("priority") || "medium"),
      estimatedMinutes: data.get("estimatedMinutes") ? Number(data.get("estimatedMinutes")) : null,
      dueAt: date ? localDateTimeToUtc(date, time, timezone).toISOString() : null,
    };

    try {
      const result = await mutateWithOfflineQueue("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (result.queued) {
        form.reset();
        setInfo("Tugas tersimpan di perangkat. Akan dikirim otomatis saat koneksi kembali.");
        return;
      }

      const responseData = await result.response.json();
      if (!result.response.ok) throw new Error(responseData.message || "Gagal membuat tugas.");
      form.reset();
      router.refresh();
      router.push(`/tugas/${responseData.task.id}`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Gagal membuat tugas.");
    } finally {
      setBusy(false);
    }
  }

  return <form className="stack" onSubmit={submit}>
    <Field label="Judul"><Input name="title" required maxLength={240} placeholder="Contoh: Makalah Hukum Pidana" /></Field>
    <div className="form-grid">
      <Field label="Mata kuliah"><Select name="courseId"><option value="">Tanpa mata kuliah</option>{courses.map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</Select></Field>
      <Field label="Jenis"><Select name="type" defaultValue="assignment"><option value="assignment">Tugas</option><option value="essay">Esai</option><option value="paper">Makalah</option><option value="presentation">Presentasi</option><option value="reading">Bacaan</option><option value="quiz">Kuis</option><option value="practice">Latihan</option><option value="administrative">Administratif</option><option value="other">Lainnya</option></Select></Field>
    </div>
    <Textarea name="description" placeholder="Deskripsi (opsional)" />
    <div className="form-grid"><Field label="Deadline"><Input type="date" name="date" /></Field><Field label="Jam"><Input type="time" name="time" defaultValue="23:59" /></Field></div>
    <div className="form-grid"><Field label="Prioritas"><Select name="priority" defaultValue="medium"><option value="low">Rendah</option><option value="medium">Sedang</option><option value="high">Tinggi</option><option value="urgent">Mendesak</option></Select></Field><Field label="Estimasi (menit)"><Input type="number" name="estimatedMinutes" min={1} /></Field></div>
    {info && <p className="hint-box" role="status">{info}</p>}
    {error && <p className="form-error" role="alert">{error}</p>}
    <Button disabled={busy}>{busy ? "Menyimpan…" : "Tambah tugas"}</Button>
  </form>;
}
