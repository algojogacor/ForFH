"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";

type Settings = {
  timezone: string; locale: string; theme: "system" | "light" | "dark";
  primaryClassAlertMinutes: number; deadlineBufferMinutes: number; aiEnabled: boolean;
  defaultClassReminders: number[]; defaultTaskReminders: number[];
};
const classOptions = [120, 90, 60, 30, 20];
const taskOptions = [10080, 4320, 1440, 360, 60];
const labelOffset = (n:number) => n >= 1440 ? `${n/1440} hari` : n >= 60 ? `${n/60} jam` : `${n} menit`;

export function SettingsForm({ displayName, settings }: { displayName: string; settings: Settings }) {
  const router = useRouter(); const [message, setMessage] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget);
    const body = {
      displayName: String(f.get("displayName") || "") || null,
      timezone: String(f.get("timezone") || "Asia/Jakarta"), locale: "id-ID",
      theme: String(f.get("theme") || "system"),
      primaryClassAlertMinutes: Number(f.get("primaryClassAlertMinutes")),
      deadlineBufferMinutes: Number(f.get("deadlineBufferMinutes")),
      aiEnabled: f.get("aiEnabled") === "on",
      defaultClassReminders: f.getAll("classReminder").map(Number).sort((a,b)=>b-a),
      defaultTaskReminders: f.getAll("taskReminder").map(Number).sort((a,b)=>b-a),
    };
    const r = await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const d = await r.json();
    setMessage(r.ok ? "Pengaturan disimpan." : d.message || "Gagal menyimpan.");
    if (r.ok) { localStorage.setItem("forfh-theme", body.theme); if (body.theme === "dark" || body.theme === "light") document.documentElement.dataset.theme = body.theme; else delete document.documentElement.dataset.theme; router.refresh(); }
  }
  return <form className="stack" onSubmit={submit}>
    <Field label="Nama tampilan"><Input name="displayName" defaultValue={displayName} /></Field>
    <Field label="Timezone" hint="Default Asia/Jakarta; bisa diganti bila kuliah di zona waktu lain."><Input name="timezone" defaultValue={settings.timezone} /></Field>
    <Field label="Tema"><Select name="theme" defaultValue={settings.theme}><option value="system">Ikuti sistem</option><option value="light">Terang</option><option value="dark">Gelap</option></Select></Field>
    <div className="form-grid"><Field label="Peringatan utama kelas (menit)"><Input type="number" name="primaryClassAlertMinutes" min={0} defaultValue={settings.primaryClassAlertMinutes} /></Field><Field label="Buffer target internal (menit)"><Input type="number" name="deadlineBufferMinutes" min={0} defaultValue={settings.deadlineBufferMinutes} /></Field></div>
    <div><span className="section-label">Pengingat kelas</span><div className="reminder-grid">{classOptions.map(n=><label className="check-row" key={n}><input type="checkbox" name="classReminder" value={n} defaultChecked={settings.defaultClassReminders.includes(n)}/><span>{labelOffset(n)} sebelumnya</span></label>)}</div></div>
    <div><span className="section-label">Pengingat tugas</span><div className="reminder-grid">{taskOptions.map(n=><label className="check-row" key={n}><input type="checkbox" name="taskReminder" value={n} defaultChecked={settings.defaultTaskReminders.includes(n)}/><span>{labelOffset(n)} sebelumnya</span></label>)}</div></div>
    <label className="check-row"><input type="checkbox" name="aiEnabled" defaultChecked={settings.aiEnabled} /><span>Aktifkan fitur AI</span></label>
    {message && <p className="hint-box">{message}</p>}<Button>Simpan pengaturan</Button>
  </form>;
}
