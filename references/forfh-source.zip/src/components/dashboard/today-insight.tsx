"use client";
import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
export function TodayInsight(){const[message,setMessage]=useState("Menyiapkan saran…");useEffect(()=>{let live=true;fetch('/api/ai/today-insight',{method:'POST'}).then(async r=>{const d=await r.json();if(!live)return;setMessage(r.ok?d.insight:(d.message||'AI sedang tidak tersedia. Fitur utama aplikasi tetap dapat digunakan.'))}).catch(()=>live&&setMessage('AI sedang tidak tersedia. Fitur utama aplikasi tetap dapat digunakan.'));return()=>{live=false}},[]);return <div className="insight"><Sparkles size={18}/><p>{message}</p></div>}
