import { createHash, randomBytes, randomUUID } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt, lte } from "drizzle-orm";
import { db } from "@/lib/db";
import { sessions, users } from "@/lib/db/schema";
import { AppError } from "@/lib/errors";

const DEV_COOKIE = "forfh-session";
const PROD_COOKIE = "__Host-forfh-session";
const SESSION_DAYS = 30;

function cookieName() { return process.env.NODE_ENV === "production" ? PROD_COOKIE : DEV_COOKIE; }
export function hashSessionToken(token: string) { return createHash("sha256").update(token).digest("base64url"); }

export async function createSession(userId: string) {
  const raw = randomBytes(32).toString("base64url");
  const now = new Date();
  await db().delete(sessions).where(lte(sessions.expiresAt, now.toISOString()));
  const expires = new Date(now.getTime() + SESSION_DAYS * 86400_000);
  await db().insert(sessions).values({ id: randomUUID(), userId, tokenHash: hashSessionToken(raw), createdAt: now.toISOString(), lastSeenAt: now.toISOString(), expiresAt: expires.toISOString() });
  const jar = await cookies();
  jar.set(cookieName(), raw, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", expires });
  return expires;
}

export async function destroySession() {
  const jar = await cookies();
  const raw = jar.get(cookieName())?.value;
  if (raw) await db().delete(sessions).where(eq(sessions.tokenHash, hashSessionToken(raw)));
  jar.delete(cookieName());
}

export async function getCurrentUser() {
  const jar = await cookies();
  const raw = jar.get(cookieName())?.value;
  if (!raw) return null;
  const now = new Date().toISOString();
  const rows = await db().select({ id: users.id, username: users.username, displayName: users.displayName, sessionId: sessions.id })
    .from(sessions).innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, hashSessionToken(raw)), gt(sessions.expiresAt, now))).limit(1);
  if (!rows[0]) {
    await db().delete(sessions).where(eq(sessions.tokenHash, hashSessionToken(raw)));
    return null;
  }
  await db().update(sessions).set({ lastSeenAt: now }).where(eq(sessions.id, rows[0].sessionId));
  return { id: rows[0].id, username: rows[0].username, displayName: rows[0].displayName };
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) throw new AppError("INVALID_SESSION", "Sesi berakhir. Silakan masuk kembali.", 401);
  return user;
}

export async function invalidateOtherSessions(userId: string, keepTokenHash?: string) {
  if (!keepTokenHash) return void await db().delete(sessions).where(eq(sessions.userId, userId));
  const existing = await db().select({ id: sessions.id, tokenHash: sessions.tokenHash }).from(sessions).where(eq(sessions.userId, userId));
  const ids = existing.filter((s) => s.tokenHash !== keepTokenHash).map((s) => s.id);
  for (const id of ids) await db().delete(sessions).where(eq(sessions.id, id));
}
