import { randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { requireCoreEnv } from "@/lib/env";

const scrypt = promisify(scryptCb);
const N = 1 << 15;
const r = 8;
const p = 1;
const KEY_LEN = 64;

export async function hashPassword(password: string): Promise<string> {
  const { PASSWORD_PEPPER } = requireCoreEnv();
  const salt = randomBytes(16);
  const key = (await scrypt(`${password}\0${PASSWORD_PEPPER}`, salt, KEY_LEN, { N, r, p, maxmem: 64 * 1024 * 1024 })) as Buffer;
  return `scrypt$${N}$${r}$${p}$${salt.toString("base64url")}$${key.toString("base64url")}`;
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  const parts = encoded.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, nRaw, rRaw, pRaw, saltRaw, expectedRaw] = parts;
  const n = Number(nRaw); const rr = Number(rRaw); const pp = Number(pRaw);
  if (!Number.isSafeInteger(n) || !Number.isSafeInteger(rr) || !Number.isSafeInteger(pp)) return false;
  const salt = Buffer.from(saltRaw, "base64url");
  const expected = Buffer.from(expectedRaw, "base64url");
  if (expected.length !== KEY_LEN || salt.length < 16) return false;
  const { PASSWORD_PEPPER } = requireCoreEnv();
  const actual = (await scrypt(`${password}\0${PASSWORD_PEPPER}`, salt, expected.length, { N: n, r: rr, p: pp, maxmem: 64 * 1024 * 1024 })) as Buffer;
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
