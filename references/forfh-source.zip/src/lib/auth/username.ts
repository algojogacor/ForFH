export function normalizeUsername(username: string) {
  return username.trim().normalize("NFKC").toLocaleLowerCase("id-ID");
}
