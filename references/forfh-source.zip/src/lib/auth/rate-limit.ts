import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { authRateLimits } from "@/lib/db/schema";
import { env } from "@/lib/env";

function hashKey(value: string) {
  const secret = env().SESSION_SECRET ?? "forfh-dev-rate-limit";
  return createHash("sha256").update(`${secret}\0${value}`).digest("hex");
}

export function requestIpHashKey(request: Request, scope: string, identity = "anonymous") {
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  return hashKey(`${scope}|${identity}|${ip}`);
}

export async function consumeRateLimit(keyHash: string, opts: { max: number; windowMs: number; blockMs: number }) {
  const now = Date.now();
  const row = (await db().select().from(authRateLimits).where(eq(authRateLimits.keyHash, keyHash)).limit(1))[0];
  if (row?.blockedUntil && Date.parse(row.blockedUntil) > now) return { allowed: false, retryAfterMs: Date.parse(row.blockedUntil) - now };
  const windowStart = row ? Date.parse(row.windowStart) : 0;
  if (!row || !Number.isFinite(windowStart) || now - windowStart >= opts.windowMs) {
    await db().insert(authRateLimits).values({ keyHash, windowStart: new Date(now).toISOString(), attemptCount: 1, blockedUntil: null })
      .onConflictDoUpdate({ target: authRateLimits.keyHash, set: { windowStart: new Date(now).toISOString(), attemptCount: 1, blockedUntil: null } });
    return { allowed: true, retryAfterMs: 0 };
  }
  const count = row.attemptCount + 1;
  const blockedUntil = count > opts.max ? new Date(now + opts.blockMs).toISOString() : null;
  await db().update(authRateLimits).set({ attemptCount: count, blockedUntil }).where(eq(authRateLimits.keyHash, keyHash));
  return { allowed: count <= opts.max, retryAfterMs: blockedUntil ? opts.blockMs : 0 };
}

export async function clearRateLimit(keyHash: string) { await db().delete(authRateLimits).where(eq(authRateLimits.keyHash, keyHash)); }
