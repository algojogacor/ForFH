export type ErrorCode =
  | "AI_PROVIDER_UNAVAILABLE"
  | "DRIVE_UPLOAD_FAILED"
  | "PASAL_RATE_LIMITED"
  | "INVALID_SESSION"
  | "FORBIDDEN"
  | "VALIDATION_ERROR"
  | "RATE_LIMITED"
  | "NOT_FOUND"
  | "CONFIGURATION_ERROR";

export class AppError extends Error {
  constructor(
    public code: ErrorCode,
    message: string,
    public status = 400,
    public details?: unknown,
  ) {
    super(message);
    this.name = "AppError";
  }
}

export function userMessage(error: unknown) {
  if (error instanceof AppError) return error.message;
  return "Terjadi kesalahan. Silakan coba lagi.";
}
