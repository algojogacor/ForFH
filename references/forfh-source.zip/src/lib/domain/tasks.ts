export type TaskStatus = "NOT_STARTED" | "IN_PROGRESS" | "REVISION" | "DONE" | "OVERDUE";
export function displayTaskStatus(status: TaskStatus, dueAt?: string | null, now = new Date()): TaskStatus { return status !== "DONE" && dueAt && Date.parse(dueAt) < now.getTime() ? "OVERDUE" : status; }
export function progressFromSubtasks(items: { completed: boolean }[]) { if (!items.length) return null; return Math.round(items.filter(x=>x.completed).length/items.length*100); }
export const priorityRank = { urgent: 4, high: 3, medium: 2, low: 1 } as const;
