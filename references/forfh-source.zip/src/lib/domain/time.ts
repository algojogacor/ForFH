export const DEFAULT_TIMEZONE = "Asia/Jakarta";
const weekdayMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

export function zonedParts(date: Date, timezone = DEFAULT_TIMEZONE) {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23", weekday: "short" }).formatToParts(date);
  const get = (t: Intl.DateTimeFormatPartTypes) => parts.find((p) => p.type === t)?.value ?? "";
  return { year: Number(get("year")), month: Number(get("month")), day: Number(get("day")), hour: Number(get("hour")), minute: Number(get("minute")), second: Number(get("second")), weekday: weekdayMap[get("weekday")] };
}

export function localDateTimeToUtc(date: string, time: string, timezone = DEFAULT_TIMEZONE): Date {
  const [y,m,d] = date.split("-").map(Number); const [hh,mm] = time.split(":").map(Number);
  let guess = new Date(Date.UTC(y,m-1,d,hh,mm,0));
  for (let i=0;i<3;i++) {
    const p = zonedParts(guess, timezone);
    const represented = Date.UTC(p.year,p.month-1,p.day,p.hour,p.minute,p.second);
    const target = Date.UTC(y,m-1,d,hh,mm,0);
    guess = new Date(guess.getTime() + target - represented);
  }
  return guess;
}

export function isoLocalDate(date: Date, timezone = DEFAULT_TIMEZONE) { const p=zonedParts(date,timezone); return `${p.year}-${String(p.month).padStart(2,"0")}-${String(p.day).padStart(2,"0")}`; }
export function addLocalDays(localDate: string, days: number) { const [y,m,d]=localDate.split("-").map(Number); const x=new Date(Date.UTC(y,m-1,d+days)); return `${x.getUTCFullYear()}-${String(x.getUTCMonth()+1).padStart(2,"0")}-${String(x.getUTCDate()).padStart(2,"0")}`; }
export function formatIdDateTime(iso: string | Date, timezone = DEFAULT_TIMEZONE) { return new Intl.DateTimeFormat("id-ID", { timeZone: timezone, dateStyle: "medium", timeStyle: "short", hourCycle: "h23" }).format(typeof iso === "string" ? new Date(iso) : iso); }
export function minutesUntil(iso: string, now = new Date()) { return Math.round((Date.parse(iso)-now.getTime())/60000); }
export function humanCountdown(minutes: number) { if(minutes<0) return "terlewat"; if(minutes<60) return `${minutes} menit lagi`; const h=Math.floor(minutes/60), m=minutes%60; if(h<24) return `${h} jam${m?` ${m} menit`:""} lagi`; const d=Math.floor(h/24), rh=h%24; return `${d} hari${rh?` ${rh} jam`:""} lagi`; }
