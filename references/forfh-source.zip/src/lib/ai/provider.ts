export type AiProviderName = "groq" | "ollama";
export type AiRequestType = "quick_capture" | "task_breakdown" | "smart_deadline" | "today_insight" | "note_summary" | "legal_explanation" | "exam_plan";
export type AiUsage = { inputTokens?: number; outputTokens?: number };
export type AiResult<T> = { data:T; provider:AiProviderName; slot:number; model:string; usage?:AiUsage };
export type JsonSchema = Record<string, unknown>;
export interface AiProviderRequest { system: string; prompt: string; requestType: AiRequestType; schema?: JsonSchema; schemaName?: string; timeoutMs?: number; }
export class ProviderFailure extends Error { constructor(public provider:AiProviderName,public slot:number,public status:number|undefined,public retryAfterMs:number|undefined,message:string){super(message);} }
