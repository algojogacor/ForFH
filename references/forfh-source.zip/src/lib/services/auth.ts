import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { users, userSettings } from "@/lib/db/schema";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { normalizeUsername } from "@/lib/auth/username";


export async function registerUser(username: string, password: string, displayName?: string | null) {
  const normalized = normalizeUsername(username);
  const duplicate = await db().select({ id: users.id }).from(users).where(eq(users.usernameNormalized, normalized)).limit(1);
  if (duplicate.length) throw new Error("USERNAME_TAKEN");
  const userId = randomUUID(); const now = new Date().toISOString();
  await db().transaction(async (tx) => {
    await tx.insert(users).values({ id: userId, username: username.trim(), usernameNormalized: normalized, passwordHash: await hashPassword(password), displayName: displayName?.trim() || null, createdAt: now, updatedAt: now });
    await tx.insert(userSettings).values({ id: randomUUID(), userId, timezone: "Asia/Jakarta", locale: "id-ID", theme: "system", defaultTaskReminders: [10080,4320,1440,360,60], defaultClassReminders: [120,90,60,30,20], primaryClassAlertMinutes: 240, deadlineBufferMinutes: 720, aiEnabled: true, createdAt: now, updatedAt: now });
  });
  return { id: userId, username: username.trim(), displayName: displayName?.trim() || null };
}

export async function authenticateUser(username: string, password: string) {
  const normalized = normalizeUsername(username);
  const row = (await db().select().from(users).where(eq(users.usernameNormalized, normalized)).limit(1))[0];
  if (!row || !(await verifyPassword(password, row.passwordHash))) return null;
  return { id: row.id, username: row.username, displayName: row.displayName };
}
