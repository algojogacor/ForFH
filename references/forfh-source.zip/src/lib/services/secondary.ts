import { randomUUID } from "node:crypto";
import { and, asc, desc, eq, isNull } from "drizzle-orm";
import { db } from "@/lib/db";
import { attendance, courses, examTopics, exams, files, grades, legalBookmarks, readings } from "@/lib/db/schema";
import { getCourse } from "@/lib/services/academic";
import { AppError } from "@/lib/errors";

async function ensureCourse(userId: string, courseId: string) {
  const course = await getCourse(userId, courseId);
  if (!course) throw new AppError("NOT_FOUND", "Mata kuliah tidak ditemukan.", 404);
  return course;
}

async function ensureOwnedFile(userId: string, fileId: string) {
  const row = (await db().select({ id: files.id }).from(files).where(and(eq(files.id, fileId), eq(files.userId, userId), isNull(files.deletedAt))).limit(1))[0];
  if (!row) throw new AppError("NOT_FOUND", "Berkas tidak ditemukan.", 404);
}

export async function listReadings(userId: string) {
  return db().select({
    id: readings.id, courseId: readings.courseId, courseName: courses.name, fileId: readings.fileId,
    type: readings.type, title: readings.title, author: readings.author, sourceUrl: readings.sourceUrl,
    startPage: readings.startPage, endPage: readings.endPage, currentPage: readings.currentPage,
    status: readings.status, deadline: readings.deadline, notes: readings.notes,
    createdAt: readings.createdAt, updatedAt: readings.updatedAt,
  }).from(readings).leftJoin(courses, and(eq(readings.courseId, courses.id), eq(courses.userId, userId)))
    .where(eq(readings.userId, userId)).orderBy(asc(readings.status), asc(readings.deadline), desc(readings.updatedAt));
}

export async function createReading(userId: string, input: Omit<typeof readings.$inferInsert, "id" | "userId" | "createdAt" | "updatedAt">) {
  if (input.courseId) await ensureCourse(userId, input.courseId);
  if (input.fileId) await ensureOwnedFile(userId, input.fileId);
  if (input.startPage && input.endPage && input.endPage < input.startPage) throw new AppError("VALIDATION_ERROR", "Halaman akhir tidak boleh sebelum halaman awal.", 400);
  const id = randomUUID(), now = new Date().toISOString();
  await db().insert(readings).values({ ...input, id, userId, createdAt: now, updatedAt: now });
  return (await db().select().from(readings).where(and(eq(readings.id, id), eq(readings.userId, userId))).limit(1))[0];
}

export async function updateReading(userId: string, id: string, patch: Partial<typeof readings.$inferInsert>) {
  const current = (await db().select().from(readings).where(and(eq(readings.id, id), eq(readings.userId, userId))).limit(1))[0];
  if (!current) return null;
  if (patch.courseId) await ensureCourse(userId, patch.courseId);
  if (patch.fileId) await ensureOwnedFile(userId, patch.fileId);
  const start = patch.startPage ?? current.startPage, end = patch.endPage ?? current.endPage;
  if (start && end && end < start) throw new AppError("VALIDATION_ERROR", "Halaman akhir tidak boleh sebelum halaman awal.", 400);
  await db().update(readings).set({ ...patch, updatedAt: new Date().toISOString() }).where(and(eq(readings.id, id), eq(readings.userId, userId)));
  return (await db().select().from(readings).where(and(eq(readings.id, id), eq(readings.userId, userId))).limit(1))[0];
}

export async function deleteReading(userId: string, id: string) {
  return (await db().delete(readings).where(and(eq(readings.id, id), eq(readings.userId, userId))).returning({ id: readings.id })).length > 0;
}

export async function listExams(userId: string) {
  return db().select({
    id: exams.id, courseId: exams.courseId, courseName: courses.name, courseColor: courses.color,
    name: exams.name, type: exams.type, examAt: exams.examAt, location: exams.location, notes: exams.notes,
    createdAt: exams.createdAt, updatedAt: exams.updatedAt,
  }).from(exams).innerJoin(courses, and(eq(exams.courseId, courses.id), eq(courses.userId, userId)))
    .where(eq(exams.userId, userId)).orderBy(asc(exams.examAt));
}

export async function getExam(userId: string, id: string) {
  return (await db().select().from(exams).where(and(eq(exams.id, id), eq(exams.userId, userId))).limit(1))[0] ?? null;
}

export async function createExam(userId: string, input: Omit<typeof exams.$inferInsert, "id" | "userId" | "createdAt" | "updatedAt">) {
  await ensureCourse(userId, input.courseId);
  const id = randomUUID(), now = new Date().toISOString();
  await db().insert(exams).values({ ...input, id, userId, createdAt: now, updatedAt: now });
  return getExam(userId, id);
}

export async function updateExam(userId: string, id: string, patch: Partial<Omit<typeof exams.$inferInsert, "id" | "userId" | "createdAt">>) {
  const current = await getExam(userId, id); if (!current) return null;
  if (patch.courseId) await ensureCourse(userId, patch.courseId);
  await db().update(exams).set({ ...patch, updatedAt: new Date().toISOString() }).where(and(eq(exams.id, id), eq(exams.userId, userId)));
  return getExam(userId, id);
}

export async function deleteExam(userId: string, id: string) {
  return (await db().delete(exams).where(and(eq(exams.id, id), eq(exams.userId, userId))).returning({ id: exams.id })).length > 0;
}

export async function listExamTopics(userId: string, examId: string) {
  if (!(await getExam(userId, examId))) return [];
  return db().select().from(examTopics).where(and(eq(examTopics.userId, userId), eq(examTopics.examId, examId))).orderBy(asc(examTopics.orderIndex));
}

export async function createExamTopic(userId: string, examId: string, input: { title: string; completed?: boolean; orderIndex?: number }) {
  if (!(await getExam(userId, examId))) return null;
  const row = { id: randomUUID(), userId, examId, title: input.title, completed: input.completed ?? false, orderIndex: input.orderIndex ?? 0 };
  await db().insert(examTopics).values(row); return row;
}

export async function updateExamTopic(userId: string, examId: string, topicId: string, patch: Partial<{ title: string; completed: boolean; orderIndex: number }>) {
  if (!(await getExam(userId, examId))) return null;
  const result = await db().update(examTopics).set(patch).where(and(eq(examTopics.id, topicId), eq(examTopics.examId, examId), eq(examTopics.userId, userId))).returning();
  return result[0] ?? null;
}

export async function deleteExamTopic(userId: string, examId: string, topicId: string) {
  return (await db().delete(examTopics).where(and(eq(examTopics.id, topicId), eq(examTopics.examId, examId), eq(examTopics.userId, userId))).returning({ id: examTopics.id })).length > 0;
}

export async function listAttendance(userId: string, courseId?: string) {
  const where = courseId ? and(eq(attendance.userId, userId), eq(attendance.courseId, courseId)) : eq(attendance.userId, userId);
  return db().select({ id: attendance.id, courseId: attendance.courseId, courseName: courses.name, classDate: attendance.classDate, status: attendance.status, notes: attendance.notes, createdAt: attendance.createdAt })
    .from(attendance).innerJoin(courses, and(eq(attendance.courseId, courses.id), eq(courses.userId, userId))).where(where).orderBy(desc(attendance.classDate));
}

export async function upsertAttendance(userId: string, input: Omit<typeof attendance.$inferInsert, "id" | "userId" | "createdAt">) {
  await ensureCourse(userId, input.courseId);
  const existing = (await db().select().from(attendance).where(and(eq(attendance.userId, userId), eq(attendance.courseId, input.courseId), eq(attendance.classDate, input.classDate))).limit(1))[0];
  if (existing) {
    await db().update(attendance).set({ status: input.status, notes: input.notes ?? null }).where(and(eq(attendance.id, existing.id), eq(attendance.userId, userId)));
    return { ...existing, status: input.status, notes: input.notes ?? null };
  }
  const row = { id: randomUUID(), userId, ...input, createdAt: new Date().toISOString() };
  await db().insert(attendance).values(row); return row;
}

export async function deleteAttendance(userId: string, id: string) {
  return (await db().delete(attendance).where(and(eq(attendance.id, id), eq(attendance.userId, userId))).returning({ id: attendance.id })).length > 0;
}

export async function listGrades(userId: string, courseId?: string) {
  const where = courseId ? and(eq(grades.userId, userId), eq(grades.courseId, courseId)) : eq(grades.userId, userId);
  return db().select({ id: grades.id, courseId: grades.courseId, courseName: courses.name, credits: courses.credits, componentName: grades.componentName, weight: grades.weight, score: grades.score, letterGrade: grades.letterGrade, gradePoint: grades.gradePoint, createdAt: grades.createdAt, updatedAt: grades.updatedAt })
    .from(grades).innerJoin(courses, and(eq(grades.courseId, courses.id), eq(courses.userId, userId))).where(where).orderBy(asc(courses.name), asc(grades.componentName));
}

export async function createGrade(userId: string, input: Omit<typeof grades.$inferInsert, "id" | "userId" | "createdAt" | "updatedAt">) {
  await ensureCourse(userId, input.courseId); const id = randomUUID(), now = new Date().toISOString();
  await db().insert(grades).values({ ...input, id, userId, createdAt: now, updatedAt: now });
  return (await db().select().from(grades).where(and(eq(grades.id, id), eq(grades.userId, userId))).limit(1))[0];
}

export async function updateGrade(userId: string, id: string, patch: Partial<Omit<typeof grades.$inferInsert, "id" | "userId" | "createdAt">>) {
  const current = (await db().select().from(grades).where(and(eq(grades.id, id), eq(grades.userId, userId))).limit(1))[0]; if (!current) return null;
  if (patch.courseId) await ensureCourse(userId, patch.courseId);
  await db().update(grades).set({ ...patch, updatedAt: new Date().toISOString() }).where(and(eq(grades.id, id), eq(grades.userId, userId)));
  return (await db().select().from(grades).where(and(eq(grades.id, id), eq(grades.userId, userId))).limit(1))[0];
}

export async function deleteGrade(userId: string, id: string) {
  return (await db().delete(grades).where(and(eq(grades.id, id), eq(grades.userId, userId))).returning({ id: grades.id })).length > 0;
}

export function calculateGradeSummary(rows: Array<{ courseId: string; credits: number | null; weight: number | null; score: number | null; gradePoint: number | null }>) {
  const byCourse = new Map<string, typeof rows>();
  for (const row of rows) byCourse.set(row.courseId, [...(byCourse.get(row.courseId) ?? []), row]);
  const coursesSummary = [...byCourse.entries()].map(([courseId, items]) => {
    const weighted = items.filter(x => x.score != null && x.weight != null);
    const weightTotal = weighted.reduce((s, x) => s + (x.weight ?? 0), 0);
    const score = weightTotal ? weighted.reduce((s, x) => s + (x.score ?? 0) * (x.weight ?? 0), 0) / weightTotal : null;
    const gp = items.find(x => x.gradePoint != null)?.gradePoint ?? null;
    const credits = items.find(x => x.credits != null)?.credits ?? 0;
    return { courseId, score, gradePoint: gp, credits };
  });
  const gpaRows = coursesSummary.filter(x => x.gradePoint != null && x.credits > 0);
  const totalCredits = gpaRows.reduce((s, x) => s + x.credits, 0);
  const gpa = totalCredits ? gpaRows.reduce((s, x) => s + (x.gradePoint ?? 0) * x.credits, 0) / totalCredits : null;
  return { courses: coursesSummary, gpa, totalCredits };
}

export async function listLegalBookmarks(userId: string) {
  return db().select({ id: legalBookmarks.id, courseId: legalBookmarks.courseId, courseName: courses.name, frbrUri: legalBookmarks.frbrUri, title: legalBookmarks.title, type: legalBookmarks.type, number: legalBookmarks.number, year: legalBookmarks.year, userNote: legalBookmarks.userNote, createdAt: legalBookmarks.createdAt })
    .from(legalBookmarks).leftJoin(courses, and(eq(legalBookmarks.courseId, courses.id), eq(courses.userId, userId))).where(eq(legalBookmarks.userId, userId)).orderBy(desc(legalBookmarks.createdAt));
}

export async function createLegalBookmark(userId: string, input: Omit<typeof legalBookmarks.$inferInsert, "id" | "userId" | "createdAt">) {
  if (input.courseId) await ensureCourse(userId, input.courseId);
  const existing = (await db().select().from(legalBookmarks).where(and(eq(legalBookmarks.userId, userId), eq(legalBookmarks.frbrUri, input.frbrUri))).limit(1))[0];
  if (existing) return existing;
  const row = { id: randomUUID(), userId, ...input, createdAt: new Date().toISOString() }; await db().insert(legalBookmarks).values(row); return row;
}

export async function deleteLegalBookmark(userId: string, id: string) {
  return (await db().delete(legalBookmarks).where(and(eq(legalBookmarks.id, id), eq(legalBookmarks.userId, userId))).returning({ id: legalBookmarks.id })).length > 0;
}
