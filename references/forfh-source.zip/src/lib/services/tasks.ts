import { randomUUID } from "node:crypto";
import { and, asc, desc, eq, isNull, sql } from "drizzle-orm";
import { db } from "@/lib/db";
import { subtasks, taskReminders, tasks, userSettings } from "@/lib/db/schema";
import { progressFromSubtasks } from "@/lib/domain/tasks";
import { getCourse } from "@/lib/services/academic";

export async function listTasks(userId: string) {
  return db().select().from(tasks).where(and(eq(tasks.userId,userId),isNull(tasks.deletedAt))).orderBy(sql`${tasks.dueAt} IS NULL`, asc(tasks.dueAt), desc(tasks.updatedAt));
}

export async function getTask(userId:string,id:string){
  return (await db().select().from(tasks).where(and(eq(tasks.id,id),eq(tasks.userId,userId),isNull(tasks.deletedAt))).limit(1))[0]??null;
}

export async function createTask(userId:string,input:{title:string;courseId?:string|null;description?:string|null;type?:typeof tasks.$inferInsert.type;dueAt?:string|null;internalTargetAt?:string|null;priority?:typeof tasks.$inferInsert.priority;estimatedMinutes?:number|null;status?:typeof tasks.$inferInsert.status;progress?:number;source?:typeof tasks.$inferInsert.source;reminders?:number[];subtasks?:{title:string;estimatedMinutes?:number|null}[]}){
  if(input.courseId && !(await getCourse(userId,input.courseId))) throw new Error("COURSE_NOT_FOUND");
  const settings=(await db().select({defaultTaskReminders:userSettings.defaultTaskReminders}).from(userSettings).where(eq(userSettings.userId,userId)).limit(1))[0];
  const reminderOffsets=input.reminders ?? settings?.defaultTaskReminders ?? [10080,4320,1440,360,60];
  const id=randomUUID(), now=new Date().toISOString();
  await db().transaction(async tx=>{
    await tx.insert(tasks).values({id,userId,title:input.title,courseId:input.courseId??null,description:input.description??null,type:input.type??"assignment",dueAt:input.dueAt??null,internalTargetAt:input.internalTargetAt??null,priority:input.priority??"medium",estimatedMinutes:input.estimatedMinutes??null,status:input.status??"NOT_STARTED",progress:input.progress??0,source:input.source??"manual",createdAt:now,updatedAt:now,version:1});
    for(const [i,s] of (input.subtasks??[]).entries()) await tx.insert(subtasks).values({id:randomUUID(),userId,taskId:id,title:s.title,completed:false,orderIndex:i,estimatedMinutes:s.estimatedMinutes??null,createdAt:now,updatedAt:now,version:1});
    if(input.dueAt) for(const offset of [...new Set(reminderOffsets)].sort((a,b)=>b-a)) await tx.insert(taskReminders).values({id:randomUUID(),userId,taskId:id,offsetMinutes:offset,enabled:true,createdAt:now});
  });
  return getTask(userId,id);
}

export async function updateTask(userId:string,id:string,patch:Partial<{title:string;courseId:string|null;description:string|null;type:typeof tasks.$inferInsert.type;dueAt:string|null;internalTargetAt:string|null;priority:typeof tasks.$inferInsert.priority;estimatedMinutes:number|null;status:typeof tasks.$inferInsert.status;progress:number}>){
  const current=await getTask(userId,id); if(!current)return null;
  if(patch.courseId && !(await getCourse(userId,patch.courseId))) return null;
  const now=new Date().toISOString(); const status=patch.status;
  await db().update(tasks).set({...patch,updatedAt:now,version:current.version+1,completedAt:status==="DONE"?now:status&&status!=="DONE"?null:current.completedAt}).where(and(eq(tasks.id,id),eq(tasks.userId,userId)));
  return getTask(userId,id);
}

export async function softDeleteTask(userId:string,id:string){
  const current=await getTask(userId,id); if(!current)return false;
  await db().update(tasks).set({deletedAt:new Date().toISOString(),version:current.version+1}).where(and(eq(tasks.id,id),eq(tasks.userId,userId)));
  return true;
}

export async function listSubtasks(userId:string,taskId:string){
  return db().select().from(subtasks).where(and(eq(subtasks.userId,userId),eq(subtasks.taskId,taskId),isNull(subtasks.deletedAt))).orderBy(asc(subtasks.orderIndex));
}

export async function createSubtask(userId:string,taskId:string,input:{title:string;estimatedMinutes?:number|null;dueAt?:string|null;orderIndex?:number}){
  const owner=await getTask(userId,taskId);if(!owner)return null;
  const now=new Date().toISOString();
  const existing=await listSubtasks(userId,taskId);
  const row={id:randomUUID(),userId,taskId,title:input.title,completed:false,orderIndex:input.orderIndex??existing.length,estimatedMinutes:input.estimatedMinutes??null,dueAt:input.dueAt??null,createdAt:now,updatedAt:now,deletedAt:null,version:1};
  await db().insert(subtasks).values(row);
  return row;
}

export async function updateSubtask(userId:string,taskId:string,subtaskId:string,patch:Partial<{title:string;completed:boolean;orderIndex:number;estimatedMinutes:number|null;dueAt:string|null}>){
  const owner=await getTask(userId,taskId);if(!owner)return null;
  const row=(await db().select().from(subtasks).where(and(eq(subtasks.id,subtaskId),eq(subtasks.taskId,taskId),eq(subtasks.userId,userId),isNull(subtasks.deletedAt))).limit(1))[0];if(!row)return null;
  await db().update(subtasks).set({...patch,updatedAt:new Date().toISOString(),version:row.version+1}).where(and(eq(subtasks.id,subtaskId),eq(subtasks.taskId,taskId),eq(subtasks.userId,userId)));
  const all=await listSubtasks(userId,taskId);const progress=progressFromSubtasks(all);
  if(progress!==null && patch.completed!==undefined) await updateTask(userId,taskId,{progress,status:progress===100?"DONE":owner.status==="DONE"?"IN_PROGRESS":owner.status});
  return (await db().select().from(subtasks).where(and(eq(subtasks.id,subtaskId),eq(subtasks.userId,userId))).limit(1))[0]??null;
}

export async function deleteSubtask(userId:string,taskId:string,subtaskId:string){
  const row=await updateSubtask(userId,taskId,subtaskId,{});if(!row)return false;
  await db().update(subtasks).set({deletedAt:new Date().toISOString(),updatedAt:new Date().toISOString(),version:row.version+1}).where(and(eq(subtasks.id,subtaskId),eq(subtasks.taskId,taskId),eq(subtasks.userId,userId)));
  const all=await listSubtasks(userId,taskId);const progress=progressFromSubtasks(all);if(progress!==null)await updateTask(userId,taskId,{progress});
  return true;
}

export async function setSubtaskCompleted(userId:string,taskId:string,subtaskId:string,completed:boolean){
  const subtask=await updateSubtask(userId,taskId,subtaskId,{completed});if(!subtask)return null;
  const all=await listSubtasks(userId,taskId);return {subtask,progress:progressFromSubtasks(all)};
}

export async function listTaskReminders(userId:string,taskId:string){
  if(!(await getTask(userId,taskId)))return null;
  return db().select().from(taskReminders).where(and(eq(taskReminders.userId,userId),eq(taskReminders.taskId,taskId))).orderBy(desc(taskReminders.offsetMinutes));
}

export async function replaceTaskReminders(userId:string,taskId:string,offsets:number[]){
  if(!(await getTask(userId,taskId)))return null;
  const now=new Date().toISOString();
  await db().transaction(async tx=>{
    await tx.delete(taskReminders).where(and(eq(taskReminders.userId,userId),eq(taskReminders.taskId,taskId)));
    for(const offset of [...new Set(offsets)].sort((a,b)=>b-a)) await tx.insert(taskReminders).values({id:randomUUID(),userId,taskId,offsetMinutes:offset,enabled:true,createdAt:now});
  });
  return listTaskReminders(userId,taskId);
}
