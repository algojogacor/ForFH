import { and, eq, isNull, like, or } from "drizzle-orm";
import { db } from "@/lib/db";
import { courses, exams, files, legalBookmarks, notes, readings, tasks } from "@/lib/db/schema";
export async function universalSearch(userId:string,q:string){const term=`%${q.replaceAll("%","\\%").replaceAll("_","\\_")}%`;const [courseRows,taskRows,noteRows,readingRows,examRows,fileRows,legalRows]=await Promise.all([
 db().select({id:courses.id,title:courses.name,subtitle:courses.code}).from(courses).where(and(eq(courses.userId,userId),like(courses.name,term))).limit(10),
 db().select({id:tasks.id,title:tasks.title,subtitle:tasks.description}).from(tasks).where(and(eq(tasks.userId,userId),isNull(tasks.deletedAt),or(like(tasks.title,term),like(tasks.description,term)))).limit(10),
 db().select({id:notes.id,title:notes.title,subtitle:notes.content}).from(notes).where(and(eq(notes.userId,userId),isNull(notes.deletedAt),or(like(notes.title,term),like(notes.content,term)))).limit(10),
 db().select({id:readings.id,title:readings.title,subtitle:readings.author}).from(readings).where(and(eq(readings.userId,userId),like(readings.title,term))).limit(10),
 db().select({id:exams.id,title:exams.name,subtitle:exams.type}).from(exams).where(and(eq(exams.userId,userId),like(exams.name,term))).limit(10),
 db().select({id:files.id,title:files.name,subtitle:files.mimeType}).from(files).where(and(eq(files.userId,userId),isNull(files.deletedAt),like(files.name,term))).limit(10),
 db().select({id:legalBookmarks.id,title:legalBookmarks.title,subtitle:legalBookmarks.type}).from(legalBookmarks).where(and(eq(legalBookmarks.userId,userId),like(legalBookmarks.title,term))).limit(10),
]);return {courses:courseRows,tasks:taskRows,notes:noteRows,readings:readingRows,exams:examRows,files:fileRows,legal:legalRows};}
