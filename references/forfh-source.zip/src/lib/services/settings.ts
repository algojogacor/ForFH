import { and, eq } from "drizzle-orm";
import { db } from "@/lib/db";
import { userSettings, users } from "@/lib/db/schema";

export async function getSettings(userId: string) {
  const row = (await db().select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1))[0];
  return row ?? null;
}

export async function updateSettings(userId: string, patch: Partial<{
  timezone: string;
  locale: string;
  theme: "system" | "light" | "dark";
  defaultTaskReminders: number[];
  defaultClassReminders: number[];
  primaryClassAlertMinutes: number;
  deadlineBufferMinutes: number;
  aiEnabled: boolean;
}>) {
  const current = await getSettings(userId);
  if (!current) return null;
  await db().update(userSettings).set({ ...patch, updatedAt: new Date().toISOString() }).where(eq(userSettings.userId, userId));
  return getSettings(userId);
}

export async function updateProfile(userId: string, patch: { displayName?: string | null }) {
  await db().update(users).set({ displayName: patch.displayName?.trim() || null, updatedAt: new Date().toISOString() }).where(eq(users.id, userId));
  return (await db().select({ id: users.id, username: users.username, displayName: users.displayName }).from(users).where(eq(users.id, userId)).limit(1))[0] ?? null;
}
