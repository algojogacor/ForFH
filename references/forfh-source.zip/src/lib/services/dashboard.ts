import { and, asc, eq, gt, isNull, lt, ne, or } from "drizzle-orm";
import { db } from "@/lib/db";
import { classSchedules, courses, exams, tasks, userSettings } from "@/lib/db/schema";
import { isoLocalDate, localDateTimeToUtc, zonedParts } from "@/lib/domain/time";
import { nextClassOccurrence } from "@/lib/services/academic";
import { displayTaskStatus } from "@/lib/domain/tasks";

export async function getDashboard(userId:string,now=new Date()){
 const settings=(await db().select().from(userSettings).where(eq(userSettings.userId,userId)).limit(1))[0];const timezone=settings?.timezone??"Asia/Jakarta";
 const scheduleRows=await db().select({id:classSchedules.id,courseId:classSchedules.courseId,courseName:courses.name,color:courses.color,dayOfWeek:classSchedules.dayOfWeek,startTime:classSchedules.startTime,endTime:classSchedules.endTime,room:classSchedules.room,validFrom:classSchedules.validFrom,validUntil:classSchedules.validUntil,enabled:classSchedules.enabled}).from(classSchedules).innerJoin(courses,and(eq(classSchedules.courseId,courses.id),eq(courses.userId,userId))).where(and(eq(classSchedules.userId,userId),eq(classSchedules.enabled,true)));
 const withOccurrence=scheduleRows.map(s=>({...s,occurrence:nextClassOccurrence(s,timezone,now)})).filter(s=>s.occurrence).sort((a,b)=>a.occurrence!.getTime()-b.occurrence!.getTime());
 const local=isoLocalDate(now,timezone);const p=zonedParts(now,timezone);const todayClasses=scheduleRows.filter(s=>((s.dayOfWeek%7)+7)%7===p.weekday && (!s.validFrom||local>=s.validFrom)&&(!s.validUntil||local<=s.validUntil)).sort((a,b)=>a.startTime.localeCompare(b.startTime));
 const allTasks=await db().select().from(tasks).where(and(eq(tasks.userId,userId),isNull(tasks.deletedAt))).orderBy(asc(tasks.dueAt));
 const todayStart=localDateTimeToUtc(local,"00:00",timezone).getTime();const tomorrow=localDateTimeToUtc(new Date(todayStart+36*3600_000).toISOString().slice(0,10),"00:00",timezone).getTime();
 const todayTasks=allTasks.filter(t=>t.status!=="DONE"&&t.dueAt&&Date.parse(t.dueAt)>=todayStart&&Date.parse(t.dueAt)<tomorrow);
 const overdue=allTasks.filter(t=>displayTaskStatus(t.status,t.dueAt,now)==="OVERDUE");
 const nearest=allTasks.filter(t=>t.status!=="DONE"&&t.dueAt&&Date.parse(t.dueAt)>=now.getTime()).sort((a,b)=>Date.parse(a.dueAt!)-Date.parse(b.dueAt!)).slice(0,6);
 const weekEnd=now.getTime()+7*86400_000;const thisWeek=allTasks.filter(t=>t.dueAt&&Date.parse(t.dueAt)>=now.getTime()-86400_000&&Date.parse(t.dueAt)<=weekEnd);const completed=thisWeek.filter(t=>t.status==="DONE").length;
 const upcomingExams=await db().select({id:exams.id,name:exams.name,type:exams.type,examAt:exams.examAt,courseName:courses.name}).from(exams).innerJoin(courses,and(eq(exams.courseId,courses.id),eq(courses.userId,userId))).where(and(eq(exams.userId,userId),gt(exams.examAt,now.toISOString()))).orderBy(asc(exams.examAt)).limit(5);
 return {timezone,nextClass:withOccurrence[0]??null,todayClasses,todayTasks,overdue,nearestDeadlines:nearest,week:{total:thisWeek.length,completed,remaining:thisWeek.length-completed,percent:thisWeek.length?Math.round(completed/thisWeek.length*100):0},upcomingExams};
}
