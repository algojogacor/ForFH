import { randomUUID } from "node:crypto";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/lib/db";
import {
  classSchedules,
  courses,
  notificationDeliveries,
  pushSubscriptions,
  taskReminders,
  tasks,
  userSettings,
} from "@/lib/db/schema";
import { nextClassOccurrence } from "@/lib/services/academic";
import { sendPush } from "@/lib/notifications/push";

const WINDOW_MS = 5 * 60_000;

export function reminderDue(occurrence: Date, offsetMinutes: number, now = new Date()) {
  const target = occurrence.getTime() - offsetMinutes * 60_000;
  return target <= now.getTime() + 30_000 && target > now.getTime() - WINDOW_MS;
}

async function deliveryRow(userId: string, entityType: string, entityId: string, occurrenceAt: string, offset: number) {
  return (await db().select({ id: notificationDeliveries.id, status: notificationDeliveries.status })
    .from(notificationDeliveries)
    .where(and(
      eq(notificationDeliveries.userId, userId),
      eq(notificationDeliveries.entityType, entityType),
      eq(notificationDeliveries.entityId, entityId),
      eq(notificationDeliveries.occurrenceAt, occurrenceAt),
      eq(notificationDeliveries.offsetMinutes, offset),
      eq(notificationDeliveries.channel, "web_push"),
    )).limit(1))[0] ?? null;
}

async function delivered(userId: string, entityType: string, entityId: string, occurrenceAt: string, offset: number) {
  return (await deliveryRow(userId, entityType, entityId, occurrenceAt, offset))?.status === "sent";
}

async function record(userId: string, entityType: string, entityId: string, occurrenceAt: string, offset: number, status: string) {
  const now = new Date().toISOString();
  const existing = await deliveryRow(userId, entityType, entityId, occurrenceAt, offset);
  if (existing) {
    await db().update(notificationDeliveries).set({ status, sentAt: status === "sent" ? now : null }).where(eq(notificationDeliveries.id, existing.id));
    return;
  }
  await db().insert(notificationDeliveries).values({
    id: randomUUID(), userId, entityType, entityId, occurrenceAt, offsetMinutes: offset,
    channel: "web_push", status, sentAt: status === "sent" ? now : null,
  });
}

function offsetLabel(minutes: number) {
  if (minutes >= 1440 && minutes % 1440 === 0) return `${minutes / 1440} hari`;
  if (minutes >= 60 && minutes % 60 === 0) return `${minutes / 60} jam`;
  if (minutes > 60) return `${Math.floor(minutes / 60)} jam ${minutes % 60} menit`;
  return `${minutes} menit`;
}

export async function processReminders(now = new Date()) {
  const activeUsers = await db().selectDistinct({ userId: pushSubscriptions.userId }).from(pushSubscriptions);
  let sent = 0;
  let skipped = 0;

  for (const { userId } of activeUsers) {
    const settings = (await db().select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1))[0];
    const timezone = settings?.timezone ?? "Asia/Jakarta";
    const subscriptions = await db().select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));

    const classRows = await db().select({
      id: classSchedules.id,
      courseName: courses.name,
      dayOfWeek: classSchedules.dayOfWeek,
      startTime: classSchedules.startTime,
      validFrom: classSchedules.validFrom,
      validUntil: classSchedules.validUntil,
      enabled: classSchedules.enabled,
    }).from(classSchedules)
      .innerJoin(courses, and(eq(classSchedules.courseId, courses.id), eq(courses.userId, userId)))
      .where(and(eq(classSchedules.userId, userId), eq(classSchedules.enabled, true)));

    const classOffsets = [settings?.primaryClassAlertMinutes ?? 240, ...(settings?.defaultClassReminders ?? [120, 90, 60, 30, 20])];
    for (const row of classRows) {
      const occurrence = nextClassOccurrence(row, timezone, now);
      if (!occurrence) continue;
      for (const offset of new Set(classOffsets)) {
        if (!reminderDue(occurrence, offset, now)) continue;
        const occurrenceAt = occurrence.toISOString();
        if (await delivered(userId, "class", row.id, occurrenceAt, offset)) { skipped += 1; continue; }
        const ok = (await Promise.all(subscriptions.map((subscription) => sendPush(subscription, {
          title: `Kelas ${row.courseName}`,
          body: `Mulai ${offsetLabel(offset)} lagi.`,
          url: "/jadwal",
          tag: `class-${row.id}-${occurrenceAt}-${offset}`,
        })))).some(Boolean);
        await record(userId, "class", row.id, occurrenceAt, offset, ok ? "sent" : "failed");
        if (ok) sent += 1;
      }
    }

    const taskRows = await db().select({
      id: tasks.id,
      title: tasks.title,
      dueAt: tasks.dueAt,
      status: tasks.status,
      offset: taskReminders.offsetMinutes,
    }).from(taskReminders)
      .innerJoin(tasks, and(eq(taskReminders.taskId, tasks.id), eq(tasks.userId, userId)))
      .where(and(eq(taskReminders.userId, userId), eq(taskReminders.enabled, true), isNull(tasks.deletedAt)));

    for (const task of taskRows) {
      if (!task.dueAt || task.status === "DONE") continue;
      const occurrence = new Date(task.dueAt);
      if (!reminderDue(occurrence, task.offset, now)) continue;
      if (await delivered(userId, "task", task.id, task.dueAt, task.offset)) { skipped += 1; continue; }
      const ok = (await Promise.all(subscriptions.map((subscription) => sendPush(subscription, {
        title: `Deadline: ${task.title}`,
        body: `Deadline ${offsetLabel(task.offset)} lagi.`,
        url: `/tugas/${task.id}`,
        tag: `task-${task.id}-${task.dueAt}-${task.offset}`,
      })))).some(Boolean);
      await record(userId, "task", task.id, task.dueAt, task.offset, ok ? "sent" : "failed");
      if (ok) sent += 1;
    }
  }

  return { sent, skipped, processedUsers: activeUsers.length, at: now.toISOString() };
}
