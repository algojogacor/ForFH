const secretPattern = /(authorization|api[_-]?key|token|secret|password|pepper|private[_-]?key|refresh[_-]?token)/i;

export function redact(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, val]) => [
      key,
      secretPattern.test(key) ? "[REDACTED]" : redact(val),
    ]));
  }
  return value;
}

export function safeLog(message: string, meta?: unknown) {
  if (meta === undefined) return console.info(message);
  console.info(message, redact(meta));
}
