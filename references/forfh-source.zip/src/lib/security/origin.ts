import { env } from "@/lib/env";

export function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return;
  const configured = env().NEXT_PUBLIC_APP_URL;
  const allowed = configured ? new URL(configured).origin : new URL(request.url).origin;
  if (origin !== allowed) throw new Error("FORBIDDEN_ORIGIN");
}
