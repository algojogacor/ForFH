import { z } from "zod";

const emptyToUndefined = (v: unknown) => typeof v === "string" && v.trim() === "" ? undefined : v;
const optionalSecret = z.preprocess(emptyToUndefined, z.string().min(1).optional());
const optionalUrl = z.preprocess(emptyToUndefined, z.string().url().optional());

const serverSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  NEXT_PUBLIC_APP_URL: optionalUrl,
  SESSION_SECRET: optionalSecret,
  PASSWORD_PEPPER: optionalSecret,
  DB_FILE_NAME: z.string().min(1).default("./data/forfh.sqlite"),
  GROQ_API_KEY_1: optionalSecret,
  GROQ_API_KEY_2: optionalSecret,
  GROQ_MODEL: z.string().default("openai/gpt-oss-120b"),
  OLLAMA_API_KEY_1: optionalSecret,
  OLLAMA_API_KEY_2: optionalSecret,
  OLLAMA_MODEL: z.string().default("gpt-oss:120b-cloud"),
  OLLAMA_LAST_RESORT_MODEL: z.string().default("minimax-m3:cloud"),
  PASAL_API_BASE_URL: z.string().url().default("https://pasal.id/api/v1"),
  PASAL_API_TOKEN: optionalSecret,
  QSTASH_URL: optionalUrl,
  QSTASH_TOKEN: optionalSecret,
  QSTASH_CURRENT_SIGNING_KEY: optionalSecret,
  QSTASH_NEXT_SIGNING_KEY: optionalSecret,
  GOOGLE_DRIVE_CLIENT_ID: optionalSecret,
  GOOGLE_DRIVE_CLIENT_SECRET: optionalSecret,
  GOOGLE_DRIVE_REFRESH_TOKEN: optionalSecret,
  GOOGLE_DRIVE_ROOT_FOLDER_ID: optionalSecret,
  NEXT_PUBLIC_VAPID_PUBLIC_KEY: optionalSecret,
  VAPID_PRIVATE_KEY: optionalSecret,
  VAPID_SUBJECT: optionalSecret,
  DEFAULT_USER_STORAGE_QUOTA_MB: z.coerce.number().int().positive().default(512),
  INTERNAL_DIAGNOSTIC_TOKEN: optionalSecret,
});

export type ServerEnv = z.infer<typeof serverSchema>;
let cached: ServerEnv | null = null;

export function env(): ServerEnv {
  if (!cached) cached = serverSchema.parse(process.env);
  return cached;
}

export function requireCoreEnv() {
  const e = env();
  const missing = ["SESSION_SECRET", "PASSWORD_PEPPER"]
    .filter((key) => !e[key as keyof ServerEnv]);
  if (missing.length) throw new Error(`Required server configuration missing: ${missing.join(", ")}`);
  return e as ServerEnv & { SESSION_SECRET: string; PASSWORD_PEPPER: string };
}

export const integrations = () => {
  const e = env();
  return {
    localDatabase: Boolean(e.DB_FILE_NAME),
    groq: Boolean(e.GROQ_API_KEY_1 || e.GROQ_API_KEY_2),
    ollama: Boolean(e.OLLAMA_API_KEY_1 || e.OLLAMA_API_KEY_2),
    pasal: Boolean(e.PASAL_API_TOKEN),
    qstash: Boolean(e.QSTASH_CURRENT_SIGNING_KEY && e.QSTASH_NEXT_SIGNING_KEY),
    drive: Boolean(e.GOOGLE_DRIVE_CLIENT_ID && e.GOOGLE_DRIVE_CLIENT_SECRET && e.GOOGLE_DRIVE_REFRESH_TOKEN),
    push: Boolean(e.NEXT_PUBLIC_VAPID_PUBLIC_KEY && e.VAPID_PRIVATE_KEY && e.VAPID_SUBJECT),
  };
};

export const browserEnv = {
  appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "",
  vapidPublicKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ?? "",
};
