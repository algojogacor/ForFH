import { z } from "zod";

export const usernameSchema = z.string().trim().min(3, "Username minimal 3 karakter.").max(32, "Username maksimal 32 karakter.").regex(/^[\p{L}\p{N}._-]+$/u, "Username hanya boleh berisi huruf, angka, titik, garis bawah, atau tanda hubung.");
export const passwordSchema = z.string().min(8, "Password minimal 8 karakter.").max(256, "Password terlalu panjang.");

export const registerSchema = z.object({
  username: usernameSchema,
  password: passwordSchema,
  confirmPassword: z.string(),
}).superRefine((value, ctx) => {
  if (value.password !== value.confirmPassword) ctx.addIssue({ code: "custom", path: ["confirmPassword"], message: "Konfirmasi password tidak sama." });
});

export const loginSchema = z.object({ username: usernameSchema, password: z.string().min(1) });
export const idSchema = z.string().uuid();
export const isoDateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const timeSchema = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
export const isoDateTimeSchema = z.string().datetime({ offset: true });

export const termSchema = z.object({
  name: z.string().trim().min(1).max(100),
  startDate: isoDateSchema,
  endDate: isoDateSchema,
  isActive: z.boolean().default(true),
});

export const courseSchema = z.object({
  academicTermId: z.string().uuid().nullable().optional(),
  name: z.string().trim().min(1).max(120),
  code: z.string().trim().max(30).nullable().optional(),
  lecturer: z.string().trim().max(120).nullable().optional(),
  credits: z.number().int().min(0).max(24).nullable().optional(),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).nullable().optional(),
  defaultRoom: z.string().trim().max(120).nullable().optional(),
  onlineUrl: z.string().url().nullable().optional(),
  notes: z.string().max(5000).nullable().optional(),
  archived: z.boolean().default(false),
});

export const scheduleSchema = z.object({
  courseId: z.string().uuid(),
  dayOfWeek: z.number().int().min(1).max(7),
  startTime: timeSchema,
  endTime: timeSchema,
  room: z.string().trim().max(120).nullable().optional(),
  onlineUrl: z.string().url().nullable().optional(),
  validFrom: isoDateSchema.nullable().optional(),
  validUntil: isoDateSchema.nullable().optional(),
  enabled: z.boolean().default(true),
});

export const taskTypeSchema = z.enum(["assignment", "essay", "paper", "presentation", "reading", "quiz", "practice", "administrative", "other"]);
export const taskPrioritySchema = z.enum(["low", "medium", "high", "urgent"]);
export const taskStatusSchema = z.enum(["NOT_STARTED", "IN_PROGRESS", "REVISION", "DONE", "OVERDUE"]);
export const taskSourceSchema = z.enum(["manual", "ai", "quick_capture"]);

export const taskSchema = z.object({
  courseId: z.string().uuid().nullable().optional(),
  title: z.string().trim().min(1).max(240),
  description: z.string().max(20000).nullable().optional(),
  type: taskTypeSchema.default("assignment"),
  dueAt: isoDateTimeSchema.nullable().optional(),
  internalTargetAt: isoDateTimeSchema.nullable().optional(),
  priority: taskPrioritySchema.default("medium"),
  estimatedMinutes: z.number().int().positive().max(100000).nullable().optional(),
  status: taskStatusSchema.default("NOT_STARTED"),
  progress: z.number().int().min(0).max(100).default(0),
  source: taskSourceSchema.default("manual"),
  reminders: z.array(z.number().int().positive()).max(10).optional(),
  version: z.number().int().positive().optional(),
});

export const subtaskSchema = z.object({
  title: z.string().trim().min(1).max(240),
  completed: z.boolean().default(false),
  orderIndex: z.number().int().min(0).default(0),
  estimatedMinutes: z.number().int().positive().nullable().optional(),
  dueAt: isoDateTimeSchema.nullable().optional(),
  version: z.number().int().positive().optional(),
});

export const noteSchema = z.object({
  courseId: z.string().uuid().nullable().optional(),
  title: z.string().trim().min(1).max(240),
  content: z.string().max(500000).default(""),
  pinned: z.boolean().default(false),
  version: z.number().int().positive().optional(),
});

export const readingSchema = z.object({
  courseId: z.string().uuid().nullable().optional(),
  fileId: z.string().uuid().nullable().optional(),
  type: z.enum(["book", "journal", "law", "case", "module", "ppt", "other"]).default("other"),
  title: z.string().trim().min(1).max(240),
  author: z.string().trim().max(180).nullable().optional(),
  sourceUrl: z.string().url().nullable().optional(),
  startPage: z.number().int().min(1).nullable().optional(),
  endPage: z.number().int().min(1).nullable().optional(),
  currentPage: z.number().int().min(0).nullable().optional(),
  status: z.enum(["NOT_STARTED", "READING", "DONE"]).default("NOT_STARTED"),
  deadline: isoDateSchema.nullable().optional(),
  notes: z.string().max(10000).nullable().optional(),
});

export const examSchema = z.object({
  courseId: z.string().uuid(),
  name: z.string().trim().min(1).max(160),
  type: z.enum(["UTS", "UAS", "QUIZ", "OTHER"]).default("OTHER"),
  examAt: isoDateTimeSchema,
  location: z.string().trim().max(160).nullable().optional(),
  notes: z.string().max(10000).nullable().optional(),
});

export const examTopicSchema = z.object({
  title: z.string().trim().min(1).max(240),
  completed: z.boolean().default(false),
  orderIndex: z.number().int().min(0).default(0),
});

export const attendanceSchema = z.object({
  courseId: z.string().uuid(),
  classDate: isoDateSchema,
  status: z.enum(["PRESENT", "PERMIT", "SICK", "ABSENT"]),
  notes: z.string().max(2000).nullable().optional(),
});

export const gradeSchema = z.object({
  courseId: z.string().uuid(),
  componentName: z.string().trim().min(1).max(160),
  weight: z.number().int().min(0).max(100).nullable().optional(),
  score: z.number().int().min(0).max(100).nullable().optional(),
  letterGrade: z.string().trim().max(8).nullable().optional(),
  gradePoint: z.number().int().min(0).max(4).nullable().optional(),
});

export const legalBookmarkSchema = z.object({
  courseId: z.string().uuid().nullable().optional(),
  frbrUri: z.string().trim().min(1).max(500),
  title: z.string().trim().min(1).max(500),
  type: z.string().trim().max(80).nullable().optional(),
  number: z.string().trim().max(80).nullable().optional(),
  year: z.number().int().min(1800).max(2200).nullable().optional(),
  userNote: z.string().max(5000).nullable().optional(),
});
