"use client";

const DB_NAME = "forfh-offline";
const DB_VERSION = 2;
const OUTBOX_STORE = "outbox";
const OWNER_KEY = "forfh-offline-owner";

export type OfflineMutation = {
  id: string;
  ownerId: string;
  url: string;
  method: "POST" | "PATCH" | "DELETE";
  body: string | null;
  contentType: string | null;
  createdAt: string;
  attempts: number;
  lastError: string | null;
};

export type MutationResult =
  | { queued: true; response: null }
  | { queued: false; response: Response };

function ensureBrowser() {
  if (typeof window === "undefined" || typeof indexedDB === "undefined") {
    throw new Error("OFFLINE_STORAGE_UNAVAILABLE");
  }
}

function currentOwner() {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(OWNER_KEY);
}

export function setOfflineOwner(userId: string) {
  if (typeof window !== "undefined") window.localStorage.setItem(OWNER_KEY, userId);
}

export function clearOfflineOwner() {
  if (typeof window !== "undefined") window.localStorage.removeItem(OWNER_KEY);
}

function openDb(): Promise<IDBDatabase> {
  ensureBrowser();
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error ?? new Error("OFFLINE_DB_OPEN_FAILED"));
    request.onupgradeneeded = () => {
      const database = request.result;
      let store: IDBObjectStore;
      if (!database.objectStoreNames.contains(OUTBOX_STORE)) {
        store = database.createObjectStore(OUTBOX_STORE, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt", { unique: false });
      } else {
        store = request.transaction!.objectStore(OUTBOX_STORE);
      }
      if (!store.indexNames.contains("ownerId")) store.createIndex("ownerId", "ownerId", { unique: false });
    };
    request.onsuccess = () => resolve(request.result);
  });
}

async function withStore<T>(
  mode: IDBTransactionMode,
  operation: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const database = await openDb();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(OUTBOX_STORE, mode);
    const request = operation(transaction.objectStore(OUTBOX_STORE));
    request.onerror = () => reject(request.error ?? new Error("OFFLINE_DB_REQUEST_FAILED"));
    request.onsuccess = () => resolve(request.result);
    transaction.oncomplete = () => database.close();
    transaction.onerror = () => reject(transaction.error ?? new Error("OFFLINE_DB_TRANSACTION_FAILED"));
  });
}

function emitOutboxChanged() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event("forfh:outbox-changed"));
}

export async function enqueueMutation(input: Omit<OfflineMutation, "id" | "ownerId" | "createdAt" | "attempts" | "lastError">) {
  const ownerId = currentOwner();
  if (!ownerId) throw new Error("OFFLINE_OWNER_UNAVAILABLE");
  const mutation: OfflineMutation = {
    ...input,
    id: crypto.randomUUID(),
    ownerId,
    createdAt: new Date().toISOString(),
    attempts: 0,
    lastError: null,
  };
  await withStore("readwrite", (store) => store.add(mutation));
  emitOutboxChanged();
  return mutation;
}

export async function listOutbox(): Promise<OfflineMutation[]> {
  const ownerId = currentOwner();
  if (!ownerId) return [];
  const rows = await withStore<OfflineMutation[]>("readonly", (store) => store.index("ownerId").getAll(ownerId));
  return rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}

export async function outboxCount() {
  const ownerId = currentOwner();
  if (!ownerId) return 0;
  return withStore<number>("readonly", (store) => store.index("ownerId").count(ownerId));
}

async function removeMutation(id: string) {
  await withStore("readwrite", (store) => store.delete(id));
}

async function markFailure(row: OfflineMutation, error: unknown) {
  const next: OfflineMutation = {
    ...row,
    attempts: row.attempts + 1,
    lastError: error instanceof Error ? error.message.slice(0, 300) : "SYNC_FAILED",
  };
  await withStore("readwrite", (store) => store.put(next));
}

function isNetworkFailure(error: unknown) {
  return error instanceof TypeError || (error instanceof DOMException && error.name === "NetworkError");
}

export async function mutateWithOfflineQueue(url: string, init: RequestInit): Promise<MutationResult> {
  const method = (init.method ?? "POST").toUpperCase();
  if (method !== "POST" && method !== "PATCH" && method !== "DELETE") {
    throw new Error("OFFLINE_MUTATION_METHOD_NOT_ALLOWED");
  }

  const body = typeof init.body === "string" ? init.body : null;
  const headers = new Headers(init.headers);
  const contentType = headers.get("content-type");

  if (typeof navigator !== "undefined" && !navigator.onLine) {
    await enqueueMutation({ url, method, body, contentType });
    return { queued: true, response: null };
  }

  try {
    const response = await fetch(url, { ...init, credentials: "same-origin" });
    return { queued: false, response };
  } catch (error) {
    if (!isNetworkFailure(error)) throw error;
    await enqueueMutation({ url, method, body, contentType });
    return { queued: true, response: null };
  }
}

export type FlushResult = {
  sent: number;
  remaining: number;
  stoppedBecauseAuth: boolean;
};

export async function flushOutbox(): Promise<FlushResult> {
  if (typeof navigator !== "undefined" && !navigator.onLine) {
    return { sent: 0, remaining: await outboxCount(), stoppedBecauseAuth: false };
  }

  const ownerId = currentOwner();
  if (!ownerId) return { sent: 0, remaining: 0, stoppedBecauseAuth: false };

  let sent = 0;
  let stoppedBecauseAuth = false;
  const rows = await listOutbox();

  for (const row of rows) {
    if (row.ownerId !== ownerId) continue;
    try {
      const headers = new Headers();
      if (row.contentType) headers.set("Content-Type", row.contentType);
      const response = await fetch(row.url, {
        method: row.method,
        headers,
        body: row.body,
        credentials: "same-origin",
      });

      if (response.ok || response.status === 404) {
        await removeMutation(row.id);
        sent += 1;
        continue;
      }

      if (response.status === 401 || response.status === 403) {
        stoppedBecauseAuth = true;
        await markFailure(row, new Error(`HTTP_${response.status}`));
        break;
      }

      await markFailure(row, new Error(`HTTP_${response.status}`));
    } catch (error) {
      await markFailure(row, error);
      if (isNetworkFailure(error)) break;
    }
  }

  emitOutboxChanged();
  return { sent, remaining: await outboxCount(), stoppedBecauseAuth };
}
