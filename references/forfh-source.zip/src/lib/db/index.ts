import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { drizzle } from "drizzle-orm/node-sqlite";
import { env } from "@/lib/env";
import * as schema from "@/lib/db/schema";

let cached: ReturnType<typeof drizzle<typeof schema>> | null = null;
let sqliteClient: DatabaseSync | null = null;

function resolveDatabasePath(configuredPath: string) {
  if (configuredPath === ":memory:") return configuredPath;
  return resolve(process.cwd(), configuredPath);
}

export function db() {
  if (cached) return cached;

  const databasePath = resolveDatabasePath(env().DB_FILE_NAME);
  if (databasePath !== ":memory:") {
    mkdirSync(dirname(databasePath), { recursive: true });
  }

  sqliteClient = new DatabaseSync(databasePath, { timeout: 5_000 });
  sqliteClient.exec("PRAGMA foreign_keys = ON;");
  sqliteClient.exec("PRAGMA journal_mode = WAL;");
  sqliteClient.exec("PRAGMA busy_timeout = 5000;");

  cached = drizzle({ client: sqliteClient, schema });
  return cached;
}

export function closeDbForTests() {
  sqliteClient?.close();
  sqliteClient = null;
  cached = null;
}
