import { sql } from "drizzle-orm";
import { index, integer, primaryKey, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

const nowSql = sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`;
const timestamps = {
  createdAt: text("created_at").notNull().default(nowSql),
  updatedAt: text("updated_at").notNull().default(nowSql),
};

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  usernameNormalized: text("username_normalized").notNull(),
  passwordHash: text("password_hash").notNull(),
  displayName: text("display_name"),
  ...timestamps,
}, (t) => [uniqueIndex("users_username_normalized_uq").on(t.usernameNormalized)]);

export const sessions = sqliteTable("sessions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull(),
  createdAt: text("created_at").notNull().default(nowSql),
  expiresAt: text("expires_at").notNull(),
  lastSeenAt: text("last_seen_at").notNull().default(nowSql),
}, (t) => [
  uniqueIndex("sessions_token_hash_uq").on(t.tokenHash),
  index("sessions_user_id_idx").on(t.userId),
  index("sessions_expires_at_idx").on(t.expiresAt),
]);

export const userSettings = sqliteTable("user_settings", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  timezone: text("timezone").notNull().default("Asia/Jakarta"),
  locale: text("locale").notNull().default("id-ID"),
  theme: text("theme", { enum: ["system", "light", "dark"] }).notNull().default("system"),
  defaultTaskReminders: text("default_task_reminders", { mode: "json" }).$type<number[]>().notNull().default(sql`'[10080,4320,1440,360,60]'`),
  defaultClassReminders: text("default_class_reminders", { mode: "json" }).$type<number[]>().notNull().default(sql`'[120,90,60,30,20]'`),
  primaryClassAlertMinutes: integer("primary_class_alert_minutes").notNull().default(240),
  deadlineBufferMinutes: integer("deadline_buffer_minutes").notNull().default(720),
  aiEnabled: integer("ai_enabled", { mode: "boolean" }).notNull().default(true),
  ...timestamps,
}, (t) => [uniqueIndex("user_settings_user_id_uq").on(t.userId)]);

export const academicTerms = sqliteTable("academic_terms", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  ...timestamps,
}, (t) => [index("academic_terms_user_id_idx").on(t.userId)]);

export const courses = sqliteTable("courses", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  academicTermId: text("academic_term_id").references(() => academicTerms.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  code: text("code"),
  lecturer: text("lecturer"),
  credits: integer("credits"),
  color: text("color"),
  defaultRoom: text("default_room"),
  onlineUrl: text("online_url"),
  notes: text("notes"),
  archived: integer("archived", { mode: "boolean" }).notNull().default(false),
  ...timestamps,
}, (t) => [
  index("courses_user_id_idx").on(t.userId),
  index("courses_term_idx").on(t.academicTermId),
]);

export const classSchedules = sqliteTable("class_schedules", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  room: text("room"),
  onlineUrl: text("online_url"),
  validFrom: text("valid_from"),
  validUntil: text("valid_until"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  ...timestamps,
}, (t) => [
  index("class_schedules_user_id_idx").on(t.userId),
  index("class_schedules_course_id_idx").on(t.courseId),
  index("class_schedules_day_idx").on(t.dayOfWeek),
]);

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type", { enum: ["assignment", "essay", "paper", "presentation", "reading", "quiz", "practice", "administrative", "other"] }).notNull().default("assignment"),
  dueAt: text("due_at"),
  internalTargetAt: text("internal_target_at"),
  priority: text("priority", { enum: ["low", "medium", "high", "urgent"] }).notNull().default("medium"),
  estimatedMinutes: integer("estimated_minutes"),
  status: text("status", { enum: ["NOT_STARTED", "IN_PROGRESS", "REVISION", "DONE", "OVERDUE"] }).notNull().default("NOT_STARTED"),
  progress: integer("progress").notNull().default(0),
  source: text("source", { enum: ["manual", "ai", "quick_capture"] }).notNull().default("manual"),
  createdAt: text("created_at").notNull().default(nowSql),
  updatedAt: text("updated_at").notNull().default(nowSql),
  completedAt: text("completed_at"),
  deletedAt: text("deleted_at"),
  version: integer("version").notNull().default(1),
}, (t) => [
  index("tasks_user_id_idx").on(t.userId),
  index("tasks_course_id_idx").on(t.courseId),
  index("tasks_due_at_idx").on(t.dueAt),
  index("tasks_status_idx").on(t.status),
  index("tasks_updated_at_idx").on(t.updatedAt),
]);

export const subtasks = sqliteTable("subtasks", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  completed: integer("completed", { mode: "boolean" }).notNull().default(false),
  orderIndex: integer("order_index").notNull().default(0),
  estimatedMinutes: integer("estimated_minutes"),
  dueAt: text("due_at"),
  createdAt: text("created_at").notNull().default(nowSql),
  updatedAt: text("updated_at").notNull().default(nowSql),
  deletedAt: text("deleted_at"),
  version: integer("version").notNull().default(1),
}, (t) => [index("subtasks_task_id_idx").on(t.taskId), index("subtasks_user_id_idx").on(t.userId)]);

export const taskReminders = sqliteTable("task_reminders", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: text("task_id").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  offsetMinutes: integer("offset_minutes").notNull(),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  createdAt: text("created_at").notNull().default(nowSql),
}, (t) => [index("task_reminders_task_id_idx").on(t.taskId), index("task_reminders_user_idx").on(t.userId)]);

export const notes = sqliteTable("notes", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  format: text("format", { enum: ["markdown"] }).notNull().default("markdown"),
  pinned: integer("pinned", { mode: "boolean" }).notNull().default(false),
  createdAt: text("created_at").notNull().default(nowSql),
  updatedAt: text("updated_at").notNull().default(nowSql),
  deletedAt: text("deleted_at"),
  version: integer("version").notNull().default(1),
}, (t) => [index("notes_user_id_idx").on(t.userId), index("notes_course_id_idx").on(t.courseId), index("notes_updated_idx").on(t.updatedAt)]);

export const files = sqliteTable("files", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  driveFileId: text("drive_file_id").notNull(),
  driveParentFolderId: text("drive_parent_folder_id"),
  name: text("name").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  category: text("category", { enum: ["assignment", "note", "reading", "course_material", "other"] }).notNull().default("other"),
  createdAt: text("created_at").notNull().default(nowSql),
  deletedAt: text("deleted_at"),
}, (t) => [index("files_user_id_idx").on(t.userId), index("files_course_idx").on(t.courseId), uniqueIndex("files_drive_file_id_uq").on(t.driveFileId)]);

export const readings = sqliteTable("readings", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  fileId: text("file_id").references(() => files.id, { onDelete: "set null" }),
  type: text("type", { enum: ["book", "journal", "law", "case", "module", "ppt", "other"] }).notNull().default("other"),
  title: text("title").notNull(),
  author: text("author"),
  sourceUrl: text("source_url"),
  startPage: integer("start_page"),
  endPage: integer("end_page"),
  currentPage: integer("current_page"),
  status: text("status", { enum: ["NOT_STARTED", "READING", "DONE"] }).notNull().default("NOT_STARTED"),
  deadline: text("deadline"),
  notes: text("notes"),
  ...timestamps,
}, (t) => [index("readings_user_id_idx").on(t.userId), index("readings_course_idx").on(t.courseId)]);

export const exams = sqliteTable("exams", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: text("type", { enum: ["UTS", "UAS", "QUIZ", "OTHER"] }).notNull().default("OTHER"),
  examAt: text("exam_at").notNull(),
  location: text("location"),
  notes: text("notes"),
  ...timestamps,
}, (t) => [index("exams_user_id_idx").on(t.userId), index("exams_exam_at_idx").on(t.examAt), index("exams_course_idx").on(t.courseId)]);

export const examTopics = sqliteTable("exam_topics", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  examId: text("exam_id").notNull().references(() => exams.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  completed: integer("completed", { mode: "boolean" }).notNull().default(false),
  orderIndex: integer("order_index").notNull().default(0),
}, (t) => [index("exam_topics_exam_idx").on(t.examId), index("exam_topics_user_idx").on(t.userId)]);

export const attendance = sqliteTable("attendance", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  classDate: text("class_date").notNull(),
  status: text("status", { enum: ["PRESENT", "PERMIT", "SICK", "ABSENT"] }).notNull(),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(nowSql),
}, (t) => [
  uniqueIndex("attendance_course_date_uq").on(t.userId, t.courseId, t.classDate),
  index("attendance_user_idx").on(t.userId),
]);

export const grades = sqliteTable("grades", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
  componentName: text("component_name").notNull(),
  weight: integer("weight"),
  score: integer("score"),
  letterGrade: text("letter_grade"),
  gradePoint: integer("grade_point"),
  ...timestamps,
}, (t) => [index("grades_user_idx").on(t.userId), index("grades_course_idx").on(t.courseId)]);

export const pushSubscriptions = sqliteTable("push_subscriptions", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  createdAt: text("created_at").notNull().default(nowSql),
  lastUsedAt: text("last_used_at"),
}, (t) => [uniqueIndex("push_endpoint_uq").on(t.endpoint), index("push_user_idx").on(t.userId)]);

export const notificationDeliveries = sqliteTable("notification_deliveries", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  occurrenceAt: text("occurrence_at").notNull(),
  offsetMinutes: integer("offset_minutes").notNull(),
  channel: text("channel").notNull(),
  status: text("status").notNull(),
  sentAt: text("sent_at"),
}, (t) => [
  uniqueIndex("notification_delivery_dedupe_uq").on(t.userId, t.entityType, t.entityId, t.occurrenceAt, t.offsetMinutes, t.channel),
  index("notification_delivery_user_idx").on(t.userId),
]);

export const legalBookmarks = sqliteTable("legal_bookmarks", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  frbrUri: text("frbr_uri").notNull(),
  title: text("title").notNull(),
  type: text("type"),
  number: text("number"),
  year: integer("year"),
  userNote: text("user_note"),
  createdAt: text("created_at").notNull().default(nowSql),
}, (t) => [index("legal_bookmarks_user_idx").on(t.userId), uniqueIndex("legal_bookmark_user_frbr_uq").on(t.userId, t.frbrUri)]);

export const aiUsage = sqliteTable("ai_usage", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => users.id, { onDelete: "set null" }),
  provider: text("provider").notNull(),
  accountSlot: integer("account_slot"),
  model: text("model").notNull(),
  requestType: text("request_type").notNull(),
  status: text("status").notNull(),
  httpStatus: integer("http_status"),
  inputTokens: integer("input_tokens"),
  outputTokens: integer("output_tokens"),
  latencyMs: integer("latency_ms"),
  errorClass: text("error_class"),
  createdAt: text("created_at").notNull().default(nowSql),
}, (t) => [index("ai_usage_created_idx").on(t.createdAt), index("ai_usage_provider_idx").on(t.provider), index("ai_usage_slot_idx").on(t.accountSlot)]);

export const authRateLimits = sqliteTable("auth_rate_limits", {
  keyHash: text("key_hash").primaryKey(),
  windowStart: text("window_start").notNull(),
  attemptCount: integer("attempt_count").notNull().default(0),
  blockedUntil: text("blocked_until"),
});

export const appConfig = sqliteTable("app_config", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: text("updated_at").notNull().default(nowSql),
});

export const caseBriefs = sqliteTable("case_briefs", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  court: text("court"),
  caseNumber: text("case_number"),
  chronology: text("chronology"),
  legalIssue: text("legal_issue"),
  legalBasis: text("legal_basis"),
  courtReasoning: text("court_reasoning"),
  decision: text("decision"),
  personalAnalysis: text("personal_analysis"),
  pasalReferences: text("pasal_references", { mode: "json" }).$type<string[]>().notNull().default(sql`'[]'`),
  ...timestamps,
}, (t) => [index("case_briefs_user_idx").on(t.userId), index("case_briefs_course_idx").on(t.courseId)]);

export const lecturerContacts = sqliteTable("lecturer_contacts", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  courseId: text("course_id").references(() => courses.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  email: text("email"),
  notes: text("notes"),
  ...timestamps,
}, (t) => [index("lecturer_contacts_user_idx").on(t.userId)]);
