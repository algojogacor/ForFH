import { NextResponse } from "next/server";
import { AppError, userMessage } from "@/lib/errors";

const knownDomainErrors: Record<string, { status: number; message: string }> = {
  COURSE_NOT_FOUND: { status: 400, message: "Mata kuliah tidak valid atau tidak dapat diakses." },
  TERM_NOT_FOUND: { status: 400, message: "Semester tidak valid atau tidak dapat diakses." },
  FILE_NOT_FOUND: { status: 400, message: "Berkas tidak valid atau tidak dapat diakses." },
};

export function jsonError(error: unknown) {
  if (error instanceof AppError) {
    return NextResponse.json({ error: error.code, message: error.message }, { status: error.status });
  }
  if (error instanceof SyntaxError) {
    return NextResponse.json({ error: "VALIDATION_ERROR", message: "Format JSON tidak valid." }, { status: 400 });
  }
  if (error instanceof Error && knownDomainErrors[error.message]) {
    const mapped = knownDomainErrors[error.message];
    return NextResponse.json({ error: "VALIDATION_ERROR", message: mapped.message }, { status: mapped.status });
  }
  return NextResponse.json({ error: "INTERNAL_ERROR", message: userMessage(error) }, { status: 500 });
}

export function assertSameOrigin(request: Request) {
  if (["GET", "HEAD", "OPTIONS"].includes(request.method)) return;
  const origin = request.headers.get("origin");
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  if (!origin || !host) return;
  const parsed = new URL(origin);
  if (parsed.host !== host) throw new AppError("FORBIDDEN", "Permintaan tidak diizinkan.", 403);
}

export async function parseJson<T>(request: Request): Promise<T> {
  try { return await request.json() as T; }
  catch { throw new AppError("VALIDATION_ERROR", "Format permintaan tidak valid.", 400); }
}
