# ForFH — College OS

ForFH adalah web/PWA akademik personal berbahasa Indonesia yang berfokus pada pertanyaan: **“Sekarang aku harus ngapain?”**

## Stack
- Next.js 16 App Router + TypeScript
- Tailwind CSS
- local SQLite (`node:sqlite`) + Drizzle ORM
- Username/password + server-managed sessions
- Groq GPT OSS 120B, fallback Ollama Cloud
- QStash reminder worker + Web Push/VAPID
- Centralized Google Drive storage
- Pasal.id legal search
- PWA + service-worker cache + IndexedDB outbox

## Local setup
1. `npm install`
2. Copy `.env.example` to `.env.local` and fill only the integrations you want to use.
3. Run `npm run setup:local` to generate missing local security secrets/VAPID keys and initialize `./data/forfh.sqlite`.
4. Run `npm run verify:local`.
5. `npm run dev`

Never commit `.env.local` or provider credentials.

See `docs/` for architecture, deployment, database, AI routing, and build status.

## Quality gates
- `npm run verify:local` works without connecting to Turso and validates the local SQLite/source setup.
- `npm run quality` runs TypeScript, ESLint, Vitest, and the production Next.js build once dependencies are installed.
