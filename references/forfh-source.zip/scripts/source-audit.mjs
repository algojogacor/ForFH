import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, resolve } from "node:path";

const root = process.cwd();
const failures = [];
const textFiles = [];
const ignoredRoots = new Set([".git", "node_modules", ".next", "data"]);

function walk(dir) {
  for (const name of readdirSync(dir)) {
    if (ignoredRoots.has(name)) continue;
    const path = join(dir, name);
    const stat = statSync(path);
    if (stat.isDirectory()) walk(path);
    else if (/\.(ts|tsx|mjs|js|json|md)$/.test(name) || name === ".env.example") textFiles.push(path);
  }
}
walk(root);

const forbiddenDatabaseTokens = ["TURSO_DATABASE_URL", "TURSO_AUTH_TOKEN", "@libsql/client", "drizzle-orm/libsql", "libsql://"];
for (const path of textFiles) {
  if (path.endsWith(`${join("scripts", "source-audit.mjs")}`)) continue;
  if (path.includes(`${join("docs", "DATABASE.md")}`) || path.includes(`${join("docs", "PROJECT_PLAN.md")}`) || path.includes(`${join("docs", "DEPLOYMENT.md")}`) || path.includes(`${join("docs", "BUILD_STATUS.md")}`)) continue;
  const content = readFileSync(path, "utf8");
  for (const token of forbiddenDatabaseTokens) {
    if (content.includes(token)) failures.push(`${path}: forbidden database token ${token}`);
  }
}

const envExample = readFileSync(resolve(root, ".env.example"), "utf8").trim().split(/\r?\n/).filter(Boolean);
for (const line of envExample) {
  if (!/^[A-Z0-9_]+=$/.test(line)) failures.push(`.env.example must contain names only: ${line.split("=")[0]}`);
}

const packageJson = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
if (packageJson.dependencies?.["@libsql/client"]) failures.push("package.json still depends on @libsql/client");
if (!packageJson.dependencies?.["drizzle-orm"]) failures.push("drizzle-orm dependency missing");

const required = [
  "src/lib/db/index.ts",
  "src/lib/offline/client.ts",
  "src/components/offline/offline-status.tsx",
  "tests/domain.test.ts",
  "tests/authorization.integration.test.ts",
  "docs/PROJECT_PLAN.md",
  "docs/BUILD_STATUS.md",
  "docs/ARCHITECTURE.md",
];
for (const file of required) {
  try { statSync(resolve(root, file)); } catch { failures.push(`required file missing: ${file}`); }
}

if (failures.length) {
  console.error("Source audit failed:\n" + failures.map((item) => `- ${item}`).join("\n"));
  process.exit(1);
}
console.log(`Source audit passed (${textFiles.length} text/source files checked).`);
