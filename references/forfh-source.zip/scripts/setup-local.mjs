import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes, generateKeyPairSync } from "node:crypto";

const path = ".env.local";
const existing = existsSync(path) ? readFileSync(path, "utf8") : "";
const map = new Map();
for (const rawLine of existing.split(/\r?\n/)) {
  const line = rawLine.trim();
  if (!line || line.startsWith("#")) continue;
  const i = line.indexOf("=");
  if (i > 0) map.set(line.slice(0, i), line.slice(i + 1));
}
const b64url = (value) => Buffer.from(value).toString("base64url");
if (!map.get("DB_FILE_NAME")) map.set("DB_FILE_NAME", "./data/forfh.sqlite");
if (!map.get("SESSION_SECRET")) map.set("SESSION_SECRET", b64url(randomBytes(48)));
if (!map.get("PASSWORD_PEPPER")) map.set("PASSWORD_PEPPER", b64url(randomBytes(48)));
if (!map.get("NEXT_PUBLIC_APP_URL")) map.set("NEXT_PUBLIC_APP_URL", "http://localhost:3000");

if (!map.get("NEXT_PUBLIC_VAPID_PUBLIC_KEY") || !map.get("VAPID_PRIVATE_KEY")) {
  const { privateKey, publicKey } = generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const pub = publicKey.export({ format: "jwk" });
  const priv = privateKey.export({ format: "jwk" });
  const publicBytes = Buffer.concat([Buffer.from([4]), Buffer.from(pub.x, "base64url"), Buffer.from(pub.y, "base64url")]);
  map.set("NEXT_PUBLIC_VAPID_PUBLIC_KEY", b64url(publicBytes));
  map.set("VAPID_PRIVATE_KEY", priv.d);
}
if (!map.get("VAPID_SUBJECT")) map.set("VAPID_SUBJECT", "mailto:admin@forfh.local");

const preferred = [
  "NEXT_PUBLIC_APP_URL","SESSION_SECRET","PASSWORD_PEPPER","DB_FILE_NAME",
  "GROQ_API_KEY_1","GROQ_API_KEY_2","GROQ_MODEL",
  "OLLAMA_API_KEY_1","OLLAMA_API_KEY_2","OLLAMA_MODEL","OLLAMA_LAST_RESORT_MODEL",
  "PASAL_API_BASE_URL","PASAL_API_TOKEN","QSTASH_URL","QSTASH_TOKEN","QSTASH_CURRENT_SIGNING_KEY","QSTASH_NEXT_SIGNING_KEY",
  "GOOGLE_DRIVE_CLIENT_ID","GOOGLE_DRIVE_CLIENT_SECRET","GOOGLE_DRIVE_REFRESH_TOKEN","GOOGLE_DRIVE_ROOT_FOLDER_ID",
  "NEXT_PUBLIC_VAPID_PUBLIC_KEY","VAPID_PRIVATE_KEY","VAPID_SUBJECT","DEFAULT_USER_STORAGE_QUOTA_MB","INTERNAL_DIAGNOSTIC_TOKEN"
];
const seen = new Set();
const out = ["# Local-only secrets/config. Never commit this file."];
for (const key of preferred) {
  if (!map.has(key)) continue;
  out.push(`${key}=${map.get(key)}`); seen.add(key);
}
for (const [key, value] of map) if (!seen.has(key)) out.push(`${key}=${value}`);
writeFileSync(path, out.join("\n") + "\n", { mode: 0o600 });
console.log("Local environment initialized. Secret values were not printed.");
