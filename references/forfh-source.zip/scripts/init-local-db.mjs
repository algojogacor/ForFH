import { mkdirSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

const configured = process.env.DB_FILE_NAME || "./data/forfh.sqlite";
const databasePath = configured === ":memory:" ? configured : resolve(process.cwd(), configured);
if (databasePath !== ":memory:") mkdirSync(dirname(databasePath), { recursive: true });

const sqlite = new DatabaseSync(databasePath, { timeout: 5_000 });
sqlite.exec("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;");
const migration = readFileSync(resolve(process.cwd(), "drizzle/0000_initial.sql"), "utf8");
sqlite.exec(migration);
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS __forfh_migrations (
    version TEXT PRIMARY KEY NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
  INSERT OR IGNORE INTO __forfh_migrations(version) VALUES ('0000_initial');
`);

const tableCount = sqlite.prepare("SELECT count(*) AS count FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").get().count;
sqlite.close();
console.log(`Local SQLite ready (${tableCount} tables).`);
