import { DatabaseSync } from "node:sqlite";
import { resolve } from "node:path";

const file = resolve(process.cwd(), process.env.DB_FILE_NAME || "./data/forfh.sqlite");
const sqlite = new DatabaseSync(file, { readOnly: true, timeout: 5_000 });
const requiredTables = [
  "users", "sessions", "user_settings", "academic_terms", "courses", "class_schedules",
  "tasks", "subtasks", "task_reminders", "notes", "readings", "exams", "attendance",
  "grades", "files", "push_subscriptions", "notification_deliveries", "legal_bookmarks", "ai_usage",
];
const rows = sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
const names = new Set(rows.map((row) => row.name));
const missing = requiredTables.filter((name) => !names.has(name));
const integrity = sqlite.prepare("PRAGMA integrity_check").get().integrity_check;
sqlite.close();

if (missing.length) {
  console.error(`Missing local SQLite tables: ${missing.join(", ")}`);
  process.exit(1);
}
if (integrity !== "ok") {
  console.error(`SQLite integrity check failed: ${integrity}`);
  process.exit(1);
}
console.log(`Local SQLite verified (${requiredTables.length} required tables, integrity ok).`);
