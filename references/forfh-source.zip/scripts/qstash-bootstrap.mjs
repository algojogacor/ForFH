import { Client } from "@upstash/qstash";
const token=process.env.QSTASH_TOKEN;const appUrl=process.env.NEXT_PUBLIC_APP_URL;
if(!token||!appUrl){console.error("QSTASH_TOKEN dan NEXT_PUBLIC_APP_URL wajib tersedia.");process.exit(1)}
const client=new Client({token});const destination=`${appUrl.replace(/\/$/,"")}/api/internal/reminders/process`;
const existing=await client.schedules.list();const match=existing.find((s)=>s.destination===destination);
if(match){console.log("Jadwal reminder QStash sudah ada.");process.exit(0)}
const created=await client.schedules.create({destination,cron:"*/5 * * * *",body:JSON.stringify({source:"forfh-reminder-worker"}),headers:{"Content-Type":"application/json"}});
console.log(`Jadwal reminder dibuat: ${created.scheduleId}`);
