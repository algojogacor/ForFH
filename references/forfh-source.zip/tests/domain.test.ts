import { describe, expect, it } from "vitest";
import { displayTaskStatus, progressFromSubtasks } from "@/lib/domain/tasks";
import { addLocalDays, humanCountdown, isoLocalDate, localDateTimeToUtc, zonedParts } from "@/lib/domain/time";
import { normalizeUsername } from "@/lib/auth/username";

describe("task domain", () => {
  it("marks unfinished past-due tasks overdue without mutating DONE", () => {
    const now = new Date("2026-08-10T12:00:00.000Z");
    expect(displayTaskStatus("IN_PROGRESS", "2026-08-10T11:00:00.000Z", now)).toBe("OVERDUE");
    expect(displayTaskStatus("DONE", "2026-08-10T11:00:00.000Z", now)).toBe("DONE");
  });

  it("derives progress from subtasks", () => {
    expect(progressFromSubtasks([])).toBeNull();
    expect(progressFromSubtasks([{ completed: true }, { completed: false }, { completed: true }])).toBe(67);
  });
});

describe("Asia/Jakarta time handling", () => {
  it("converts Jakarta local time to UTC", () => {
    const utc = localDateTimeToUtc("2026-08-10", "23:00", "Asia/Jakarta");
    expect(utc.toISOString()).toBe("2026-08-10T16:00:00.000Z");
    const parts = zonedParts(utc, "Asia/Jakarta");
    expect(parts.hour).toBe(23);
    expect(isoLocalDate(utc, "Asia/Jakarta")).toBe("2026-08-10");
  });

  it("adds local calendar days deterministically", () => {
    expect(addLocalDays("2026-12-31", 1)).toBe("2027-01-01");
    expect(humanCountdown(90)).toBe("1 jam 30 menit lagi");
  });
});

describe("username normalization", () => {
  it("normalizes case, whitespace, and compatibility forms", () => {
    expect(normalizeUsername("  Arya.Pratama  ")).toBe("arya.pratama");
    expect(normalizeUsername("ＡＲＹＡ")).toBe("arya");
  });
});
