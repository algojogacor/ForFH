import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";

let root = "";
let userA: { id: string };
let userB: { id: string };
let courseA: { id: string };
let taskA: { id: string };
let noteA: { id: string };

let getTask: typeof import("@/lib/services/tasks").getTask;
let updateTask: typeof import("@/lib/services/tasks").updateTask;
let softDeleteTask: typeof import("@/lib/services/tasks").softDeleteTask;
let createTask: typeof import("@/lib/services/tasks").createTask;
let getNote: typeof import("@/lib/services/notes").getNote;
let updateNote: typeof import("@/lib/services/notes").updateNote;
let deleteNote: typeof import("@/lib/services/notes").deleteNote;
let createNote: typeof import("@/lib/services/notes").createNote;
let closeDbForTests: typeof import("@/lib/db").closeDbForTests;

beforeAll(async () => {
  root = mkdtempSync(join(tmpdir(), "forfh-authz-"));
  const databaseFile = join(root, "test.sqlite");
  process.env.DB_FILE_NAME = databaseFile;
  process.env.SESSION_SECRET = "test-session-secret-that-is-long-enough";
  process.env.PASSWORD_PEPPER = "test-password-pepper-that-is-different";
  process.env.NODE_ENV = "test";

  const sqlite = new DatabaseSync(databaseFile);
  sqlite.exec(readFileSync(join(process.cwd(), "drizzle/0000_initial.sql"), "utf8"));
  sqlite.close();

  const auth = await import("@/lib/services/auth");
  const academic = await import("@/lib/services/academic");
  const tasks = await import("@/lib/services/tasks");
  const notes = await import("@/lib/services/notes");
  ({ closeDbForTests } = await import("@/lib/db"));

  userA = await auth.registerUser("user-a", "password-a-123");
  userB = await auth.registerUser("user-b", "password-b-123");
  courseA = (await academic.createCourse(userA.id, { name: "Hukum Pidana", archived: false }))!;
  taskA = (await tasks.createTask(userA.id, { title: "Analisis putusan", courseId: courseA.id }))!;
  noteA = (await notes.createNote(userA.id, { title: "Catatan A", courseId: courseA.id }))!;

  ({ getTask, updateTask, softDeleteTask, createTask } = tasks);
  ({ getNote, updateNote, deleteNote, createNote } = notes);
});

afterAll(() => {
  closeDbForTests?.();
  if (root) rmSync(root, { recursive: true, force: true });
});

describe("cross-user authorization", () => {
  it("does not expose another user's task by ID", async () => {
    expect(await getTask(userB.id, taskA.id)).toBeNull();
    expect(await updateTask(userB.id, taskA.id, { title: "stolen" })).toBeNull();
    expect(await softDeleteTask(userB.id, taskA.id)).toBe(false);
    expect((await getTask(userA.id, taskA.id))?.title).toBe("Analisis putusan");
  });

  it("does not expose another user's note by ID", async () => {
    expect(await getNote(userB.id, noteA.id)).toBeNull();
    expect(await updateNote(userB.id, noteA.id, { title: "stolen" })).toBeNull();
    expect(await deleteNote(userB.id, noteA.id)).toBe(false);
    expect((await getNote(userA.id, noteA.id))?.title).toBe("Catatan A");
  });

  it("rejects cross-user course relationships", async () => {
    await expect(createTask(userB.id, { title: "invalid", courseId: courseA.id })).rejects.toThrow("COURSE_NOT_FOUND");
    await expect(createNote(userB.id, { title: "invalid", courseId: courseA.id })).rejects.toThrow("COURSE_NOT_FOUND");
  });
});
