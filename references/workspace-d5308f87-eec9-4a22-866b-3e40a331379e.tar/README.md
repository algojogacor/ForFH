# ForFH — College OS

A personal academic operating system ("College OS") for Indonesian university students (initially designed around an undergraduate law student's workflow). Built as a **single-route PWA** that answers the core question:

> **"Sekarang aku harus ngapain?"**

## Status: Core V1 functional & QA-verified

- ✅ Username/password auth with scrypt + pepper, server sessions, rate limiting
- ✅ Multi-user data isolation (verified: User B cannot read User A's data by ID)
- ✅ Academic terms, courses, weekly class schedules
- ✅ Dashboard (next class, today's classes, today's tasks, overdue, deadlines, week progress, upcoming exams, AI insight)
- ✅ Task manager (subtasks, status, progress, priority, deadlines, AI breakdown)
- ✅ Markdown notes with autosave
- ✅ Calendar (weekly grid + agenda)
- ✅ Readings tracker, Exams with topics
- ✅ Universal search (local)
- ✅ Legal search via Pasal.id + AI explanation (grounded)
- ✅ Quick Capture: natural-language → AI → structured task → user confirms → save
- ✅ AI: Quick Capture parsing, task breakdown, smart deadline, today insight, legal explain (via z-ai-web-dev-sdk)
- ✅ PWA: manifest, service worker, icons, installable
- ✅ Settings: profile, theme (light/dark/system), timezone, reminders, AI toggle

## Stack

- **Framework**: Next.js 16 (App Router) + TypeScript 5
- **DB**: Prisma + SQLite (local file). Schema designed to port to Turso/libSQL (Drizzle) — see docs/DATABASE.md.
- **Styling**: Tailwind CSS 4 + shadcn/ui (New York), academic emerald palette
- **AI**: z-ai-web-dev-sdk (the available AI capability in this env). Provider abstraction in `src/lib/ai/` documents Groq/Ollama slot-rotation architecture for future wiring.
- **State**: Zustand (UI) + TanStack Query (server)
- **PWA**: manifest.webmanifest + sw.js (app-shell cache, network-first nav, stale-while-revalidate assets)

## Architecture

Single user-visible route `/` (per environment constraint). The page is a server component that checks the session and renders `<AppRoot>` (client), which switches between:
- `<AuthScreen>` (login/register) when unauthenticated
- `<AppShell>` (sidebar + bottom nav + view switching) when authenticated

All data flows through API Route Handlers under `/api/*`. Every user-owned query includes `userId` from the validated session — never trusts a client-supplied `userId`.

```
src/
  app/
    page.tsx                 # server: session check → AppRoot
    layout.tsx              # theme + query providers + SW register
    api/
      auth/{register,login,logout,me}/route.ts
      terms/, courses/, schedules/, tasks/, subtasks/, notes/
      exams/, readings/, dashboard/, search/
      ai/{quick-capture,breakdown,smart-deadline,insight,legal-explain}/
      legal/{search,detail,bookmarks}/
      settings/, onboarding/, push/ (planned)
  components/
    app-root.tsx, app-shell.tsx, auth-screen.tsx
    views/{dashboard,calendar,tasks,courses,notes,readings,exams,legal,settings}-view.tsx
    task-dialog.tsx, quick-capture-dialog.tsx, onboarding-dialog.tsx, search-dialog.tsx
  lib/
    db.ts, env.ts, crypto.ts, session.ts, api.ts, rate-limit.ts
    date.ts, constants.ts, types.ts, store.ts, fetch.ts, hooks.ts
    ai/{provider,prompts}.ts
  prisma/schema.prisma
  public/{manifest.webmanifest, sw.js, icon.svg, icon-192.png, icon-512.png}
```

## Security

- Passwords: scrypt + per-user salt + server `PASSWORD_PEPPER` (constant-time compare)
- Sessions: random 32-byte token; DB stores SHA-256 hash; `forfh-session` cookie (HttpOnly, SameSite=Lax, Secure in prod)
- Rate limiting: Turso/SQLite-backed `AuthRateLimit` table (login/register/AI endpoints)
- Authorization: every query `findFirst({ where: { id, userId } })` — cross-user access returns 404
- Secrets: never exposed to client; `NEXT_PUBLIC_*` only for VAPID public key + app URL
- AI prompt injection: source content (legal text) treated as data, system prompt forbids following embedded instructions

## Local dev

```bash
bun run dev      # port 3000
bun run lint
bun run db:push  # apply schema
```

See `docs/` for PROJECT_PLAN, ARCHITECTURE, DATABASE, ENVIRONMENT, AI_ROUTING, BUILD_STATUS.
