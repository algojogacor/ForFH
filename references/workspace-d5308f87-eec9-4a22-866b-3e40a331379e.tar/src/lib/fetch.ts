"use client";

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(code: string, message: string, status: number) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

export async function fetchApi<T = unknown>(
  path: string,
  opts?: RequestInit & { json?: unknown },
): Promise<T> {
  const { json, ...rest } = opts ?? {};
  const headers: Record<string, string> = { ...(rest.headers as Record<string, string>) };
  let body = rest.body;
  if (json !== undefined) {
    headers["content-type"] = "application/json";
    body = JSON.stringify(json);
  }
  const res = await fetch(path, { ...rest, headers, body, credentials: "same-origin" });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    if (res.status === 401) {
      // Trigger global auth reset
      window.dispatchEvent(new CustomEvent("forfh:unauthorized"));
    }
    throw new ApiError(data?.error ?? "INTERNAL_ERROR", data?.message ?? "Gagal memuat data.", res.status);
  }
  return data as T;
}
