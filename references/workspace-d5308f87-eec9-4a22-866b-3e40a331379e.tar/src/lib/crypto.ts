import { scrypt as _scrypt, randomBytes, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { env } from "./env";

const scrypt = promisify(_scrypt) as (
  password: Buffer | string,
  salt: Buffer,
  keylen: number,
  options?: { N?: number; r?: number; p?: number; maxmem?: number },
) => Promise<Buffer>;

const SCRYPT_KEYLEN = 64;
const SCRYPT_PARAMS = { N: 16384, r: 16, p: 1, maxmem: 128 * 1024 * 1024 };

/** Hash a password with scrypt + per-user salt + server pepper. Returns "scrypt:salt:hash". */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const peppered = Buffer.concat([Buffer.from(password, "utf8"), Buffer.from(env.PASSWORD_PEPPER, "utf8")]);
  const hash = await scrypt(peppered, salt, SCRYPT_KEYLEN, SCRYPT_PARAMS);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

/** Verify a password against a stored "scrypt$salt$hash" string. Constant-time. */
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const salt = Buffer.from(parts[1], "hex");
  const expected = Buffer.from(parts[2], "hex");
  const peppered = Buffer.concat([Buffer.from(password, "utf8"), Buffer.from(env.PASSWORD_PEPPER, "utf8")]);
  const hash = await scrypt(peppered, salt, SCRYPT_KEYLEN, SCRYPT_PARAMS);
  if (hash.length !== expected.length) return false;
  return timingSafeEqual(hash, expected);
}

/** High-entropy random session token (raw, returned to caller; DB stores hash). */
export function generateSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

/** SHA-256 hash of session token for DB storage. */
export async function hashSessionToken(token: string): Promise<string> {
  const { createHash } = await import("node:crypto");
  return createHash("sha256").update(token).digest("hex");
}

/** Normalize a username for uniqueness checks (lowercase, trim). */
export function normalizeUsername(username: string): string {
  return username.trim().toLowerCase().replace(/\s+/g, "");
}

export const SESSION_COOKIE = "forfh-session";
export const SESSION_MAX_AGE_DAYS = 30;
