import { db } from "./db";

const WINDOW_MS = 15 * 60 * 1000; // 15 min
const MAX_ATTEMPTS = 8;
const BLOCK_MS = 15 * 60 * 1000;

function hashKey(key: string): string {
  // Lightweight non-cryptographic-ish hash for the key (do not store raw identifier).
  let h = 0;
  for (let i = 0; i < key.length; i++) {
    h = (h * 31 + key.charCodeAt(i)) >>> 0;
  }
  return `k${h.toString(16)}`;
}

/** Record an attempt for an auth action; returns whether the caller is currently blocked. */
export async function authRateLimit(key: string): Promise<{ blocked: boolean; retryAfterSec: number }> {
  const keyHash = hashKey(key);
  const now = new Date();
  const record = await db.authRateLimit.findUnique({ where: { keyHash } });

  if (record?.blockedUntil && record.blockedUntil > now) {
    const retryAfterSec = Math.ceil((record.blockedUntil.getTime() - now.getTime()) / 1000);
    return { blocked: true, retryAfterSec };
  }

  const windowStart = record && record.windowStart.getTime() + WINDOW_MS > now.getTime() ? record.windowStart : now;
  const attemptCount = (record && record.windowStart.getTime() + WINDOW_MS > now.getTime()) ? record.attemptCount + 1 : 1;
  const blockedUntil = attemptCount >= MAX_ATTEMPTS ? new Date(now.getTime() + BLOCK_MS) : null;

  await db.authRateLimit.upsert({
    where: { keyHash },
    update: { windowStart, attemptCount, blockedUntil },
    create: { keyHash, windowStart, attemptCount, blockedUntil },
  });

  return { blocked: false, retryAfterSec: 0 };
}

/** Reset attempt counter on success. */
export async function clearAuthRateLimit(key: string): Promise<void> {
  const keyHash = hashKey(key);
  await db.authRateLimit.delete({ where: { keyHash } }).catch(() => {});
}
