import "server-only";
import webpush from "web-push";
import { env, features } from "@/lib/env";

let configured = false;

function ensureConfigured() {
  if (configured) return;
  if (!features.vapid) return;
  webpush.setVapidDetails(env.VAPID_SUBJECT, process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY!, env.VAPID_PRIVATE_KEY!);
  configured = true;
}

export type PushPayload = {
  title: string;
  body: string;
  url?: string;
  tag?: string;
};

export async function sendPushNotification(
  subscription: { endpoint: string; p256dh: string; auth: string },
  payload: PushPayload,
): Promise<{ success: boolean; gone?: boolean; error?: string }> {
  if (!features.vapid) return { success: false, error: "VAPID_NOT_CONFIGURED" };
  ensureConfigured();
  try {
    await webpush.sendNotification(
      { endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } },
      JSON.stringify(payload),
      { TTL: 60 * 60 * 24 }, // 24h
    );
    return { success: true };
  } catch (e: unknown) {
    const status = (e as { statusCode?: number }).statusCode;
    if (status === 404 || status === 410) return { success: false, gone: true };
    return { success: false, error: (e as Error).message };
  }
}
