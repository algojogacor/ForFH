"use client";

// Client-safe feature flags. Server-side `features` (in env.ts) is the source of truth
// for actual availability; these are UI hints derived from build-time config.
// AI is always available in this environment via z-ai-web-dev-sdk.

export const features = {
  ai: true,
  pasal: Boolean(process.env.NEXT_PUBLIC_PASAL_ENABLED ?? true),
  qstash: Boolean(process.env.NEXT_PUBLIC_QSTASH_ENABLED ?? true),
  drive: Boolean(process.env.NEXT_PUBLIC_DRIVE_ENABLED ?? true),
  vapid: Boolean(process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY),
};
