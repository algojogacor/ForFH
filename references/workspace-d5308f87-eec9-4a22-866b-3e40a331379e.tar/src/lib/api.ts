import { NextResponse } from "next/server";
import { ZodError } from "zod";

export type ApiError =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "VALIDATION_ERROR"
  | "NOT_FOUND"
  | "CONFLICT"
  | "RATE_LIMITED"
  | "AI_PROVIDER_UNAVAILABLE"
  | "DRIVE_UPLOAD_FAILED"
  | "PASAL_RATE_LIMITED"
  | "FEATURE_NOT_CONFIGURED"
  | "INTERNAL_ERROR";

const statusMap: Record<ApiError, number> = {
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  VALIDATION_ERROR: 400,
  NOT_FOUND: 404,
  CONFLICT: 409,
  RATE_LIMITED: 429,
  AI_PROVIDER_UNAVAILABLE: 503,
  DRIVE_UPLOAD_FAILED: 502,
  PASAL_RATE_LIMITED: 429,
  FEATURE_NOT_CONFIGURED: 501,
  INTERNAL_ERROR: 500,
};

export function apiError(code: ApiError, message?: string, extra?: Record<string, unknown>) {
  return NextResponse.json(
    { error: code, message: message ?? code, ...extra },
    { status: statusMap[code] },
  );
}

export function apiOk(data: unknown, status = 200) {
  return NextResponse.json(data, { status });
}

export function parseZod<T>(schema: { safeParse: (v: unknown) => { success: true; data: T } | { success: false; error: ZodError } }, value: unknown): { ok: true; data: T } | { ok: false; res: ReturnType<typeof apiError> } {
  const r = schema.safeParse(value);
  if (r.success) return { ok: true, data: r.data };
  return { ok: false, res: apiError("VALIDATION_ERROR", r.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")) };
}

/** Ensure a server error is typed and never leaks secrets. */
export function handleApiError(e: unknown) {
  const msg = e instanceof Error ? e.message : String(e);
  if (msg === "UNAUTHORIZED") return apiError("UNAUTHORIZED", "Sesi tidak valid. Silakan masuk kembali.");
  if (msg === "FORBIDDEN") return apiError("FORBIDDEN", "Anda tidak memiliki akses ke sumber daya ini.");
  console.error("[api:error]", msg);
  return apiError("INTERNAL_ERROR", "Terjadi kesalahan. Coba lagi nanti.");
}
