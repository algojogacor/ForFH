import { z } from "zod";

/**
 * Server-only environment validation.
 * Browser-safe env is exported separately via `publicEnv`.
 * Never import this on the client.
 */

const serverEnvSchema = z.object({
  DATABASE_URL: z.string().min(1),
  SESSION_SECRET: z.string().min(32, "SESSION_SECRET must be >= 32 chars"),
  PASSWORD_PEPPER: z.string().min(32, "PASSWORD_PEPPER must be >= 32 chars"),

  // Optional integrations - missing = "not configured" state, not crash.
  TURSO_DATABASE_URL: z.string().optional(),
  TURSO_AUTH_TOKEN: z.string().optional(),

  GROQ_API_KEY_1: z.string().optional(),
  GROQ_API_KEY_2: z.string().optional(),
  GROQ_MODEL: z.string().default("openai/gpt-oss-120b"),

  OLLAMA_API_KEY_1: z.string().optional(),
  OLLAMA_API_KEY_2: z.string().optional(),
  OLLAMA_MODEL: z.string().default("gpt-oss:120b-cloud"),
  OLLAMA_LAST_RESORT_MODEL: z.string().default("minimax-m3:cloud"),

  PASAL_API_BASE_URL: z.string().default("https://pasal.id/api/v1"),
  PASAL_API_TOKEN: z.string().optional(),

  QSTASH_URL: z.string().optional(),
  QSTASH_TOKEN: z.string().optional(),
  QSTASH_CURRENT_SIGNING_KEY: z.string().optional(),
  QSTASH_NEXT_SIGNING_KEY: z.string().optional(),

  GOOGLE_DRIVE_CLIENT_ID: z.string().optional(),
  GOOGLE_DRIVE_CLIENT_SECRET: z.string().optional(),
  GOOGLE_DRIVE_REFRESH_TOKEN: z.string().optional(),
  GOOGLE_DRIVE_ROOT_FOLDER_ID: z.string().optional(),

  VAPID_PRIVATE_KEY: z.string().optional(),
  VAPID_SUBJECT: z.string().default("mailto:admin@forfh.app"),

  DEFAULT_USER_STORAGE_QUOTA_MB: z.coerce.number().default(200),

  NODE_ENV: z.string().default("development"),
});

export type ServerEnv = z.infer<typeof serverEnvSchema>;

function loadServerEnv(): ServerEnv {
  const parsed = serverEnvSchema.safeParse(process.env);
  if (!parsed.success) {
    // Only the critical vars (DATABASE_URL, SESSION_SECRET, PASSWORD_PEPPER) cause hard failure.
    const critical = parsed.error.issues.filter(
      (i) => ["DATABASE_URL", "SESSION_SECRET", "PASSWORD_PEPPER"].includes(i.path[0] as string),
    );
    if (critical.length > 0) {
      console.error("[env] Critical server env missing:", critical.map((c) => c.path.join(".")));
      throw new Error(`Critical server environment misconfigured: ${critical.map((c) => c.path.join(".")).join(", ")}`);
    }
    // Non-critical: log warnings, continue.
    console.warn("[env] Optional integration env not configured:", parsed.error.issues.map((i) => i.path.join(".")));
    // Build a partial env with defaults for optionals.
    return process.env as unknown as ServerEnv;
  }
  return parsed.data;
}

export const env = loadServerEnv();

/** Browser-safe, non-secret env exposed to client. */
export const publicEnv = {
  APP_URL: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
  VAPID_PUBLIC_KEY: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY ?? "",
};

/** Feature availability flags (server-only, derived). */
export const features = {
  ai: Boolean(env.GROQ_API_KEY_1 || env.GROQ_API_KEY_2 || env.OLLAMA_API_KEY_1 || env.OLLAMA_API_KEY_2),
  pasal: Boolean(env.PASAL_API_TOKEN),
  qstash: Boolean(env.QSTASH_TOKEN && env.QSTASH_CURRENT_SIGNING_KEY),
  drive: Boolean(env.GOOGLE_DRIVE_REFRESH_TOKEN && env.GOOGLE_DRIVE_CLIENT_ID),
  vapid: Boolean(env.VAPID_PRIVATE_KEY && publicEnv.VAPID_PUBLIC_KEY),
};
