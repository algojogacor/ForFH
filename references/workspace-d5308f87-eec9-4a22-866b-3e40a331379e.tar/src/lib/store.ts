"use client";

import { create } from "zustand";
import type { User, View } from "@/lib/types";

type AppState = {
  user: User | null;
  setUser: (u: User | null) => void;
  view: View;
  setView: (v: View) => void;
  activeCourseId: string | null;
  setActiveCourseId: (id: string | null) => void;
  activeTaskId: string | null;
  setActiveTaskId: (id: string | null) => void;
  activeNoteId: string | null;
  setActiveNoteId: (id: string | null) => void;
  quickCaptureOpen: boolean;
  setQuickCaptureOpen: (open: boolean) => void;
  onboardingOpen: boolean;
  setOnboardingOpen: (open: boolean) => void;
};

export const useApp = create<AppState>((set) => ({
  user: null,
  setUser: (u) => set({ user: u }),
  view: "dashboard",
  setView: (v) => set({ view: v }),
  activeCourseId: null,
  setActiveCourseId: (id) => set({ activeCourseId: id }),
  activeTaskId: null,
  setActiveTaskId: (id) => set({ activeTaskId: id }),
  activeNoteId: null,
  setActiveNoteId: (id) => set({ activeNoteId: id }),
  quickCaptureOpen: false,
  setQuickCaptureOpen: (open) => set({ quickCaptureOpen: open }),
  onboardingOpen: false,
  setOnboardingOpen: (open) => set({ onboardingOpen: open }),
}));
