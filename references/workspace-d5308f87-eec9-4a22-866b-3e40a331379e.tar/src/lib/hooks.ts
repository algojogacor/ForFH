"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi } from "@/lib/fetch";
import type { Dashboard } from "@/lib/types";
import { apiKeys } from "@/lib/query-keys";

export function useDashboard() {
  return useQuery({
    queryKey: apiKeys.dashboard(),
    queryFn: () => fetchApi<Dashboard>("/api/dashboard"),
    refetchInterval: 60_000,
  });
}

export function useInvalidateDashboard() {
  const qc = useQueryClient();
  return () => {
    qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
    qc.invalidateQueries({ queryKey: apiKeys.tasks() });
    qc.invalidateQueries({ queryKey: apiKeys.calendar() });
  };
}

export function useMutationWithInvalidate<T, V = unknown>(
  fn: (vars: V) => Promise<T>,
  keysToInvalidate: string[][],
) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: () => {
      keysToInvalidate.forEach((k) => qc.invalidateQueries({ queryKey: k }));
    },
  });
}
