import type { TaskStatus } from "@/lib/types";

/** Get the day-of-week (0=Sun..6=Sat) in Asia/Jakarta timezone for a given Date. */
export function jakartaDow(date: Date = new Date()): number {
  const short = new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "Asia/Jakarta" }).format(date);
  return ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(short);
}

/** Get the date string (YYYY-MM-DD) in Asia/Jakarta timezone for a given Date. */
export function jakartaDateKey(date: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", year: "numeric", month: "2-digit", day: "2-digit" }).format(date);
}

/** Compute display status, deriving OVERDUE dynamically. */
export function displayStatus(status: TaskStatus, dueAt: string | null, now = new Date()): TaskStatus {
  if (status === "DONE") return "DONE";
  if (dueAt && new Date(dueAt) < now) return "OVERDUE";
  return status;
}

/** Minutes remaining until a datetime (negative = past). */
export function minutesUntil(target: string | null, now = new Date()): number | null {
  if (!target) return null;
  return Math.round((new Date(target).getTime() - now.getTime()) / 60000);
}

/** Human relative time in Indonesian. */
export function relativeTime(target: string | null, now = new Date()): string {
  if (!target) return "Tanpa deadline";
  const mins = minutesUntil(target, now);
  if (mins === null) return "Tanpa deadline";
  if (mins < 0) {
    const abs = Math.abs(mins);
    if (abs < 60) return `${abs} menit lalu`;
    if (abs < 1440) return `${Math.round(abs / 60)} jam lalu`;
    return `${Math.round(abs / 1440)} hari lalu`;
  }
  if (mins < 60) return `${mins} menit lagi`;
  if (mins < 1440) return `${Math.round(mins / 60)} jam lagi`;
  return `${Math.round(mins / 1440)} hari lagi`;
}

/** Format datetime to Indonesian 24h local string. */
export function formatDateTime(iso: string | null | Date, opts?: { weekday?: boolean }): string {
  if (!iso) return "-";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return new Intl.DateTimeFormat("id-ID", {
    weekday: opts?.weekday ? "short" : undefined,
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta",
    hour12: false,
  }).format(d);
}

export function formatDate(iso: string | null | Date): string {
  if (!iso) return "-";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return new Intl.DateTimeFormat("id-ID", { day: "2-digit", month: "long", year: "numeric", timeZone: "Asia/Jakarta" }).format(d);
}

export function formatTime(iso: string | null | Date): string {
  if (!iso) return "-";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return new Intl.DateTimeFormat("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta", hour12: false }).format(d);
}

/** Convert a Date to a local <input type="datetime-local"> value (Asia/Jakarta). */
export function toLocalInput(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const tz = "Asia/Jakarta";
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hour12: false,
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}T${get("hour")}:${get("minute")}`;
}

/** Parse a local datetime-local input value as ISO (interpreted as Asia/Jakarta wall time). */
export function fromLocalInput(value: string): string | null {
  if (!value) return null;
  // value is "YYYY-MM-DDTHH:mm" — interpret as Jakarta time.
  // Jakarta is UTC+7. Construct ISO with +07:00 offset.
  return `${value}:00+07:00`;
}

/** "dd jam mm menit" remaining helper for next class. */
export function formatDuration(mins: number): string {
  if (mins < 0) mins = 0;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h > 0 && m > 0) return `${h} jam ${m} menit`;
  if (h > 0) return `${h} jam`;
  return `${m} menit`;
}

/** Get the next weekly occurrence Date for a dayOfWeek + startTime ("HH:mm") in Asia/Jakarta. */
export function nextWeeklyOccurrence(dayOfWeek: number, startTime: string, from = new Date()): Date {
  // Work in Jakarta time by using Intl to get parts.
  const tz = "Asia/Jakarta";
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
    weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false,
  });
  const parts = fmt.formatToParts(from);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  const nowDow = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(get("weekday"));
  let diff = (dayOfWeek - nowDow + 7) % 7;
  const [sh, sm] = startTime.split(":").map(Number);
  // If same day and class already started today, push to next week
  const nowH = Number(get("hour")); const nowM = Number(get("minute"));
  if (diff === 0 && (sh < nowH || (sh === nowH && sm <= nowM))) diff = 7;
  // Build target date in Jakarta, then convert.
  const targetJakarta = new Date(Date.UTC(Number(get("year")), Number(get("month")) - 1, Number(get("day")) + diff, sh, sm, 0));
  // Jakarta is UTC+7 — Date.UTC gives UTC, but we want it to represent Jakarta wall time.
  // So subtract 7 hours to get the true UTC instant.
  return new Date(targetJakarta.getTime() - 7 * 60 * 60 * 1000);
}

export function startOfWeek(from = new Date()): Date {
  const d = new Date(from);
  d.setHours(0, 0, 0, 0);
  const dow = d.getDay();
  d.setDate(d.getDate() - dow);
  return d;
}

export function addDays(d: Date, n: number): Date {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
}
