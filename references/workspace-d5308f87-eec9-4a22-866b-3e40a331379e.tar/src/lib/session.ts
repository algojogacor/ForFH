import "server-only";
import { cookies } from "next/headers";
import { db } from "./db";
import {
  SESSION_COOKIE,
  SESSION_MAX_AGE_DAYS,
  generateSessionToken,
  hashSessionToken,
} from "./crypto";
import { cache } from "react";

const SESSION_COOKIE_MAX_AGE = SESSION_MAX_AGE_DAYS * 24 * 60 * 60;

export type AuthUser = {
  id: string;
  username: string;
  usernameNormalized: string;
  displayName: string | null;
};

export const sessionCookieOptions = () => ({
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
  maxAge: SESSION_COOKIE_MAX_AGE,
});

/** Create a session for a user and set the cookie. */
export async function createSession(userId: string): Promise<void> {
  const token = generateSessionToken();
  const tokenHash = await hashSessionToken(token);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_COOKIE_MAX_AGE * 1000);
  await db.session.create({
    data: { userId, tokenHash, expiresAt, lastSeenAt: now },
  });
  const opts = sessionCookieOptions();
  const c = await cookies();
  c.set(SESSION_COOKIE, token, opts);
}

/** Destroy the current session (logout). */
export async function destroySession(): Promise<void> {
  const c = await cookies();
  const token = c.get(SESSION_COOKIE)?.value;
  if (token) {
    const tokenHash = await hashSessionToken(token);
    await db.session.deleteMany({ where: { tokenHash } }).catch(() => {});
  }
  c.set(SESSION_COOKIE, "", { ...sessionCookieOptions(), maxAge: 0 });
}

/**
 * Get the current authenticated user (cached per-request).
 * Returns null if not authenticated or session expired.
 */
export const getCurrentUser = cache(async (): Promise<AuthUser | null> => {
  try {
    const c = await cookies();
    const token = c.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const tokenHash = await hashSessionToken(token);
    const session = await db.session.findUnique({
      where: { tokenHash },
      include: { user: true },
    });
    if (!session) return null;
    if (session.expiresAt < new Date()) {
      await db.session.delete({ where: { id: session.id } }).catch(() => {});
      return null;
    }
    // Bump lastSeenAt (throttled to once per hour handled implicitly by update).
    await db.session.update({
      where: { id: session.id },
      data: { lastSeenAt: new Date() },
    }).catch(() => {});
    return {
      id: session.user.id,
      username: session.user.username,
      usernameNormalized: session.user.usernameNormalized,
      displayName: session.user.displayName,
    };
  } catch {
    return null;
  }
});

/** Require authentication — throws a redirect-friendly error if not authed. */
export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}
