import type { TaskPriority, TaskStatus, TaskType } from "@/lib/types";

export const TASK_TYPES: { value: TaskType; label: string }[] = [
  { value: "assignment", label: "Tugas" },
  { value: "essay", label: "Esai" },
  { value: "paper", label: "Makalah" },
  { value: "presentation", label: "Presentasi" },
  { value: "reading", label: "Bacaan" },
  { value: "quiz", label: "Quiz" },
  { value: "practice", label: "Latihan" },
  { value: "administrative", label: "Administratif" },
  { value: "other", label: "Lainnya" },
];

export const PRIORITIES: { value: TaskPriority; label: string; className: string }[] = [
  { value: "low", label: "Rendah", className: "text-low" },
  { value: "medium", label: "Sedang", className: "text-medium" },
  { value: "high", label: "Tinggi", className: "text-high" },
  { value: "urgent", label: "Mendesak", className: "text-urgent" },
];

export const STATUSES: { value: TaskStatus; label: string }[] = [
  { value: "NOT_STARTED", label: "Belum Mulai" },
  { value: "IN_PROGRESS", label: "Berjalan" },
  { value: "REVISION", label: "Revisi" },
  { value: "DONE", label: "Selesai" },
  { value: "OVERDUE", label: "Terlambat" },
];

export const EXAM_TYPES = [
  { value: "UTS", label: "UTS" },
  { value: "UAS", label: "UAS" },
  { value: "QUIZ", label: "Quiz" },
  { value: "OTHER", label: "Lainnya" },
];

export const READING_TYPES = [
  { value: "book", label: "Buku" },
  { value: "journal", label: "Jurnal" },
  { value: "law", label: "Peraturan" },
  { value: "case", label: "Putusan" },
  { value: "module", label: "Modul" },
  { value: "ppt", label: "Slide/PPT" },
  { value: "other", label: "Lainnya" },
];

export const DAYS = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
export const DAYS_SHORT = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

export const CLASS_REMINDER_OFFSETS = [240, 120, 90, 60, 30, 20];
export const TASK_REMINDER_OFFSETS = [10080, 4320, 1440, 360, 60];

export const COURSE_COLORS = [
  "#0f8a6a", "#b45309", "#9333ea", "#be123c", "#0891b2",
  "#ca8a04", "#4f46e5", "#db2777", "#15803d", "#c2410c",
];
