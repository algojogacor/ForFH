import "server-only";
import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";
import { features } from "@/lib/env";

export type AiProvider = "zai" | "none";

export type AiResult = {
  ok: boolean;
  content: string | null;
  provider: AiProvider;
  error?: string;
};

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;
async function getZai() {
  if (!zaiInstance) zaiInstance = await ZAI.create();
  return zaiInstance;
}

/**
 * Generate text using the AI provider abstraction.
 * Currently wired to z-ai-web-dev-sdk (the available AI capability in this env).
 * The architecture (provider slots, cooldown, fallback) is documented for
 * future Groq/Ollama wiring in docs/AI_ROUTING.md.
 */
export async function generateText(
  systemPrompt: string,
  userPrompt: string,
  opts?: { temperature?: number; timeoutMs?: number },
  ctx?: { userId?: string; requestType: string },
): Promise<AiResult> {
  if (!features.ai) {
    await recordUsage(ctx?.userId, "none", 0, "ai-disabled", "error", null);
    return { ok: false, content: null, provider: "none", error: "AI_NOT_CONFIGURED" };
  }
  const start = Date.now();
  try {
    const zai = await getZai();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      thinking: { type: "disabled" },
    });
    const content = completion?.choices?.[0]?.message?.content ?? null;
    const latency = Date.now() - start;
    await recordUsage(ctx?.userId, "zai", 1, ctx?.requestType, "success", latency, completion?.usage);
    return { ok: Boolean(content), content, provider: "zai" };
  } catch (e) {
    const latency = Date.now() - start;
    const msg = e instanceof Error ? e.message : String(e);
    await recordUsage(ctx?.userId, "zai", 1, ctx?.requestType, "error", latency, null, msg);
    return { ok: false, content: null, provider: "zai", error: msg };
  }
}

/**
 * Generate a JSON object. Instructs the model to return strict JSON, strips
 * markdown fences, parses, and validates with a user-supplied parser.
 */
export async function generateJson<T>(
  systemPrompt: string,
  userPrompt: string,
  parse: (raw: unknown) => T | null,
  opts?: { timeoutMs?: number },
  ctx?: { userId?: string; requestType: string },
): Promise<{ ok: true; data: T; provider: AiProvider } | { ok: false; error: string; provider: AiProvider }> {
  const res = await generateText(systemPrompt, userPrompt, { timeoutMs: opts?.timeoutMs ?? 25000 }, ctx);
  if (!res.ok || !res.content) return { ok: false, error: res.error ?? "AI_FAILED", provider: res.provider };
  const raw = stripFences(res.content);
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    const m = raw.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (m) {
      try { parsed = JSON.parse(m[1]); } catch { return { ok: false, error: "AI_JSON_INVALID", provider: res.provider }; }
    } else {
      return { ok: false, error: "AI_JSON_INVALID", provider: res.provider };
    }
  }
  const data = parse(parsed);
  if (data === null) return { ok: false, error: "AI_SCHEMA_INVALID", provider: res.provider };
  return { ok: true, data, provider: res.provider };
}

function stripFences(s: string): string {
  return s.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "").trim();
}

async function recordUsage(
  userId: string | undefined,
  provider: string,
  slot: number,
  requestType: string,
  status: "success" | "error",
  latencyMs: number | null,
  usage?: { prompt_tokens?: number; completion_tokens?: number } | null,
  errorClass?: string,
) {
  try {
    await db.aiUsage.create({
      data: {
        userId: userId ?? null,
        provider,
        accountSlot: slot,
        model: "zai-llm",
        requestType,
        status,
        latencyMs,
        inputTokens: usage?.prompt_tokens ?? null,
        outputTokens: usage?.completion_tokens ?? null,
        errorClass: errorClass ?? null,
      },
    });
  } catch {
    // best-effort
  }
}
