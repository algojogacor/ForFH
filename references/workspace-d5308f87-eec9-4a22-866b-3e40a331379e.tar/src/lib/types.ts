// Shared domain types (client + server).

export type View =
  | "dashboard"
  | "calendar"
  | "tasks"
  | "courses"
  | "notes"
  | "readings"
  | "exams"
  | "legal"
  | "settings"
  | "search"
  | "attendance"
  | "grades"
  | "stats"
  | "focus";

export type User = {
  id: string;
  username: string;
  displayName: string | null;
};

export type UserSettings = {
  id: string;
  timezone: string;
  locale: string;
  theme: string;
  defaultTaskReminders: string;
  defaultClassReminders: string;
  primaryClassAlertMinutes: number;
  deadlineBufferMinutes: number;
  aiEnabled: boolean;
};

export type AcademicTerm = {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
};

export type Course = {
  id: string;
  academicTermId: string | null;
  name: string;
  code: string | null;
  lecturer: string | null;
  sks: number | null;
  color: string | null;
  defaultRoom: string | null;
  onlineUrl: string | null;
  notes: string | null;
  archived: boolean;
  _count?: { tasks: number };
};

export type ClassSchedule = {
  id: string;
  courseId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  room: string | null;
  onlineUrl: string | null;
  enabled: boolean;
  course?: Course;
};

export type TaskType =
  | "assignment" | "essay" | "paper" | "presentation"
  | "reading" | "quiz" | "practice" | "administrative" | "other";

export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type TaskStatus = "NOT_STARTED" | "IN_PROGRESS" | "REVISION" | "DONE" | "OVERDUE";

export type Subtask = {
  id: string;
  taskId: string;
  title: string;
  completed: boolean;
  orderIndex: number;
  estimatedMinutes: number | null;
  dueAt: string | null;
};

export type Task = {
  id: string;
  userId: string;
  courseId: string | null;
  title: string;
  description: string | null;
  type: TaskType;
  dueAt: string | null;
  internalTargetAt: string | null;
  priority: TaskPriority;
  estimatedMinutes: number | null;
  status: TaskStatus;
  progress: number;
  source: string;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  course?: Course | null;
  subtasks?: Subtask[];
  _count?: { subtasks: number };
};

export type Note = {
  id: string;
  userId: string;
  courseId: string | null;
  title: string;
  content: string;
  format: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
  course?: Course | null;
};

export type Exam = {
  id: string;
  courseId: string;
  name: string;
  type: "UTS" | "UAS" | "QUIZ" | "OTHER";
  examAt: string;
  location: string | null;
  notes: string | null;
  course?: Course;
  topics?: ExamTopic[];
  _count?: { topics: number };
};

export type ExamTopic = {
  id: string;
  examId: string;
  title: string;
  completed: boolean;
  orderIndex: number;
};

export type Reading = {
  id: string;
  courseId: string | null;
  type: string;
  title: string;
  author: string | null;
  startPage: number | null;
  endPage: number | null;
  currentPage: number | null;
  status: string;
  deadline: string | null;
  notes: string | null;
  course?: Course | null;
};

export type Dashboard = {
  nextClass: {
    course: Course;
    schedule: ClassSchedule;
    startsAt: string;
    room: string | null;
    onlineUrl: string | null;
    minutesUntil: number;
  } | null;
  todaysClasses: {
    course: Course;
    schedule: ClassSchedule;
    startsAt: string;
    endsAt: string;
    room: string | null;
    onlineUrl: string | null;
    minutesUntil: number;
  }[];
  todaysTasks: Task[];
  overdue: Task[];
  nearestDeadlines: Task[];
  weekStats: { total: number; completed: number; remaining: number };
  upcomingExams: (Exam & { daysUntil: number })[];
  aiInsight: string | null;
  aiAvailable: boolean;
  now: string;
  academicSummary: {
    termName: string | null;
    courseCount: number;
    ipk: number | null;
    totalSks: number;
    gradedCourses: number;
  };
};

export type LegalSearchResult = {
  results: {
    frbr_uri: string;
    title: string;
    type: string | null;
    number: string | null;
    year: number | null;
    status: string | null;
    snippet: string | null;
  }[];
  total: number;
  available: boolean;
};

export type Attendance = {
  id: string;
  courseId: string;
  classDate: string;
  status: "PRESENT" | "PERMIT" | "SICK" | "ABSENT";
  notes: string | null;
};

export type AttendanceStats = {
  course: Course;
  total: number;
  present: number;
  permit: number;
  sick: number;
  absent: number;
  percentage: number;
};

export type Grade = {
  id: string;
  courseId: string;
  componentName: string;
  weight: number | null;
  score: number | null;
  letterGrade: string | null;
  gradePoint: number | null;
  course?: Course;
};

export type GpaSummary = {
  courses: {
    course: Course;
    finalGrade: number | null;
    letterGrade: string | null;
    sks: number | null;
  }[];
  ips: number | null;
  ipk: number | null;
  totalSks: number;
};
