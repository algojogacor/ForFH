import { getCurrentUser } from "@/lib/session";
import { AppRoot } from "@/components/app-root";

export default async function Home() {
  const user = await getCurrentUser();
  return <AppRoot initialUser={user} />;
}
