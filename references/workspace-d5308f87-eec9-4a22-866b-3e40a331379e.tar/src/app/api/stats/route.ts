import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");

    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 86400000);

    const [tasks, courses, notes, exams, readings, aiUsage] = await Promise.all([
      db.task.findMany({ where: { userId: user.id }, select: { id: true, status: true, priority: true, type: true, createdAt: true, completedAt: true, dueAt: true, estimatedMinutes: true } }),
      db.course.count({ where: { userId: user.id, archived: false } }),
      db.note.count({ where: { userId: user.id, deletedAt: null } }),
      db.exam.count({ where: { userId: user.id } }),
      db.reading.count({ where: { userId: user.id } }),
      db.aiUsage.findMany({ where: { userId: user.id }, select: { status: true, requestType: true, createdAt: true, latencyMs: true }, orderBy: { createdAt: "desc" }, take: 100 }),
    ]);

    // Task status breakdown
    const byStatus = {
      NOT_STARTED: tasks.filter((t) => t.status === "NOT_STARTED").length,
      IN_PROGRESS: tasks.filter((t) => t.status === "IN_PROGRESS").length,
      REVISION: tasks.filter((t) => t.status === "REVISION").length,
      DONE: tasks.filter((t) => t.status === "DONE").length,
      OVERDUE: tasks.filter((t) => t.status === "OVERDUE").length,
    };

    // Task priority breakdown (active only)
    const activeTasks = tasks.filter((t) => t.status !== "DONE");
    const byPriority = {
      urgent: activeTasks.filter((t) => t.priority === "urgent").length,
      high: activeTasks.filter((t) => t.priority === "high").length,
      medium: activeTasks.filter((t) => t.priority === "medium").length,
      low: activeTasks.filter((t) => t.priority === "low").length,
    };

    // Task type breakdown
    const byType: Record<string, number> = {};
    for (const t of tasks) { byType[t.type] = (byType[t.type] ?? 0) + 1; }

    // Completion trend (last 14 days)
    const trend: { date: string; completed: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const day = new Date(now);
      day.setDate(day.getDate() - i);
      day.setHours(0, 0, 0, 0);
      const next = new Date(day);
      next.setDate(next.getDate() + 1);
      const completed = tasks.filter((t) => t.completedAt && new Date(t.completedAt) >= day && new Date(t.completedAt) < next).length;
      trend.push({ date: day.toISOString().slice(0, 10), completed });
    }

    // Total estimated study time (active tasks)
    const totalEstimatedMinutes = activeTasks.reduce((s, t) => s + (t.estimatedMinutes ?? 0), 0);

    // AI usage stats
    const aiStats = {
      total: aiUsage.length,
      success: aiUsage.filter((a) => a.status === "success").length,
      byType: aiUsage.reduce((acc, a) => { acc[a.requestType] = (acc[a.requestType] ?? 0) + 1; return acc; }, {} as Record<string, number>),
      avgLatency: aiUsage.length > 0 ? Math.round(aiUsage.reduce((s, a) => s + (a.latencyMs ?? 0), 0) / aiUsage.length) : 0,
    };

    return apiOk({
      totals: { courses, notes, exams, readings, tasks: tasks.length },
      taskStatus: byStatus,
      taskPriority: byPriority,
      taskType: byType,
      completionTrend: trend,
      totalEstimatedMinutes,
      aiStats,
    });
  } catch (e) { return handleApiError(e); }
}
