import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const courses = await db.course.findMany({
      where: { userId: user.id, archived: false },
      orderBy: { name: "asc" },
      include: { _count: { select: { tasks: true } } },
    });
    return apiOk({ courses });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  name: z.string().min(1).max(120),
  academicTermId: z.string().nullable().optional(),
  code: z.string().max(40).nullable().optional(),
  lecturer: z.string().max(120).nullable().optional(),
  sks: z.number().int().min(0).max(12).nullable().optional(),
  color: z.string().max(20).nullable().optional(),
  defaultRoom: z.string().max(120).nullable().optional(),
  onlineUrl: z.string().url().nullable().or(z.literal("")).nullable().optional(),
  notes: z.string().max(2000).nullable().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const data = parsed.data;
    if (data.academicTermId) {
      const term = await db.academicTerm.findFirst({ where: { id: data.academicTermId, userId: user.id } });
      if (!term) return apiError("VALIDATION_ERROR", "Term tidak valid.");
    }
    const course = await db.course.create({
      data: {
        userId: user.id,
        name: data.name,
        academicTermId: data.academicTermId ?? null,
        code: data.code ?? null,
        lecturer: data.lecturer ?? null,
        sks: data.sks ?? null,
        color: data.color ?? null,
        defaultRoom: data.defaultRoom ?? null,
        onlineUrl: data.onlineUrl || null,
        notes: data.notes ?? null,
      },
    });
    return apiOk({ course });
  } catch (e) { return handleApiError(e); }
}
