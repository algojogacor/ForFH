import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

/** Get full course detail: course + schedules + tasks + notes + exams + readings */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await db.course.findFirst({ where: { id, userId: user.id } });
    if (!course) return apiError("NOT_FOUND");

    const [schedules, tasks, notes, exams, readings] = await Promise.all([
      db.classSchedule.findMany({ where: { courseId: id }, orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }] }),
      db.task.findMany({ where: { courseId: id, deletedAt: null }, include: { course: true }, orderBy: { dueAt: { sort: "asc", nulls: "last" } } }),
      db.note.findMany({ where: { courseId: id, deletedAt: null }, orderBy: { updatedAt: "desc" } }),
      db.exam.findMany({ where: { courseId: id }, include: { topics: true }, orderBy: { examAt: "asc" } }),
      db.reading.findMany({ where: { courseId: id }, orderBy: { updatedAt: "desc" } }),
    ]);

    return apiOk({ course, schedules, tasks, notes, exams, readings });
  } catch (e) { return handleApiError(e); }
}
