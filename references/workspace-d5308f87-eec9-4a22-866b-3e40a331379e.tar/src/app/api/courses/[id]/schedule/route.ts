import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await db.course.findFirst({ where: { id, userId: user.id } });
    if (!course) return apiError("NOT_FOUND");
    const schedules = await db.classSchedule.findMany({
      where: { userId: user.id, courseId: id },
      orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
    });
    return apiOk({ schedules });
  } catch (e) { return handleApiError(e); }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await db.course.findFirst({ where: { id, userId: user.id } });
    if (!course) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => null);
    if (!body || typeof body.dayOfWeek !== "number" || !body.startTime || !body.endTime) {
      return apiError("VALIDATION_ERROR", "Hari, jam mulai, dan jam selesai wajib diisi.");
    }
    if (body.startTime >= body.endTime) return apiError("VALIDATION_ERROR", "Jam selesai harus setelah jam mulai.");
    const schedule = await db.classSchedule.create({
      data: {
        userId: user.id,
        courseId: id,
        dayOfWeek: body.dayOfWeek,
        startTime: body.startTime,
        endTime: body.endTime,
        room: body.room ?? null,
        onlineUrl: body.onlineUrl ?? null,
        validFrom: body.validFrom ? new Date(body.validFrom) : null,
        validUntil: body.validUntil ? new Date(body.validUntil) : null,
        enabled: body.enabled ?? true,
      },
    });
    return apiOk({ schedule });
  } catch (e) { return handleApiError(e); }
}
