import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

async function ownCourse(id: string, userId: string) {
  return db.course.findFirst({ where: { id, userId } });
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await ownCourse(id, user.id);
    if (!course) return apiError("NOT_FOUND");
    return apiOk({ course });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await ownCourse(id, user.id);
    if (!course) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.course.update({
      where: { id },
      data: {
        name: body.name,
        academicTermId: body.academicTermId === null ? null : body.academicTermId,
        code: body.code,
        lecturer: body.lecturer,
        sks: body.sks,
        color: body.color,
        defaultRoom: body.defaultRoom,
        onlineUrl: body.onlineUrl,
        notes: body.notes,
        archived: body.archived,
      },
    });
    return apiOk({ course: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const course = await ownCourse(id, user.id);
    if (!course) return apiError("NOT_FOUND");
    await db.course.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
