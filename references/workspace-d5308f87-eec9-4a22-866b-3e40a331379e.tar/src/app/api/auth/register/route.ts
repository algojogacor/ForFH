import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, normalizeUsername } from "@/lib/crypto";
import { createSession } from "@/lib/session";
import { authRateLimit, clearAuthRateLimit } from "@/lib/rate-limit";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";
import { headers } from "next/headers";

const registerSchema = z.object({
  username: z.string().min(3).max(32),
  password: z.string().min(8).max(128),
  displayName: z.string().max(64).optional(),
});

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const parsed = parseZod(registerSchema, body);
    if (!parsed.ok) return parsed.res;

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`register:${ip}:${normalizeUsername(parsed.data.username)}`);
    if (rl.blocked) return apiError("RATE_LIMITED", `Terlalu banyak percobaan. Coba lagi dalam ${rl.retryAfterSec}s.`);

    const username = parsed.data.username.trim();
    const usernameNormalized = normalizeUsername(username);

    const existing = await db.user.findUnique({ where: { usernameNormalized } });
    if (existing) {
      return apiError("CONFLICT", "Username sudah digunakan.");
    }

    const passwordHash = await hashPassword(parsed.data.password);
    const user = await db.user.create({
      data: {
        username,
        usernameNormalized,
        passwordHash,
        displayName: parsed.data.displayName,
        settings: { create: {} },
      },
    });

    await createSession(user.id);
    await clearAuthRateLimit(`register:${ip}:${usernameNormalized}`);
    return apiOk({
      user: { id: user.id, username: user.username, displayName: user.displayName },
      onboardingRequired: true,
    });
  } catch (e) {
    return handleApiError(e);
  }
}
