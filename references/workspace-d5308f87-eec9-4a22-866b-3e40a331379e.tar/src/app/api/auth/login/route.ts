import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { verifyPassword, normalizeUsername } from "@/lib/crypto";
import { createSession } from "@/lib/session";
import { authRateLimit, clearAuthRateLimit } from "@/lib/rate-limit";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";
import { headers } from "next/headers";

const loginSchema = z.object({
  username: z.string().min(1).max(64),
  password: z.string().min(1).max(128),
});

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const parsed = parseZod(loginSchema, body);
    if (!parsed.ok) return parsed.res;

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const usernameNormalized = normalizeUsername(parsed.data.username);
    const rl = await authRateLimit(`login:${ip}:${usernameNormalized}`);
    if (rl.blocked) return apiError("RATE_LIMITED", `Terlalu banyak percobaan. Coba lagi dalam ${rl.retryAfterSec}s.`);

    const user = await db.user.findUnique({ where: { usernameNormalized } });
    // Always do hash work to reduce timing-based user enumeration.
    const ok = user ? await verifyPassword(parsed.data.password, user.passwordHash) : false;
    if (!user || !ok) {
      return apiError("UNAUTHORIZED", "Username atau password salah.");
    }

    await createSession(user.id);
    await clearAuthRateLimit(`login:${ip}:${usernameNormalized}`);
    return apiOk({ user: { id: user.id, username: user.username, displayName: user.displayName } });
  } catch (e) {
    return handleApiError(e);
  }
}
