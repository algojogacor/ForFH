import "server-only";
import { getCurrentUser } from "@/lib/session";
import { apiOk, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    return apiOk({ user });
  } catch (e) {
    return handleApiError(e);
  }
}
