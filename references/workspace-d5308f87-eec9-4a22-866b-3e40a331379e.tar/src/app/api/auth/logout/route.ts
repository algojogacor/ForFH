import "server-only";
import { destroySession } from "@/lib/session";
import { apiOk, handleApiError } from "@/lib/api";

export async function POST() {
  try {
    await destroySession();
    return apiOk({ ok: true });
  } catch (e) {
    return handleApiError(e);
  }
}
