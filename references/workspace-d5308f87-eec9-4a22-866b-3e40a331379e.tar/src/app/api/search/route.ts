import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const q = new URL(req.url).searchParams.get("q")?.trim() ?? "";
    if (q.length < 1) return apiOk({ results: { courses: [], tasks: [], notes: [], readings: [], exams: [] } });

    const [courses, tasks, notes, readings, exams] = await Promise.all([
      db.course.findMany({ where: { userId: user.id, OR: [{ name: { contains: q } }, { code: { contains: q } }, { lecturer: { contains: q } }] }, take: 10 }),
      db.task.findMany({ where: { userId: user.id, deletedAt: null, title: { contains: q } }, include: { course: true }, take: 15 }),
      db.note.findMany({ where: { userId: user.id, deletedAt: null, OR: [{ title: { contains: q } }, { content: { contains: q } }] }, include: { course: true }, take: 15 }),
      db.reading.findMany({ where: { userId: user.id, OR: [{ title: { contains: q } }, { author: { contains: q } }] }, include: { course: true }, take: 10 }),
      db.exam.findMany({ where: { userId: user.id, OR: [{ name: { contains: q } }, { location: { contains: q } }] }, include: { course: true }, take: 10 }),
    ]);
    return apiOk({ results: { courses, tasks, notes, readings, exams } });
  } catch (e) { return handleApiError(e); }
}
