import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const courseId = url.searchParams.get("courseId");
    const notes = await db.note.findMany({
      where: { userId: user.id, deletedAt: null, ...(courseId ? { courseId } : {}) },
      include: { course: true },
      orderBy: [{ pinned: "desc" }, { updatedAt: "desc" }],
    });
    return apiOk({ notes });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  title: z.string().min(1).max(200),
  content: z.string().max(100000).optional(),
  courseId: z.string().nullable().optional(),
  pinned: z.boolean().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const d = parsed.data;
    if (d.courseId) {
      const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
      if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    }
    const note = await db.note.create({
      data: {
        userId: user.id,
        title: d.title,
        content: d.content ?? "",
        courseId: d.courseId ?? null,
        pinned: d.pinned ?? false,
      },
    });
    return apiOk({ note });
  } catch (e) { return handleApiError(e); }
}
