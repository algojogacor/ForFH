import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const note = await db.note.findFirst({
      where: { id, userId: user.id, deletedAt: null },
      include: { course: true },
    });
    if (!note) return apiError("NOT_FOUND");
    return apiOk({ note });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const note = await db.note.findFirst({ where: { id, userId: user.id } });
    if (!note) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.note.update({
      where: { id },
      data: {
        title: body.title,
        content: body.content,
        courseId: body.courseId === null ? null : body.courseId,
        pinned: body.pinned,
        version: { increment: 1 },
      },
      include: { course: true },
    });
    return apiOk({ note: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const note = await db.note.findFirst({ where: { id, userId: user.id } });
    if (!note) return apiError("NOT_FOUND");
    await db.note.update({ where: { id }, data: { deletedAt: new Date() } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
