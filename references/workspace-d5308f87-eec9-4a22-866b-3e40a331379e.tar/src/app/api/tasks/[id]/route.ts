import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

async function ownTask(id: string, userId: string) {
  return db.task.findFirst({ where: { id, userId } });
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const task = await db.task.findFirst({
      where: { id, userId: user.id, deletedAt: null },
      include: { course: true, subtasks: { orderBy: { orderIndex: "asc" } }, attachments: true },
    });
    if (!task) return apiError("NOT_FOUND");
    return apiOk({ task });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const task = await ownTask(id, user.id);
    if (!task) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));

    // If marking complete, set completedAt + progress 100.
    const becomingDone = body.status === "DONE" && task.status !== "DONE";
    const leavingDone = task.status === "DONE" && body.status && body.status !== "DONE";

    const updated = await db.task.update({
      where: { id },
      data: {
        title: body.title,
        description: body.description,
        courseId: body.courseId === null ? null : body.courseId,
        type: body.type,
        dueAt: body.dueAt === null ? null : body.dueAt ? new Date(body.dueAt) : undefined,
        internalTargetAt: body.internalTargetAt === null ? null : body.internalTargetAt ? new Date(body.internalTargetAt) : undefined,
        priority: body.priority,
        estimatedMinutes: body.estimatedMinutes,
        status: body.status,
        progress: becomingDone ? 100 : body.progress,
        completedAt: becomingDone ? new Date() : leavingDone ? null : undefined,
        version: { increment: 1 },
      },
      include: { subtasks: { orderBy: { orderIndex: "asc" } }, course: true },
    });

    // Optional: sync progress from subtasks if flagged
    if (body.syncProgressFromSubtasks && updated.subtasks.length > 0) {
      const done = updated.subtasks.filter((s) => s.completed).length;
      const progress = Math.round((done / updated.subtasks.length) * 100);
      await db.task.update({ where: { id }, data: { progress } });
    }

    return apiOk({ task: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const task = await ownTask(id, user.id);
    if (!task) return apiError("NOT_FOUND");
    // Soft delete
    await db.task.update({ where: { id }, data: { deletedAt: new Date(), status: "DONE" } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
