import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const task = await db.task.findFirst({ where: { id, userId: user.id } });
    if (!task) return apiError("NOT_FOUND");
    const subtasks = await db.subtask.findMany({
      where: { taskId: id, deletedAt: null },
      orderBy: { orderIndex: "asc" },
    });
    return apiOk({ subtasks });
  } catch (e) { return handleApiError(e); }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const task = await db.task.findFirst({ where: { id, userId: user.id } });
    if (!task) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => null);
    if (!body?.title) return apiError("VALIDATION_ERROR", "Judul subtask wajib diisi.");
    const count = await db.subtask.count({ where: { taskId: id, deletedAt: null } });
    const subtask = await db.subtask.create({
      data: {
        userId: user.id,
        taskId: id,
        title: body.title,
        orderIndex: body.orderIndex ?? count,
        estimatedMinutes: body.estimatedMinutes ?? null,
        dueAt: body.dueAt ? new Date(body.dueAt) : null,
      },
    });
    // Recompute progress
    await syncTaskProgress(id);
    return apiOk({ subtask });
  } catch (e) { return handleApiError(e); }
}

async function syncTaskProgress(taskId: string) {
  const subs = await db.subtask.findMany({ where: { taskId, deletedAt: null } });
  if (subs.length === 0) return;
  const done = subs.filter((s) => s.completed).length;
  const progress = Math.round((done / subs.length) * 100);
  await db.task.update({ where: { id: taskId }, data: { progress } });
}
