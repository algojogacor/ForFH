import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const status = url.searchParams.get("status");
    const courseId = url.searchParams.get("courseId");
    const includeDeleted = url.searchParams.get("includeDeleted") === "1";

    const tasks = await db.task.findMany({
      where: {
        userId: user.id,
        deletedAt: includeDeleted ? undefined : null,
        ...(status ? { status } : {}),
        ...(courseId ? { courseId } : {}),
      },
      include: { course: true, _count: { select: { subtasks: true } } },
      orderBy: [{ dueAt: { sort: "asc", nulls: "last" } }, { updatedAt: "desc" }],
    });
    return apiOk({ tasks });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  title: z.string().min(1).max(200),
  courseId: z.string().nullable().optional(),
  description: z.string().max(5000).nullable().optional(),
  type: z.string().optional(),
  dueAt: z.string().datetime({ offset: true }).nullable().optional(),
  internalTargetAt: z.string().datetime({ offset: true }).nullable().optional(),
  priority: z.string().optional(),
  estimatedMinutes: z.number().int().min(1).nullable().optional(),
  status: z.string().optional(),
  progress: z.number().int().min(0).max(100).optional(),
  source: z.string().optional(),
  subtasks: z.array(z.object({ title: z.string().min(1), estimatedMinutes: z.number().int().min(1).nullable().optional() })).optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const d = parsed.data;
    if (d.courseId) {
      const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
      if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    }
    const task = await db.task.create({
      data: {
        userId: user.id,
        title: d.title,
        courseId: d.courseId ?? null,
        description: d.description ?? null,
        type: d.type ?? "assignment",
        dueAt: d.dueAt ? new Date(d.dueAt) : null,
        internalTargetAt: d.internalTargetAt ? new Date(d.internalTargetAt) : null,
        priority: d.priority ?? "medium",
        estimatedMinutes: d.estimatedMinutes ?? null,
        status: d.status ?? "NOT_STARTED",
        progress: d.progress ?? 0,
        source: d.source ?? "manual",
        completedAt: d.status === "DONE" ? new Date() : null,
        subtasks: d.subtasks
          ? { create: d.subtasks.map((s, i) => ({ userId: user.id, title: s.title, orderIndex: i, estimatedMinutes: s.estimatedMinutes ?? null })) }
          : undefined,
      },
      include: { subtasks: { orderBy: { orderIndex: "asc" } }, course: true },
    });
    return apiOk({ task });
  } catch (e) { return handleApiError(e); }
}
