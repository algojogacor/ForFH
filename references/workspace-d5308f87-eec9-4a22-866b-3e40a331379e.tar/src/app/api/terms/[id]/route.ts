import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const term = await db.academicTerm.findFirst({ where: { id, userId: user.id } });
    if (!term) return apiError("NOT_FOUND");
    await db.academicTerm.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const term = await db.academicTerm.findFirst({ where: { id, userId: user.id } });
    if (!term) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    if (body.isActive) {
      await db.academicTerm.updateMany({ where: { userId: user.id, isActive: true }, data: { isActive: false } });
    }
    const updated = await db.academicTerm.update({
      where: { id },
      data: {
        name: body.name ?? undefined,
        startDate: body.startDate ? new Date(body.startDate) : undefined,
        endDate: body.endDate ? new Date(body.endDate) : undefined,
        isActive: body.isActive ?? undefined,
      },
    });
    return apiOk({ term: updated });
  } catch (e) { return handleApiError(e); }
}
