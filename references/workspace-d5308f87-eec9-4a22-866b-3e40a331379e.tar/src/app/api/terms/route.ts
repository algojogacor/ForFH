import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const terms = await db.academicTerm.findMany({
      where: { userId: user.id },
      orderBy: { startDate: "desc" },
    });
    return apiOk({ terms });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  name: z.string().min(1).max(120),
  startDate: z.string().datetime({ offset: true }),
  endDate: z.string().datetime({ offset: true }),
  isActive: z.boolean().default(false),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const { name, startDate, endDate, isActive } = parsed.data;

    if (new Date(endDate) < new Date(startDate)) return apiError("VALIDATION_ERROR", "Tanggal selesai sebelum tanggal mulai.");

    if (isActive) {
      await db.academicTerm.updateMany({ where: { userId: user.id, isActive: true }, data: { isActive: false } });
    }
    const term = await db.academicTerm.create({
      data: { userId: user.id, name, startDate: new Date(startDate), endDate: new Date(endDate), isActive },
    });
    return apiOk({ term });
  } catch (e) { return handleApiError(e); }
}
