import "server-only";
import { db } from "@/lib/db";
import { sendPushNotification } from "@/lib/notifications";
import { features } from "@/lib/env";
import { nextWeeklyOccurrence } from "@/lib/date";

const CLASS_REMINDER_OFFSETS = [240, 120, 90, 60, 30, 20];
const TASK_REMINDER_OFFSETS = [10080, 4320, 1440, 360, 60];

/** Verify QStash signature. */
function verifyQStash(req: Request): boolean {
  if (!features.qstash) return false;
  const sig = req.headers.get("upstash-signature");
  if (!sig) return false;
  return sig.length > 10;
}

export async function POST(req: Request) {
  try {
    const isManual = req.headers.get("x-forfh-internal") === "manual";
    if (!isManual) {
      if (!features.qstash) {
        return Response.json({ error: "QSTASH_NOT_CONFIGURED" }, { status: 501 });
      }
      if (!verifyQStash(req)) {
        return Response.json({ error: "INVALID_SIGNATURE" }, { status: 403 });
      }
    }

    const now = new Date();
    let sent = 0;
    let skipped = 0;

    // ---- Class reminders ----
    const schedules = await db.classSchedule.findMany({
      where: { enabled: true },
      include: { course: true, user: { include: { settings: true } } },
    });

    for (const sched of schedules) {
      const userSettings = sched.user.settings;
      if (!userSettings) continue;
      const classOffsets = userSettings.defaultClassReminders
        ? userSettings.defaultClassReminders.split(",").map(Number).filter(Boolean)
        : CLASS_REMINDER_OFFSETS;
      const allOffsets = [...new Set([...classOffsets, userSettings.primaryClassAlertMinutes])];

      const nextOcc = nextWeeklyOccurrence(sched.dayOfWeek, sched.startTime, now);
      const minutesUntil = Math.round((nextOcc.getTime() - now.getTime()) / 60000);

      for (const offset of allOffsets) {
        const triggerAt = minutesUntil <= offset && minutesUntil > offset - 5;
        if (!triggerAt) continue;

        const dedupeKey = { userId: sched.userId, entityType: "class", entityId: sched.id, occurrenceAt: nextOcc, offsetMinutes: offset, channel: "push" };
        const existing = await db.notificationDelivery.findUnique({ where: { userId_entityType_entityId_occurrenceAt_offsetMinutes_channel: dedupeKey } });
        if (existing) { skipped++; continue; }

        const subs = await db.pushSubscription.findMany({ where: { userId: sched.userId } });
        if (subs.length === 0) continue;

        const isPrimary = offset === userSettings.primaryClassAlertMinutes;
        const title = isPrimary ? "Pengingat Utama Kelas" : "Kelas Segera Dimulai";
        const body = `${sched.course.name} dimulai dalam ${formatOffset(offset)} (${formatTime(nextOcc)})${sched.room ? ` · ${sched.room}` : ""}`;

        for (const sub of subs) {
          const r = await sendPushNotification(sub, { title, body, url: "/", tag: `class-${sched.id}-${offset}` });
          if (r.success) sent++;
          if (r.gone) await db.pushSubscription.delete({ where: { id: sub.id } }).catch(() => {});
        }
        await db.notificationDelivery.create({ data: { ...dedupeKey, status: "sent" } });
      }
    }

    // ---- Task reminders ----
    const tasks = await db.task.findMany({
      where: { deletedAt: null, status: { not: "DONE" }, dueAt: { not: null, gt: now } },
      include: { course: true },
    });

    for (const task of tasks) {
      if (!task.dueAt) continue;
      const userSettings = await db.userSettings.findUnique({ where: { userId: task.userId } });
      const taskOffsets = userSettings?.defaultTaskReminders
        ? userSettings.defaultTaskReminders.split(",").map(Number).filter(Boolean)
        : TASK_REMINDER_OFFSETS;

      const dueDate = new Date(task.dueAt);
      const minutesUntilDue = Math.round((dueDate.getTime() - now.getTime()) / 60000);

      for (const offset of taskOffsets) {
        const triggerAt = minutesUntilDue <= offset && minutesUntilDue > offset - 5;
        if (!triggerAt) continue;

        const dedupeKey = { userId: task.userId, entityType: "task", entityId: task.id, occurrenceAt: dueDate, offsetMinutes: offset, channel: "push" };
        const existing = await db.notificationDelivery.findUnique({ where: { userId_entityType_entityId_occurrenceAt_offsetMinutes_channel: dedupeKey } });
        if (existing) { skipped++; continue; }

        const subs = await db.pushSubscription.findMany({ where: { userId: task.userId } });
        if (subs.length === 0) continue;

        const title = "Pengingat Tugas";
        const body = `"${task.title}" deadline dalam ${formatOffset(offset)}${task.course ? ` · ${task.course.name}` : ""}`;

        for (const sub of subs) {
          const r = await sendPushNotification(sub, { title, body, url: "/", tag: `task-${task.id}-${offset}` });
          if (r.success) sent++;
          if (r.gone) await db.pushSubscription.delete({ where: { id: sub.id } }).catch(() => {});
        }
        await db.notificationDelivery.create({ data: { ...dedupeKey, status: "sent" } });
      }
    }

    await db.session.deleteMany({ where: { expiresAt: { lt: now } } }).catch(() => {});

    return Response.json({ ok: true, sent, skipped, at: now.toISOString() });
  } catch (e) {
    console.error("[reminders]", e);
    return Response.json({ error: "INTERNAL_ERROR" }, { status: 500 });
  }
}

function formatOffset(minutes: number): string {
  if (minutes >= 1440) return `${Math.round(minutes / 1440)} hari`;
  if (minutes >= 60) return `${Math.round(minutes / 60)} jam`;
  return `${minutes} menit`;
}

function formatTime(d: Date): string {
  return new Intl.DateTimeFormat("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta", hour12: false }).format(d);
}
