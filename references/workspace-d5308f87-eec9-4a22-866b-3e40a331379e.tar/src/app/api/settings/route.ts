import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const settings = await db.userSettings.upsert({
      where: { userId: user.id },
      update: {},
      create: { userId: user.id },
    });
    return apiOk({ settings });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const body = await req.json().catch(() => ({}));
    const settings = await db.userSettings.upsert({
      where: { userId: user.id },
      update: {
        timezone: body.timezone,
        locale: body.locale,
        theme: body.theme,
        defaultTaskReminders: body.defaultTaskReminders,
        defaultClassReminders: body.defaultClassReminders,
        primaryClassAlertMinutes: body.primaryClassAlertMinutes,
        deadlineBufferMinutes: body.deadlineBufferMinutes,
        aiEnabled: body.aiEnabled,
      },
      create: {
        userId: user.id,
        timezone: body.timezone,
        locale: body.locale,
        theme: body.theme,
        defaultTaskReminders: body.defaultTaskReminders,
        defaultClassReminders: body.defaultClassReminders,
        primaryClassAlertMinutes: body.primaryClassAlertMinutes,
        deadlineBufferMinutes: body.deadlineBufferMinutes,
        aiEnabled: body.aiEnabled,
      },
    });
    return apiOk({ settings });
  } catch (e) { return handleApiError(e); }
}
