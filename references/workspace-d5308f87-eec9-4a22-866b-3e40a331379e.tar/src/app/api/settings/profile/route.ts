import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function PATCH(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const body = await req.json().catch(() => ({}));
    const updated = await db.user.update({
      where: { id: user.id },
      data: { displayName: body.displayName?.trim() || null },
      select: { id: true, username: true, displayName: true },
    });
    return apiOk({ user: updated });
  } catch (e) { return handleApiError(e); }
}
