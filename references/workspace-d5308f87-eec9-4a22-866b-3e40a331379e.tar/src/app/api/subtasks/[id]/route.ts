import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const sub = await db.subtask.findFirst({ where: { id, userId: user.id } });
    if (!sub) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.subtask.update({
      where: { id },
      data: {
        title: body.title,
        completed: body.completed,
        orderIndex: body.orderIndex,
        estimatedMinutes: body.estimatedMinutes,
        dueAt: body.dueAt === null ? null : body.dueAt ? new Date(body.dueAt) : undefined,
        version: { increment: 1 },
      },
    });
    // Sync parent task progress
    if (typeof body.completed === "boolean") {
      const subs = await db.subtask.findMany({ where: { taskId: sub.taskId, deletedAt: null } });
      const done = subs.filter((s) => s.completed).length;
      const progress = subs.length ? Math.round((done / subs.length) * 100) : 0;
      const allDone = subs.length > 0 && done === subs.length;
      await db.task.update({
        where: { id: sub.taskId },
        data: {
          progress,
          status: allDone ? "DONE" : body.completed ? "IN_PROGRESS" : undefined,
          completedAt: allDone ? new Date() : null,
        },
      });
    }
    return apiOk({ subtask: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const sub = await db.subtask.findFirst({ where: { id, userId: user.id } });
    if (!sub) return apiError("NOT_FOUND");
    await db.subtask.update({ where: { id }, data: { deletedAt: new Date() } });
    // Sync progress
    const subs = await db.subtask.findMany({ where: { taskId: sub.taskId, deletedAt: null } });
    const done = subs.filter((s) => s.completed).length;
    const progress = subs.length ? Math.round((done / subs.length) * 100) : 0;
    await db.task.update({ where: { id: sub.taskId }, data: { progress } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
