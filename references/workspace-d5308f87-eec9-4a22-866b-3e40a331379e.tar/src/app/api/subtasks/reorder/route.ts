import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

const reorderSchema = z.object({
  subtasks: z.array(z.object({
    id: z.string(),
    orderIndex: z.number().int(),
  })),
});

export async function PATCH(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(reorderSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;

    // Verify all subtasks belong to the user and update order
    for (const item of parsed.data.subtasks) {
      const sub = await db.subtask.findFirst({ where: { id: item.id, userId: user.id } });
      if (!sub) return apiError("NOT_FOUND", `Subtask ${item.id} tidak ditemukan.`);
      await db.subtask.update({ where: { id: item.id }, data: { orderIndex: item.orderIndex } });
    }
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
