import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const exams = await db.exam.findMany({
      where: { userId: user.id },
      include: { course: true, _count: { select: { topics: true } } },
      orderBy: { examAt: "asc" },
    });
    return apiOk({ exams });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  courseId: z.string(),
  name: z.string().min(1).max(120),
  type: z.string().default("UTS"),
  examAt: z.string().datetime({ offset: true }),
  location: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  topics: z.array(z.object({ title: z.string().min(1) })).optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const d = parsed.data;
    const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
    if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    const exam = await db.exam.create({
      data: {
        userId: user.id,
        courseId: d.courseId,
        name: d.name,
        type: d.type,
        examAt: new Date(d.examAt),
        location: d.location ?? null,
        notes: d.notes ?? null,
        topics: d.topics ? { create: d.topics.map((t, i) => ({ userId: user.id, title: t.title, orderIndex: i })) } : undefined,
      },
      include: { course: true, topics: { orderBy: { orderIndex: "asc" } } },
    });
    return apiOk({ exam });
  } catch (e) { return handleApiError(e); }
}
