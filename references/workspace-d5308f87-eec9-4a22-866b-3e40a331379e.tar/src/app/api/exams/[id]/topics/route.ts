import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const exam = await db.exam.findFirst({ where: { id, userId: user.id } });
    if (!exam) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => null);
    if (!body?.title) return apiError("VALIDATION_ERROR", "Judul topik wajib diisi.");
    const count = await db.examTopic.count({ where: { examId: id } });
    const topic = await db.examTopic.create({
      data: { userId: user.id, examId: id, title: body.title, orderIndex: count },
    });
    return apiOk({ topic });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    // id here is examId; body has topicId
    const body = await req.json().catch(() => ({}));
    const topic = await db.examTopic.findFirst({ where: { id: body.topicId, examId: id, userId: user.id } });
    if (!topic) return apiError("NOT_FOUND");
    const updated = await db.examTopic.update({
      where: { id: topic.id },
      data: { title: body.title, completed: body.completed },
    });
    return apiOk({ topic: updated });
  } catch (e) { return handleApiError(e); }
}
