import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const exam = await db.exam.findFirst({
      where: { id, userId: user.id },
      include: { course: true, topics: { orderBy: { orderIndex: "asc" } } },
    });
    if (!exam) return apiError("NOT_FOUND");
    return apiOk({ exam });
  } catch (e) { return handleApiError(e); }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const exam = await db.exam.findFirst({ where: { id, userId: user.id } });
    if (!exam) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.exam.update({
      where: { id },
      data: {
        name: body.name,
        type: body.type,
        examAt: body.examAt ? new Date(body.examAt) : undefined,
        location: body.location,
        notes: body.notes,
      },
      include: { course: true, topics: { orderBy: { orderIndex: "asc" } } },
    });
    return apiOk({ exam: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const exam = await db.exam.findFirst({ where: { id, userId: user.id } });
    if (!exam) return apiError("NOT_FOUND");
    await db.exam.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
