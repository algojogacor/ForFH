import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { generateText } from "@/lib/ai/provider";
import { TODAY_INSIGHT_SYSTEM } from "@/lib/ai/prompts";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

export async function POST() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");

    const settings = await db.userSettings.findUnique({ where: { userId: user.id } });
    if (settings?.aiEnabled === false) return apiError("FEATURE_NOT_CONFIGURED", "AI dinonaktifkan di pengaturan.");

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`ai-insight:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan AI.");

    const now = new Date();
    const startToday = new Date(now); startToday.setHours(0, 0, 0, 0);
    const endToday = new Date(now); endToday.setHours(23, 59, 59, 999);
    const weekEnd = new Date(now); weekEnd.setDate(weekEnd.getDate() + 7);

    const [tasks, exams, schedules] = await Promise.all([
      db.task.findMany({ where: { userId: user.id, deletedAt: null, status: { not: "DONE" } }, include: { course: true }, orderBy: { dueAt: { sort: "asc", nulls: "last" } }, take: 12 }),
      db.exam.findMany({ where: { userId: user.id, examAt: { gt: now }, lt: weekEnd }, include: { course: true }, orderBy: { examAt: "asc" }, take: 3 }),
      db.classSchedule.findMany({ where: { userId: user.id, enabled: true }, include: { course: true } }),
    ]);

    const todayDow = now.getDay();
    const todaysClasses = schedules.filter((s) => s.dayOfWeek === todayDow).map((s) => `${s.course.name} ${s.startTime}-${s.endTime}`);
    const todaysTasks = tasks.filter((t) => t.dueAt && new Date(t.dueAt) <= endToday && new Date(t.dueAt) >= startToday).map((t) => t.title);
    const overdue = tasks.filter((t) => t.dueAt && new Date(t.dueAt) < now).map((t) => `${t.title} (terlambat)`);
    const upcoming = tasks.filter((t) => t.dueAt && new Date(t.dueAt) > now && new Date(t.dueAt) <= weekEnd).slice(0, 5).map((t) => `${t.title} (${new Date(t.dueAt).toISOString()})`);

    const prompt = `Waktu sekarang (Jakarta): ${new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "full", timeStyle: "short", hour12: false }).format(now)}
Kelas hari ini: ${todaysClasses.join(", ") || "tidak ada"}
Tugas jatuh tempo hari ini: ${todaysTasks.join(", ") || "tidak ada"}
Tugas terlambat: ${overdue.join(", ") || "tidak ada"}
Tugas minggu ini: ${upcoming.join(", ") || "tidak ada"}
Ujian dekat: ${exams.map((e) => `${e.name} ${new Date(e.examAt).toISOString()}`).join(", ") || "tidak ada"}

Beri insight singkat (maks 3 kalimat) tentang apa yang harus dilakukan hari ini.`;

    const res = await generateText(TODAY_INSIGHT_SYSTEM, prompt, { timeoutMs: 20000 }, { userId: user.id, requestType: "today_insight" });
    if (!res.ok || !res.content) return apiOk({ insight: null, available: false });
    return apiOk({ insight: res.content.trim(), available: true });
  } catch (e) { return handleApiError(e); }
}
