import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { generateJson } from "@/lib/ai/provider";
import { TASK_BREAKDOWN_SYSTEM } from "@/lib/ai/prompts";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { taskId } = await req.json().catch(() => ({}));
    if (!taskId) return apiError("VALIDATION_ERROR", "taskId wajib.");
    const task = await db.task.findFirst({ where: { id: taskId, userId: user.id } });
    if (!task) return apiError("NOT_FOUND");

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`ai-bd:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan AI.");

    const res = await generateJson(
      TASK_BREAKDOWN_SYSTEM,
      `Tugas: ${task.title}\nTipe: ${task.type}\nDeskripsi: ${task.description ?? "-"}\nEstimasi: ${task.estimatedMinutes ?? "?"} menit\nDeadline: ${task.dueAt ?? "?"}`,
      (raw) => {
        if (!Array.isArray(raw)) return null;
        return raw
          .map((r) => ({ title: String(r?.title ?? "").trim(), estimatedMinutes: Number.isFinite(r?.estimatedMinutes) ? Math.max(5, Math.round(r.estimatedMinutes)) : null }))
          .filter((r) => r.title)
          .slice(0, 8);
      },
      { timeoutMs: 25000 },
      { userId: user.id, requestType: "task_breakdown" },
    );

    if (!res.ok) return apiError("AI_PROVIDER_UNAVAILABLE", "AI tidak dapat memecah tugas ini.", { aiError: res.error });
    return apiOk({ subtasks: res.data });
  } catch (e) { return handleApiError(e); }
}
