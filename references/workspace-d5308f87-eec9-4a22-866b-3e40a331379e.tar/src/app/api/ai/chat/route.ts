import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { generateText } from "@/lib/ai/provider";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

const ASSISTANT_SYSTEM = `Anda asisten akademik ForFH untuk mahasiswa hukum Indonesia. Nama Anda ForFH Assistant.

Tugas:
- Bantu menjawab pertanyaan akademik, menjelaskan konsep hukum, dan memberi saran belajar.
- Gunakan Bahasa Indonesia yang natural dan ramah.
- Jawaban ringkas dan actionable (maks 3-4 paragraf kecuali diminta detail).
- Jika pertanyaan tentang peraturan spesifik, sarankan gunakan fitur Hukum (Pasal.id).
- Jika pertanyaan tentang jadwal/tugas, gunakan konteks data pengguna yang diberikan.

Konteks pengguna (jika tersedia) akan diberikan sebagai data. Gunakan untuk personalisasi jawaban.`;

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const body = await req.json().catch(() => null);
    if (!body?.message || typeof body.message !== "string" || body.message.trim().length < 1) {
      return apiError("VALIDATION_ERROR", "Pesan tidak boleh kosong.");
    }

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`ai-chat:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan AI. Tunggu sebentar.");

    // Build context from user's data
    const [activeTasks, todayClasses, upcomingExams] = await Promise.all([
      db.task.findMany({ where: { userId: user.id, deletedAt: null, status: { not: "DONE" } }, include: { course: true }, orderBy: { dueAt: { sort: "asc", nulls: "last" } }, take: 8 }),
      db.task.findMany({ where: { userId: user.id, deletedAt: null, status: { not: "DONE" }, dueAt: { not: null } }, include: { course: true }, orderBy: { dueAt: "asc" }, take: 5 }),
      db.exam.findMany({ where: { userId: user.id, examAt: { gt: new Date() } }, include: { course: true }, orderBy: { examAt: "asc" }, take: 3 }),
    ]);

    const tz = "Asia/Jakarta";
    const nowStr = new Intl.DateTimeFormat("id-ID", { timeZone: tz, dateStyle: "full", timeStyle: "short", hour12: false }).format(new Date());

    const context = `Waktu sekarang (Jakarta): ${nowStr}
Pengguna: ${user.displayName || user.username}

Tugas aktif terdekat:
${activeTasks.map((t) => `- ${t.title} (${t.course?.name ?? "tanpa MK"}, deadline: ${t.dueAt ? new Intl.DateTimeFormat("id-ID", { timeZone: tz, dateStyle: "medium", timeStyle: "short", hour12: false }).format(new Date(t.dueAt)) : "tanpa deadline"})`).join("\n") || "- tidak ada"}

Ujian mendatang:
${upcomingExams.map((e) => `- ${e.name} (${e.course?.name ?? ""}, ${new Intl.DateTimeFormat("id-ID", { timeZone: tz, dateStyle: "medium", timeStyle: "short", hour12: false }).format(new Date(e.examAt))})`).join("\n") || "- tidak ada"}`;

    const conversation = body.history?.map((m: { role: string; content: string }) => `${m.role === "user" ? "Mahasiswa" : "Asisten"}: ${m.content}`).join("\n") ?? "";

    const fullPrompt = `${ASSISTANT_SYSTEM}

KONTEKS DATA PENGGUNA:
${context}

${conversation}

Mahasiswa: ${body.message}

Asisten:`;

    const res = await generateText(
      ASSISTANT_SYSTEM,
      `Konteks:\n${context}\n\nRiwayat:\n${conversation}\n\nPertanyaan: ${body.message}`,
      { timeoutMs: 25000 },
      { userId: user.id, requestType: "chat_assistant" },
    );

    if (!res.ok || !res.content) {
      return apiOk({ reply: null, available: false, error: res.error });
    }
    return apiOk({ reply: res.content.trim(), available: true });
  } catch (e) { return handleApiError(e); }
}
