import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { generateJson } from "@/lib/ai/provider";
import { QUICK_CAPTURE_SCHEMA, quickCaptureSystem } from "@/lib/ai/prompts";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const body = await req.json().catch(() => null);
    if (!body?.text || typeof body.text !== "string" || body.text.trim().length < 2) {
      return apiError("VALIDATION_ERROR", "Masukkan teks tugas.");
    }

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`ai-qc:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan AI. Tunggu sebentar.");

    const courses = await db.course.findMany({
      where: { userId: user.id, archived: false },
      select: { name: true, code: true },
    });
    const nowJakarta = new Intl.DateTimeFormat("id-ID", {
      timeZone: "Asia/Jakarta", weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false,
    }).format(new Date());

    const res = await generateJson(
      quickCaptureSystem(courses, nowJakarta),
      body.text,
      (raw) => {
        const r = QUICK_CAPTURE_SCHEMA.safeParse(raw);
        return r.success ? r.data : null;
      },
      { timeoutMs: 20000 },
      { userId: user.id, requestType: "quick_capture" },
    );

    if (!res.ok) {
      return apiError("AI_PROVIDER_UNAVAILABLE", "AI tidak dapat memproses teks ini. Coba tulis manual atau ulangi.", { aiError: res.error });
    }
    return apiOk({ parsed: res.data });
  } catch (e) { return handleApiError(e); }
}
