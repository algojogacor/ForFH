import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { generateJson } from "@/lib/ai/provider";
import { SMART_DEADLINE_SYSTEM } from "@/lib/ai/prompts";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { taskId } = await req.json().catch(() => ({}));
    if (!taskId) return apiError("VALIDATION_ERROR", "taskId wajib.");
    const task = await db.task.findFirst({ where: { id: taskId, userId: user.id } });
    if (!task || !task.dueAt) return apiError("VALIDATION_ERROR", "Tugas harus memiliki deadline.");

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`ai-sd:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan AI.");

    const [schedules, otherTasks] = await Promise.all([
      db.classSchedule.findMany({ where: { userId: user.id, enabled: true }, select: { dayOfWeek: true, startTime: true, endTime: true } }),
      db.task.findMany({ where: { userId: user.id, deletedAt: null, status: { not: "DONE" }, dueAt: { not: null }, NOT: { id: taskId } }, select: { title: true, dueAt: true } }),
    ]);
    const days = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
    const scheduleStr = schedules.map((s) => `${days[s.dayOfWeek]} ${s.startTime}-${s.endTime}`).join(", ") || "kosong";
    const otherTasksStr = otherTasks.map((t) => `${t.title} (${new Date(t.dueAt!).toISOString()})`).join(", ") || "kosong";

    const nowJakarta = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Jakarta", dateStyle: "full", timeStyle: "short", hour12: false }).format(new Date());

    const res = await generateJson(
      SMART_DEADLINE_SYSTEM,
      `Tugas: ${task.title}\nDeadline: ${new Date(task.dueAt).toISOString()}\nEstimasi total: ${task.estimatedMinutes ?? "?"} menit\nProgress saat ini: ${task.progress}%\nJadwal kelas mingguan: ${scheduleStr}\nTugas lain mendekati deadline: ${otherTasksStr}\nWaktu sekarang (Jakarta): ${nowJakarta}\n\nBuat rencana pengerjaan bertahap.`,
      (raw) => {
        if (!Array.isArray(raw)) return null;
        return raw
          .map((r) => ({
            date: String(r?.date ?? "").trim(),
            title: String(r?.title ?? "").trim(),
            estimatedMinutes: Number.isFinite(r?.estimatedMinutes) ? Math.max(15, Math.round(r.estimatedMinutes)) : 60,
            rationale: String(r?.rationale ?? "").trim(),
          }))
          .filter((r) => r.date && r.title)
          .slice(0, 8);
      },
      { timeoutMs: 25000 },
      { userId: user.id, requestType: "smart_deadline" },
    );

    if (!res.ok) return apiError("AI_PROVIDER_UNAVAILABLE", "AI tidak dapat membuat rencana.", { aiError: res.error });
    return apiOk({ plan: res.data });
  } catch (e) { return handleApiError(e); }
}
