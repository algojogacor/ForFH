import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { nextWeeklyOccurrence, addDays } from "@/lib/date";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");

    const now = new Date();
    const startToday = new Date(now);
    startToday.setHours(0, 0, 0, 0);
    const endToday = new Date(now);
    endToday.setHours(23, 59, 59, 999);

    // Jakarta today's day-of-week index (0=Sun..6=Sat) from "now"
    const tz = "Asia/Jakarta";
    const todayDowShort = new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: tz }).format(now);
    const todayDow = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(todayDowShort);

    const [schedules, tasks, exams, settings, grades, courses, activeTerm] = await Promise.all([
      db.classSchedule.findMany({
        where: { userId: user.id, enabled: true },
        include: { course: true },
      }),
      db.task.findMany({
        where: { userId: user.id, deletedAt: null, status: { not: "DONE" } },
        include: { course: true, subtasks: { where: { deletedAt: null }, orderBy: { orderIndex: "asc" } } },
      }),
      db.exam.findMany({
        where: { userId: user.id, examAt: { gt: now } },
        include: { course: true, topics: true },
        orderBy: { examAt: "asc" },
        take: 5,
      }),
      db.userSettings.findUnique({ where: { userId: user.id } }),
      db.grade.findMany({ where: { userId: user.id }, include: { course: true } }),
      db.course.findMany({ where: { userId: user.id, archived: false }, select: { id: true, name: true, sks: true, color: true, code: true } }),
      db.academicTerm.findFirst({ where: { userId: user.id, isActive: true } }),
    ]);

    // ---- GPA calculation ----
    const GRADE_MAP: Record<string, number> = { A: 4.0, "A-": 3.7, "B+": 3.3, B: 3.0, "B-": 2.7, "C+": 2.3, C: 2.0, "C-": 1.7, D: 1.0, E: 0.0 };
    const gradesByCourse = new Map<string, typeof grades>();
    for (const g of grades) {
      const arr = gradesByCourse.get(g.courseId) ?? [];
      arr.push(g);
      gradesByCourse.set(g.courseId, arr);
    }
    let totalSks = 0;
    let totalPoints = 0;
    let gradedCourses = 0;
    for (const c of courses) {
      const components = gradesByCourse.get(c.id) ?? [];
      if (components.length === 0 || !c.sks) continue;
      const totalWeight = components.reduce((s, g) => s + (g.weight ?? 0), 0);
      const weightedScore = components.reduce((s, g) => s + (g.score ?? 0) * (g.weight ?? 0), 0);
      const finalGrade = totalWeight > 0 ? weightedScore / totalWeight : null;
      if (finalGrade === null) continue;
      const letter = finalGrade >= 85 ? "A" : finalGrade >= 80 ? "A-" : finalGrade >= 75 ? "B+" : finalGrade >= 70 ? "B" : finalGrade >= 65 ? "B-" : finalGrade >= 60 ? "C+" : finalGrade >= 55 ? "C" : finalGrade >= 50 ? "C-" : finalGrade >= 40 ? "D" : "E";
      const point = GRADE_MAP[letter] ?? 0;
      totalSks += c.sks;
      totalPoints += point * c.sks;
      gradedCourses++;
    }
    const ipk = totalSks > 0 ? totalPoints / totalSks : null;

    // ---- Today's classes ----
    type ClassOcc = {
      course: typeof schedules[number]["course"];
      schedule: (typeof schedules)[number];
      startsAt: Date;
      endsAt: Date;
      room: string | null;
      onlineUrl: string | null;
      minutesUntil: number;
    };
    const todaysClasses: ClassOcc[] = [];
    for (const s of schedules) {
      if (s.dayOfWeek !== todayDow) continue;
      const occ = nextWeeklyOccurrence(s.dayOfWeek, s.startTime, now);
      const [eh, em] = s.endTime.split(":").map(Number);
      const endsAt = new Date(occ);
      endsAt.setUTCHours(eh, em, 0, 0);
      // adjust endsAt to same jakarta day semantics: build from occ date
      const endsJakarta = new Date(Date.UTC(occ.getUTCFullYear(), occ.getUTCMonth(), occ.getUTCDate(), eh, em));
      endsAt.setTime(endsJakarta.getTime() - 7 * 60 * 60 * 1000);
      const minutesUntil = Math.round((occ.getTime() - now.getTime()) / 60000);
      todaysClasses.push({ course: s.course, schedule: s, startsAt: occ, endsAt, room: s.room ?? s.course.defaultRoom, onlineUrl: s.onlineUrl ?? s.course.onlineUrl, minutesUntil });
    }
    todaysClasses.sort((a, b) => a.startsAt.getTime() - b.startsAt.getTime());

    // ---- Next class (today remaining or next week) ----
    const upcoming = todaysClasses.filter((c) => c.minutesUntil > -1);
    let nextClass: ClassOcc | null = upcoming[0] ?? null;
    if (!nextClass) {
      // Find next weekly occurrence across all enabled schedules
      let best: ClassOcc | null = null;
      for (const s of schedules) {
        const occ = nextWeeklyOccurrence(s.dayOfWeek, s.startTime, now);
        if (!best || occ < best.startsAt) {
          const [eh, em] = s.endTime.split(":").map(Number);
          const endsJakarta = new Date(Date.UTC(occ.getUTCFullYear(), occ.getUTCMonth(), occ.getUTCDate(), eh, em));
          const endsAt = new Date(endsJakarta.getTime() - 7 * 60 * 60 * 1000);
          best = { course: s.course, schedule: s, startsAt: occ, endsAt, room: s.room ?? s.course.defaultRoom, onlineUrl: s.onlineUrl ?? s.course.onlineUrl, minutesUntil: Math.round((occ.getTime() - now.getTime()) / 60000) };
        }
      }
      nextClass = best;
    }

    // ---- Today's tasks (due today or internal target today) ----
    const todaysTasks = tasks.filter((t) => {
      if (!t.dueAt && !t.internalTargetAt) return false;
      const d = t.dueAt ?? t.internalTargetAt!;
      return d >= startToday && d <= endToday;
    });

    // ---- Overdue ----
    const overdue = tasks.filter((t) => t.dueAt && new Date(t.dueAt) < now).sort((a, b) => new Date(a.dueAt!).getTime() - new Date(b.dueAt!).getTime());

    // ---- Nearest deadlines (top 6 by dueAt asc) ----
    const nearestDeadlines = [...tasks]
      .filter((t) => t.dueAt)
      .sort((a, b) => new Date(a.dueAt!).getTime() - new Date(b.dueAt!).getTime())
      .slice(0, 6);

    // ---- Week stats ----
    const weekStart = addDays(startToday, -(now.getDay()));
    const weekEnd = addDays(weekStart, 7);
    const weekTasks = await db.task.findMany({
      where: {
        userId: user.id,
        OR: [
          { dueAt: { gte: weekStart, lt: weekEnd } },
          { completedAt: { gte: weekStart, lt: weekEnd } },
        ],
      },
    });
    const weekStats = {
      total: weekTasks.length,
      completed: weekTasks.filter((t) => t.status === "DONE").length,
      remaining: weekTasks.filter((t) => t.status !== "DONE").length,
    };

    // ---- Upcoming exams with days until ----
    const upcomingExams = exams.map((e) => ({
      ...e,
      daysUntil: Math.ceil((new Date(e.examAt).getTime() - now.getTime()) / 86400000),
    }));

    return apiOk({
      nextClass: nextClass
        ? {
            course: nextClass.course,
            schedule: nextClass.schedule,
            startsAt: nextClass.startsAt.toISOString(),
            endsAt: nextClass.endsAt.toISOString(),
            room: nextClass.room,
            onlineUrl: nextClass.onlineUrl,
            minutesUntil: nextClass.minutesUntil,
          }
        : null,
      todaysClasses: todaysClasses.map((c) => ({
        course: c.course,
        schedule: c.schedule,
        startsAt: c.startsAt.toISOString(),
        endsAt: c.endsAt.toISOString(),
        room: c.room,
        onlineUrl: c.onlineUrl,
        minutesUntil: c.minutesUntil,
      })),
      todaysTasks,
      overdue,
      nearestDeadlines,
      weekStats,
      upcomingExams,
      aiInsight: null,
      aiAvailable: Boolean(settings?.aiEnabled),
      now: now.toISOString(),
      academicSummary: {
        termName: activeTerm?.name ?? null,
        courseCount: courses.length,
        ipk: ipk !== null ? Math.round(ipk * 100) / 100 : null,
        totalSks,
        gradedCourses,
      },
    });
  } catch (e) { return handleApiError(e); }
}
