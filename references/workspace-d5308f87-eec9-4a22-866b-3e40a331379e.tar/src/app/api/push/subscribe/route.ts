import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";
import { z } from "zod";
import { features } from "@/lib/env";

const subscribeSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({ p256dh: z.string(), auth: z.string() }),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    if (!features.vapid) return apiError("FEATURE_NOT_CONFIGURED", "Web Push belum dikonfigurasi.");
    const parsed = parseZod(subscribeSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const { endpoint, keys } = parsed.data;

    await db.pushSubscription.upsert({
      where: { endpoint },
      update: { userId: user.id, p256dh: keys.p256dh, auth: keys.auth, lastUsedAt: new Date() },
      create: { userId: user.id, endpoint, p256dh: keys.p256dh, auth: keys.auth },
    });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const endpoint = url.searchParams.get("endpoint");
    if (!endpoint) return apiError("VALIDATION_ERROR", "endpoint wajib.");
    const sub = await db.pushSubscription.findUnique({ where: { endpoint } });
    if (sub && sub.userId === user.id) {
      await db.pushSubscription.delete({ where: { endpoint } });
    }
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const count = await db.pushSubscription.count({ where: { userId: user.id } });
    return apiOk({ subscribed: count > 0, count, vapidEnabled: features.vapid });
  } catch (e) { return handleApiError(e); }
}
