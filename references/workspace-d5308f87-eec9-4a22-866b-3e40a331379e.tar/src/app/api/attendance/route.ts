import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { z } from "zod";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const courseId = url.searchParams.get("courseId");

    const where = { userId: user.id, ...(courseId ? { courseId } : {}) };
    const records = await db.attendance.findMany({ where, orderBy: { classDate: "desc" } });

    // Compute per-course stats
    const courses = await db.course.findMany({ where: { userId: user.id, archived: false }, orderBy: { name: "asc" } });
    const stats = courses.map((c) => {
      const courseRecords = records.filter((r) => r.courseId === c.id);
      const present = courseRecords.filter((r) => r.status === "PRESENT").length;
      const permit = courseRecords.filter((r) => r.status === "PERMIT").length;
      const sick = courseRecords.filter((r) => r.status === "SICK").length;
      const absent = courseRecords.filter((r) => r.status === "ABSENT").length;
      const total = courseRecords.length;
      const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
      return { course: c, total, present, permit, sick, absent, percentage };
    });

    return apiOk({ records, stats });
  } catch (e) { return handleApiError(e); }
}

const setSchema = z.object({
  courseId: z.string(),
  classDate: z.string().datetime({ offset: true }),
  status: z.enum(["PRESENT", "PERMIT", "SICK", "ABSENT"]),
  notes: z.string().max(500).nullable().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = z.object({ records: z.array(setSchema) }).safeParse(await req.json().catch(() => null));
    if (!parsed.success) return apiError("VALIDATION_ERROR", parsed.error.issues.map((i) => i.message).join("; "));
    const { records } = parsed.data;

    for (const r of records) {
      const c = await db.course.findFirst({ where: { id: r.courseId, userId: user.id } });
      if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
      await db.attendance.upsert({
        where: { userId_courseId_classDate: { userId: user.id, courseId: r.courseId, classDate: new Date(r.classDate) } },
        update: { status: r.status, notes: r.notes ?? null },
        create: { userId: user.id, courseId: r.courseId, classDate: new Date(r.classDate), status: r.status, notes: r.notes ?? null },
      });
    }
    return apiOk({ ok: true, count: records.length });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return apiError("VALIDATION_ERROR", "id wajib.");
    const rec = await db.attendance.findFirst({ where: { id, userId: user.id } });
    if (!rec) return apiError("NOT_FOUND");
    await db.attendance.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
