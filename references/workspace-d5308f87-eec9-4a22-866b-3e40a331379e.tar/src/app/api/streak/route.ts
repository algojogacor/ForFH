import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { jakartaDateKey } from "@/lib/date";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");

    // Get all completed tasks (by completion date)
    const completedTasks = await db.task.findMany({
      where: { userId: user.id, completedAt: { not: null } },
      select: { completedAt: true },
    });

    // Get unique Jakarta dates of completion
    const completionDates = new Set<string>();
    for (const t of completedTasks) {
      if (t.completedAt) {
        completionDates.add(jakartaDateKey(t.completedAt));
      }
    }

    // Calculate current streak (consecutive days up to today/yesterday)
    const today = jakartaDateKey(new Date());
    const yesterday = jakartaDateKey(new Date(Date.now() - 86400000));
    const sortedDates = Array.from(completionDates).sort().reverse();

    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;

    // Calculate longest streak by iterating sorted dates
    const allDates = Array.from(completionDates).sort();
    for (let i = 0; i < allDates.length; i++) {
      if (i === 0) {
        tempStreak = 1;
      } else {
        const prev = new Date(allDates[i - 1]);
        const curr = new Date(allDates[i]);
        const diff = Math.round((curr.getTime() - prev.getTime()) / 86400000);
        if (diff === 1) {
          tempStreak++;
        } else {
          tempStreak = 1;
        }
      }
      longestStreak = Math.max(longestStreak, tempStreak);
    }

    // Calculate current streak
    if (sortedDates.length > 0) {
      if (sortedDates[0] === today || sortedDates[0] === yesterday) {
        currentStreak = 1;
        for (let i = 1; i < sortedDates.length; i++) {
          const prev = new Date(sortedDates[i - 1]);
          const curr = new Date(sortedDates[i]);
          const diff = Math.round((prev.getTime() - curr.getTime()) / 86400000);
          if (diff === 1) {
            currentStreak++;
          } else {
            break;
          }
        }
      }
    }

    // Total completed
    const totalCompleted = completedTasks.length;

    // Achievements
    const achievements = [
      { id: "first_task", label: "Tugas Pertama", description: "Selesaikan tugas pertamamu", icon: "🎯", unlocked: totalCompleted >= 1 },
      { id: "streak_3", label: "Konsistensi 3 Hari", description: "Selesaikan tugas 3 hari berturut-turut", icon: "🔥", unlocked: longestStreak >= 3 },
      { id: "streak_7", label: "Pekan Sempurna", description: "Selesaikan tugas 7 hari berturut-turut", icon: "⚡", unlocked: longestStreak >= 7 },
      { id: "tasks_10", label: "Sepuluh Tugas", description: "Selesaikan 10 tugas total", icon: "📚", unlocked: totalCompleted >= 10 },
      { id: "tasks_25", label: "Duapuluhan", description: "Selesaikan 25 tugas total", icon: "🏆", unlocked: totalCompleted >= 25 },
      { id: "streak_30", label: "Sebulan Penuh", description: "Selesaikan tugas 30 hari berturut-turut", icon: "👑", unlocked: longestStreak >= 30 },
    ];

    return apiOk({
      currentStreak,
      longestStreak,
      totalCompleted,
      achievements,
      lastCompletionDate: sortedDates[0] ?? null,
    });
  } catch (e) { return handleApiError(e); }
}
