import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const schedules = await db.classSchedule.findMany({
      where: { userId: user.id, enabled: true },
      include: { course: true },
      orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
    });
    return apiOk({ schedules });
  } catch (e) { return handleApiError(e); }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const body = await req.json().catch(() => null);
    if (!body || !body.courseId || typeof body.dayOfWeek !== "number" || !body.startTime || !body.endTime) {
      return apiError("VALIDATION_ERROR", "Mata kuliah, hari, jam mulai, dan jam selesai wajib diisi.");
    }
    const course = await db.course.findFirst({ where: { id: body.courseId, userId: user.id } });
    if (!course) return apiError("NOT_FOUND");
    const schedule = await db.classSchedule.create({
      data: {
        userId: user.id,
        courseId: body.courseId,
        dayOfWeek: body.dayOfWeek,
        startTime: body.startTime,
        endTime: body.endTime,
        room: body.room ?? null,
        onlineUrl: body.onlineUrl ?? null,
        enabled: body.enabled ?? true,
      },
    });
    return apiOk({ schedule });
  } catch (e) { return handleApiError(e); }
}
