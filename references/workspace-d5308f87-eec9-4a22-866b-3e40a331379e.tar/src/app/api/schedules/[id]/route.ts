import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const sched = await db.classSchedule.findFirst({ where: { id, userId: user.id } });
    if (!sched) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.classSchedule.update({
      where: { id },
      data: {
        dayOfWeek: body.dayOfWeek,
        startTime: body.startTime,
        endTime: body.endTime,
        room: body.room,
        onlineUrl: body.onlineUrl,
        enabled: body.enabled,
      },
    });
    return apiOk({ schedule: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const sched = await db.classSchedule.findFirst({ where: { id, userId: user.id } });
    if (!sched) return apiError("NOT_FOUND");
    await db.classSchedule.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
