import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const bookmarks = await db.legalBookmark.findMany({
      where: { userId: user.id },
      include: { course: true },
      orderBy: { createdAt: "desc" },
    });
    return apiOk({ bookmarks });
  } catch (e) { return handleApiError(e); }
}

const schema = z.object({
  frbrUri: z.string().min(1),
  title: z.string().min(1).max(300),
  type: z.string().nullable().optional(),
  number: z.string().nullable().optional(),
  year: z.number().int().nullable().optional(),
  courseId: z.string().nullable().optional(),
  userNote: z.string().max(2000).nullable().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(schema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const d = parsed.data;
    if (d.courseId) {
      const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
      if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    }
    const bookmark = await db.legalBookmark.create({
      data: {
        userId: user.id,
        frbrUri: d.frbrUri,
        title: d.title,
        type: d.type ?? null,
        number: d.number ?? null,
        year: d.year ?? null,
        courseId: d.courseId ?? null,
        userNote: d.userNote ?? null,
      },
    });
    return apiOk({ bookmark });
  } catch (e) { return handleApiError(e); }
}
