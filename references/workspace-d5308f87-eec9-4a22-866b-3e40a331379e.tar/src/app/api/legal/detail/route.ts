import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { env, features } from "@/lib/env";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    if (!features.pasal) return apiOk({ law: null, available: false });

    const uri = new URL(req.url).searchParams.get("uri");
    if (!uri) return apiError("VALIDATION_ERROR", "uri wajib.");

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`pasal:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak permintaan.");

    // Normalize: remove leading slash duplication, encode safely.
    const cleanUri = uri.replace(/^\/+/, "");
    const res = await fetch(`${env.PASAL_API_BASE_URL}/laws/${cleanUri}`, {
      headers: { Authorization: `Bearer ${env.PASAL_API_TOKEN}`, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return apiOk({ law: null, available: false });
    const law = await res.json();
    return apiOk({ law, available: true });
  } catch (e) { return handleApiError(e); }
}
