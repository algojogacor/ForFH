import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { env, features } from "@/lib/env";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { authRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";

const TYPE_CODES = [
  "UUD","TAP_MPR","UU","PERPPU","KUHPERDATA","PP","PERPRES","KEPPRES","INPRES","PENPRES",
  "PERMEN","PERMENKUMHAM","PERMENKUM","PERBAN","PERDA","PERDA_PROV","PERDA_KAB","KEPMEN","SE",
  "PERMA","PBI","UUDRT","UUDS","PMK","PUTUSAN_MK","PERKETUA_MK","PERSEKJEN_MK","POJK","PERGUB",
  "PERBUP","PERWALI","QANUN","PERDASUS","PERDAIS",
];

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim() ?? "";
    const type = url.searchParams.get("type") ?? "";
    const limit = Math.min(Number(url.searchParams.get("limit") ?? 10), 20);
    if (q.length < 2) return apiOk({ results: [], total: 0, available: features.pasal });

    if (!features.pasal) {
      return apiOk({ results: [], total: 0, available: false });
    }

    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const rl = await authRateLimit(`pasal:${user.id}:${ip}`);
    if (rl.blocked) return apiError("RATE_LIMITED", "Terlalu banyak pencarian hukum.");

    const params = new URLSearchParams({ q, limit: String(limit) });
    if (type && TYPE_CODES.includes(type)) params.set("type", type);
    const res = await fetch(`${env.PASAL_API_BASE_URL}/search?${params}`, {
      headers: { Authorization: `Bearer ${env.PASAL_API_TOKEN}`, Accept: "application/json" },
      signal: AbortSignal.timeout(12000),
    });
    if (res.status === 429) return apiError("PASAL_RATE_LIMITED", "Server Pasal.id sedang sibuk. Coba lagi nanti.");
    if (!res.ok) {
      return apiOk({ results: [], total: 0, available: false });
    }
    const data = await res.json();
    const results = Array.isArray(data?.results) ? data.results : Array.isArray(data?.data) ? data.data : [];
    return apiOk({ results, total: data?.total ?? results.length, available: true });
  } catch (e) { return handleApiError(e); }
}
