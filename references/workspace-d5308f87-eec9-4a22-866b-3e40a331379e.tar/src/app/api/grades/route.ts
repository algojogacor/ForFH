import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";
import { z } from "zod";

// Indonesian grade mapping (configurable — stored in app_config for future)
const GRADE_MAP: Record<string, number> = {
  A: 4.0, "A-": 3.7, "B+": 3.3, B: 3.0, "B-": 2.7, "C+": 2.3, C: 2.0, "C-": 1.7, D: 1.0, E: 0.0,
};

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const grades = await db.grade.findMany({
      where: { userId: user.id },
      include: { course: true },
      orderBy: { createdAt: "desc" },
    });

    // Compute per-course final grade (weighted average of components)
    const byCourse = new Map<string, typeof grades>();
    for (const g of grades) {
      const arr = byCourse.get(g.courseId) ?? [];
      arr.push(g);
      byCourse.set(g.courseId, arr);
    }

    const courses = await db.course.findMany({ where: { userId: user.id, archived: false }, orderBy: { name: "asc" } });
    const courseGrades = courses.map((c) => {
      const components = byCourse.get(c.id) ?? [];
      const totalWeight = components.reduce((s, g) => s + (g.weight ?? 0), 0);
      const weightedScore = components.reduce((s, g) => s + (g.score ?? 0) * (g.weight ?? 0), 0);
      const finalGrade = totalWeight > 0 ? weightedScore / totalWeight : null;
      const letterGrade = finalGrade !== null ? scoreToLetter(finalGrade) : null;
      const gradePoint = letterGrade ? (GRADE_MAP[letterGrade] ?? null) : null;
      return { course: c, components, finalGrade, letterGrade, gradePoint, sks: c.sks };
    });

    // IPS (semester) & IPK (cumulative)
    const gradedCourses = courseGrades.filter((c) => c.gradePoint !== null && c.sks);
    const totalSks = gradedCourses.reduce((s, c) => s + (c.sks ?? 0), 0);
    const totalPoints = gradedCourses.reduce((s, c) => s + (c.gradePoint ?? 0) * (c.sks ?? 0), 0);
    const ipk = totalSks > 0 ? totalPoints / totalSks : null;

    return apiOk({ grades, courseGrades, ipk, totalSks });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  courseId: z.string(),
  componentName: z.string().min(1).max(100),
  weight: z.number().min(0).max(100).nullable().optional(),
  score: z.number().min(0).max(100).nullable().optional(),
  letterGrade: z.string().max(5).nullable().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = createSchema.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return apiError("VALIDATION_ERROR", parsed.error.issues.map((i) => i.message).join("; "));
    const d = parsed.data;
    const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
    if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    const gradePoint = d.letterGrade ? (GRADE_MAP[d.letterGrade] ?? null) : null;
    const grade = await db.grade.create({
      data: { userId: user.id, courseId: d.courseId, componentName: d.componentName, weight: d.weight ?? null, score: d.score ?? null, letterGrade: d.letterGrade ?? null, gradePoint },
    });
    return apiOk({ grade });
  } catch (e) { return handleApiError(e); }
}

function scoreToLetter(score: number): string {
  if (score >= 85) return "A";
  if (score >= 80) return "A-";
  if (score >= 75) return "B+";
  if (score >= 70) return "B";
  if (score >= 65) return "B-";
  if (score >= 60) return "C+";
  if (score >= 55) return "C";
  if (score >= 50) return "C-";
  if (score >= 40) return "D";
  return "E";
}
