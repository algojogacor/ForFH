import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { handleApiError } from "@/lib/api";
import { displayStatus } from "@/lib/date";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), { status: 401 });
    const tasks = await db.task.findMany({
      where: { userId: user.id, deletedAt: null },
      include: { course: true },
      orderBy: { dueAt: { sort: "asc", nulls: "last" } },
    });

    const header = ["Judul", "Mata Kuliah", "Jenis", "Prioritas", "Status", "Deadline", "Estimasi (menit)", "Progress", "Deskripsi"];
    const rows = tasks.map((t) => [
      escapeCsv(t.title),
      escapeCsv(t.course?.name ?? ""),
      escapeCsv(t.type),
      escapeCsv(t.priority),
      escapeCsv(displayStatus(t.status as never, t.dueAt)),
      escapeCsv(t.dueAt ? new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "medium", timeStyle: "short", hour12: false }).format(new Date(t.dueAt)) : ""),
      t.estimatedMinutes?.toString() ?? "",
      `${t.progress}%`,
      escapeCsv(t.description ?? ""),
    ].join(","));

    const csv = [header.join(","), ...rows].join("\n");

    return new Response("\ufeff" + csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="forfh-tugas-${new Date().toISOString().slice(0, 10)}.csv"`,
      },
    });
  } catch (e) { return handleApiError(e) as unknown as Response; }
}

function escapeCsv(s: string): string {
  if (s.includes(",") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}
