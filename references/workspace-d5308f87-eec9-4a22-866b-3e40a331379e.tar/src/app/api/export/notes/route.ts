import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return new Response(JSON.stringify({ error: "UNAUTHORIZED" }), { status: 401 });
    const notes = await db.note.findMany({
      where: { userId: user.id, deletedAt: null },
      include: { course: true },
      orderBy: [{ pinned: "desc" }, { updatedAt: "desc" }],
    });

    const md = notes.map((n) => {
      const header = `# ${n.title}${n.pinned ? " 📌" : ""}`;
      const meta = [
        n.course?.name && `**Mata Kuliah:** ${n.course.name}`,
        `**Diperbarui:** ${new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "full", timeStyle: "short", hour12: false }).format(new Date(n.updatedAt))}`,
      ].filter(Boolean).join("\n");
      return `${header}\n\n${meta}\n\n---\n\n${n.content || "_Catatan kosong_"}`;
    }).join("\n\n---\n\n");

    const fullMd = `# Catatan ForFH — ${user.displayName || user.username}\n\n_Diexport pada ${new Intl.DateTimeFormat("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "full", timeStyle: "short", hour12: false }).format(new Date())}_\n\nTotal: ${notes.length} catatan\n\n---\n\n${md}`;

    return new Response(fullMd, {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename="forfh-catatan-${new Date().toISOString().slice(0, 10)}.md"`,
      },
    });
  } catch (e) { return handleApiError(e) as unknown as Response; }
}
