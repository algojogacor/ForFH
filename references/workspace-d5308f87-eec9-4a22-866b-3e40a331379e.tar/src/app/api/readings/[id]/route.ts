import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const r = await db.reading.findFirst({ where: { id, userId: user.id } });
    if (!r) return apiError("NOT_FOUND");
    const body = await req.json().catch(() => ({}));
    const updated = await db.reading.update({
      where: { id },
      data: {
        title: body.title,
        courseId: body.courseId === null ? null : body.courseId,
        type: body.type,
        author: body.author,
        sourceUrl: body.sourceUrl,
        startPage: body.startPage,
        endPage: body.endPage,
        currentPage: body.currentPage,
        status: body.status,
        deadline: body.deadline === null ? null : body.deadline ? new Date(body.deadline) : undefined,
        notes: body.notes,
      },
      include: { course: true },
    });
    return apiOk({ reading: updated });
  } catch (e) { return handleApiError(e); }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const { id } = await params;
    const r = await db.reading.findFirst({ where: { id, userId: user.id } });
    if (!r) return apiError("NOT_FOUND");
    await db.reading.delete({ where: { id } });
    return apiOk({ ok: true });
  } catch (e) { return handleApiError(e); }
}
