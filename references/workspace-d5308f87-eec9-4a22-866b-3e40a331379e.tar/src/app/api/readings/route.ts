import "server-only";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, parseZod, handleApiError } from "@/lib/api";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const readings = await db.reading.findMany({
      where: { userId: user.id },
      include: { course: true },
      orderBy: { updatedAt: "desc" },
    });
    return apiOk({ readings });
  } catch (e) { return handleApiError(e); }
}

const createSchema = z.object({
  title: z.string().min(1).max(200),
  courseId: z.string().nullable().optional(),
  type: z.string().optional(),
  author: z.string().nullable().optional(),
  sourceUrl: z.string().nullable().optional(),
  startPage: z.number().int().nullable().optional(),
  endPage: z.number().int().nullable().optional(),
  currentPage: z.number().int().nullable().optional(),
  status: z.string().optional(),
  deadline: z.string().datetime({ offset: true }).nullable().optional(),
  notes: z.string().nullable().optional(),
});

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const parsed = parseZod(createSchema, await req.json().catch(() => null));
    if (!parsed.ok) return parsed.res;
    const d = parsed.data;
    if (d.courseId) {
      const c = await db.course.findFirst({ where: { id: d.courseId, userId: user.id } });
      if (!c) return apiError("VALIDATION_ERROR", "Mata kuliah tidak valid.");
    }
    const reading = await db.reading.create({
      data: {
        userId: user.id,
        title: d.title,
        courseId: d.courseId ?? null,
        type: d.type ?? "book",
        author: d.author ?? null,
        sourceUrl: d.sourceUrl ?? null,
        startPage: d.startPage ?? null,
        endPage: d.endPage ?? null,
        currentPage: d.currentPage ?? null,
        status: d.status ?? "NOT_STARTED",
        deadline: d.deadline ? new Date(d.deadline) : null,
        notes: d.notes ?? null,
      },
    });
    return apiOk({ reading });
  } catch (e) { return handleApiError(e); }
}
