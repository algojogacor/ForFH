import "server-only";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { apiError, apiOk, handleApiError } from "@/lib/api";

/** Onboarding status: does user have any term / course yet? */
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return apiError("UNAUTHORIZED");
    const [termCount, courseCount] = await Promise.all([
      db.academicTerm.count({ where: { userId: user.id } }),
      db.course.count({ where: { userId: user.id } }),
    ]);
    const settings = await db.userSettings.findUnique({ where: { userId: user.id } });
    return apiOk({
      needsOnboarding: termCount === 0 || courseCount === 0,
      termCount,
      courseCount,
      hasDisplayName: Boolean(user.displayName),
      aiEnabled: settings?.aiEnabled ?? true,
    });
  } catch (e) { return handleApiError(e); }
}
