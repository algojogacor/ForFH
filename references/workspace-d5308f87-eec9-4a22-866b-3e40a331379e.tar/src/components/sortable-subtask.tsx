"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Checkbox } from "@/components/ui/checkbox";
import { GripVertical, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { Subtask } from "@/lib/types";

type SortableSubtaskProps = {
  subtask: Subtask;
  onToggle: (id: string, completed: boolean) => void;
  onDelete?: (id: string) => void;
};

export function SortableSubtask({ subtask, onToggle, onDelete }: SortableSubtaskProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: subtask.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center gap-2 rounded-md p-2 group bg-card border",
        isDragging && "shadow-lg ring-2 ring-primary/40 z-50 opacity-90",
      )}
    >
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabing text-muted-foreground/40 hover:text-muted-foreground touch-none shrink-0"
        title="Seret untuk urutkan"
      >
        <GripVertical className="size-4" />
      </button>
      <Checkbox
        checked={subtask.completed}
        onCheckedChange={(v) => onToggle(subtask.id, Boolean(v))}
      />
      <span className={cn("text-sm flex-1 min-w-0", subtask.completed && "line-through text-muted-foreground")}>
        {subtask.title}
      </span>
      {subtask.estimatedMinutes && (
        <span className="text-xs text-muted-foreground shrink-0">{subtask.estimatedMinutes}m</span>
      )}
      {onDelete && (
        <Button
          variant="ghost"
          size="icon"
          className="size-7 opacity-0 group-hover:opacity-100 transition shrink-0"
          onClick={() => onDelete(subtask.id)}
        >
          <Trash2 className="size-3" />
        </Button>
      )}
    </div>
  );
}
