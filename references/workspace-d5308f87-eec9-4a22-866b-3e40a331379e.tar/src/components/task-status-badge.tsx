"use client";

import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { displayStatus as _ds } from "@/lib/date";
import type { TaskPriority, TaskStatus } from "@/lib/types";

export function TaskStatusBadge({ status, dueAt }: { status: TaskStatus; dueAt?: string | null }) {
  const s = _ds(status, dueAt ?? null);
  const map: Record<string, { label: string; className: string }> = {
    NOT_STARTED: { label: "Belum Mulai", className: "bg-muted text-muted-foreground" },
    IN_PROGRESS: { label: "Berjalan", className: "bg-medium/15 text-medium" },
    REVISION: { label: "Revisi", className: "bg-high/15 text-high" },
    DONE: { label: "Selesai", className: "bg-success/15 text-success" },
    OVERDUE: { label: "Terlambat", className: "bg-urgent/15 text-urgent" },
  };
  const cfg = map[s] ?? map.NOT_STARTED;
  return <Badge variant="secondary" className={cn("text-[11px] font-medium", cfg.className)}>{cfg.label}</Badge>;
}

export function PriorityDot({ priority }: { priority: TaskPriority }) {
  const colors: Record<TaskPriority, string> = {
    low: "bg-low", medium: "bg-medium", high: "bg-high", urgent: "bg-urgent",
  };
  return <span className={cn("size-2 rounded-full", colors[priority])} />;
}
