"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { fetchApi } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Task, Course } from "@/lib/types";
import { Play, Pause, RotateCcw, Timer, Coffee, Check, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PRESETS = [
  { label: "Pomodoro", focus: 25, break: 5 },
  { label: "Fokus Dalam", focus: 50, break: 10 },
  { label: "Cepat", focus: 15, break: 3 },
];

type Mode = "focus" | "break";

export function FocusView() {
  const [presetIdx, setPresetIdx] = useState(0);
  const [mode, setMode] = useState<Mode>("focus");
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [cycles, setCycles] = useState(0);
  const [taskId, setTaskId] = useState<string>("none");
  const [totalFocusSeconds, setTotalFocusSeconds] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const modeRef = useRef<Mode>(mode);

  useEffect(() => { modeRef.current = mode; }, [mode]);

  const preset = PRESETS[presetIdx];

  const { data: tasks } = useQuery({
    queryKey: apiKeys.tasks(),
    queryFn: () => fetchApi<{ tasks: Task[] }>("/api/tasks").then((r) => r.tasks.filter((t) => t.status !== "DONE")),
  });

  const stop = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    setRunning(false);
  }, []);

  const tick = useCallback(() => {
    setSecondsLeft((s) => {
      if (s <= 1) {
        // Phase complete
        const finishedMode = modeRef.current;
        if (finishedMode === "focus") {
          setCycles((c) => c + 1);
          setTotalFocusSeconds((t) => t + preset.focus * 60);
          setMode("break");
          toast.success(`Sesi fokus selesai! (${preset.focus}m) Waktu istirahat.`);
          return preset.break * 60;
        } else {
          setMode("focus");
          toast.info("Istilahat selesai. Saatnya fokus kembali!");
          return preset.focus * 60;
        }
      }
      return s - 1;
    });
  }, [preset]);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(tick, 1000);
      return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
    }
  }, [running, tick]);

  const start = () => { setRunning(true); };
  const pause = () => { setRunning(false); };
  const reset = () => {
    stop();
    setMode("focus");
    setSecondsLeft(preset.focus * 60);
    setCycles(0);
    setTotalFocusSeconds(0);
  };

  const switchPreset = (idx: number) => {
    setPresetIdx(idx);
    stop();
    setMode("focus");
    setSecondsLeft(PRESETS[idx].focus * 60);
  };

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const progress = mode === "focus"
    ? ((preset.focus * 60 - secondsLeft) / (preset.focus * 60)) * 100
    : ((preset.break * 60 - secondsLeft) / (preset.break * 60)) * 100;

  const totalFocusMins = Math.floor(totalFocusSeconds / 60);

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Fokus</h1>
        <p className="text-sm text-muted-foreground">Teknik Pomodoro untuk produktivitas belajar</p>
      </div>

      {/* Preset selector */}
      <div className="grid grid-cols-3 gap-2">
        {PRESETS.map((p, i) => (
          <button
            key={i}
            onClick={() => switchPreset(i)}
            className={cn(
              "rounded-xl border p-3.5 text-center transition",
              presetIdx === i ? "border-primary bg-primary/10 ring-1 ring-primary/20" : "bg-card hover:bg-accent/50 border-border",
            )}
          >
            <div className={cn("text-sm font-semibold", presetIdx === i ? "text-primary" : "")}>{p.label}</div>
            <div className="text-[11px] text-muted-foreground mt-0.5">{p.focus}m / {p.break}m</div>
          </button>
        ))}
      </div>

      {/* Timer card */}
      <Card className={cn("border-2 transition-colors", mode === "focus" ? "border-primary/40 bg-primary/5" : "border-high/40 bg-high/5")}>
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col items-center gap-5">
            {/* Circular timer */}
            <div className="relative size-52">
              <svg className="size-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="4" className="text-muted/50" />
                <circle
                  cx="50" cy="50" r="45" fill="none"
                  stroke="currentColor" strokeWidth="4" strokeLinecap="round"
                  className={mode === "focus" ? "text-primary" : "text-high"}
                  strokeDasharray={`${2 * Math.PI * 45}`}
                  strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                  style={{ transition: "stroke-dashoffset 1s linear" }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-6xl font-bold tabular-nums tracking-tight">
                  {String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-2">
                  {mode === "focus" ? <Brain className="size-3" /> : <Coffee className="size-3" />}
                  {mode === "focus" ? "Sesi Fokus" : "Istirahat"}
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-3">
              {!running ? (
                <Button size="lg" onClick={start} className="min-w-32">
                  <Play className="size-5" /> Mulai
                </Button>
              ) : (
                <Button size="lg" variant="outline" onClick={pause} className="min-w-32">
                  <Pause className="size-5" /> Jeda
                </Button>
              )}
              <Button size="lg" variant="ghost" onClick={reset} className="px-3">
                <RotateCcw className="size-5" />
              </Button>
            </div>

            {/* Task selector */}
            <div className="w-full max-w-sm">
              <Select value={taskId} onValueChange={setTaskId}>
                <SelectTrigger><SelectValue placeholder="Pilih tugas (opsional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Tanpa tugas —</SelectItem>
                  {tasks?.map((t) => <SelectItem key={t.id} value={t.id}>{t.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Session stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 text-center">
          <Timer className="size-5 mx-auto text-primary mb-1" />
          <div className="text-2xl font-bold tabular-nums">{cycles}</div>
          <div className="text-[11px] text-muted-foreground">Sesi selesai</div>
        </Card>
        <Card className="p-4 text-center">
          <Brain className="size-5 mx-auto text-primary mb-1" />
          <div className="text-2xl font-bold tabular-nums">{totalFocusMins}<span className="text-sm text-muted-foreground">m</span></div>
          <div className="text-[11px] text-muted-foreground">Total fokus</div>
        </Card>
        <Card className="p-4 text-center">
          <Coffee className="size-5 mx-auto text-high mb-1" />
          <div className="text-2xl font-bold tabular-nums">{cycles * preset.break}</div>
          <div className="text-[11px] text-muted-foreground">Menit istirahat</div>
        </Card>
      </div>

      {/* Tips */}
      <Card className="bg-muted/30">
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground leading-relaxed">
            <strong className="text-foreground">Tips Pomodoro:</strong> Selama sesi fokus, hindari semua distraksi. Jangan buka media sosial. Saat istirahat, berdiri, regangkan tubuh, atau minum air. Setelah 4 sesi, ambil istirahat panjang (15-30 menit).
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
