"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Course } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Award, Plus, Trash2, TrendingUp, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const LETTER_GRADES = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "E"];
const GRADE_COLORS: Record<string, string> = {
  A: "text-success", "A-": "text-success", "B+": "text-success",
  B: "text-primary-strong", "B-": "text-primary-strong", "C+": "text-primary-strong",
  C: "text-high", "C-": "text-high", D: "text-urgent", E: "text-urgent",
};

type CourseGrade = {
  course: Course;
  components: { id: string; componentName: string; weight: number | null; score: number | null; letterGrade: string | null }[];
  finalGrade: number | null;
  letterGrade: string | null;
  gradePoint: number | null;
  sks: number | null;
};

export function GradesView() {
  const qc = useQueryClient();
  const [addCourseId, setAddCourseId] = useState<string | null>(null);
  const [expandedCourse, setExpandedCourse] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: apiKeys.grades(),
    queryFn: () => fetchApi<{
      courseGrades: CourseGrade[];
      ipk: number | null;
      totalSks: number;
    }>("/api/grades").then((r) => ({ courseGrades: r.courseGrades, ipk: r.ipk, totalSks: r.totalSks })),
  });
  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });

  const delGrade = useMutation({
    mutationFn: (id: string) => fetchApi(`/api/grades/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.grades() }); toast.success("Komponen dihapus"); },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Nilai & IPK</h1>
          <p className="text-sm text-muted-foreground">Pantau komponen nilai dan IPK</p>
        </div>
        <Button onClick={() => courses && courses.length > 0 && setAddCourseId(courses[0].id)} disabled={!courses?.length}>
          <Plus className="size-4" /> Tambah
        </Button>
      </div>

      {/* IPK Hero */}
      {data && (
        <div className="grid gap-4 sm:grid-cols-3">
          <Card className="sm:col-span-1 bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground font-medium uppercase">IPK</p>
                  <div className="text-4xl font-bold tabular-nums mt-1 text-primary-strong">
                    {data.ipk !== null ? data.ipk.toFixed(2) : "—"}
                  </div>
                </div>
                <div className="size-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Award className="size-7 text-primary" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">{data.totalSks} SKS total</p>
            </CardContent>
          </Card>
          <Card className="sm:col-span-2">
            <CardContent className="p-5">
              <p className="text-xs text-muted-foreground font-medium uppercase mb-3">Distribusi Nilai</p>
              {data.courseGrades.filter((c) => c.letterGrade).length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {data.courseGrades.filter((c) => c.letterGrade).map((c) => (
                    <div key={c.course.id} className="flex items-center gap-2 rounded-lg border px-3 py-1.5">
                      <span className={cn("text-sm font-bold", GRADE_COLORS[c.letterGrade!] ?? "text-foreground")}>{c.letterGrade}</span>
                      <span className="text-xs text-muted-foreground truncate max-w-[120px]">{c.course.name}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-4 text-center">Belum ada nilai yang dicatat.</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Course grades */}
      {isLoading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28" />)}</div>
      ) : !data || data.courseGrades.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
          <GraduationCap className="size-8 mx-auto mb-2 opacity-40" />
          Belum ada mata kuliah. Tambahkan mata kuliah dahulu.
        </Card>
      ) : (
        <div className="space-y-3">
          {data.courseGrades.map((cg) => {
            const hasGrades = cg.components.length > 0;
            const isExpanded = expandedCourse === cg.course.id;
            return (
              <Card key={cg.course.id}>
                <CardContent className="p-4">
                  <button
                    onClick={() => hasGrades && setExpandedCourse(isExpanded ? null : cg.course.id)}
                    className="w-full flex items-center gap-3 text-left"
                  >
                    <div className="size-3 rounded-full shrink-0" style={{ backgroundColor: cg.course.color || "var(--primary)" }} />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold truncate">{cg.course.name}</p>
                      {cg.course.sks && <p className="text-xs text-muted-foreground">{cg.course.sks} SKS</p>}
                    </div>
                    {cg.letterGrade ? (
                      <div className="text-right shrink-0">
                        <div className={cn("text-2xl font-bold tabular-nums", GRADE_COLORS[cg.letterGrade] ?? "text-foreground")}>{cg.letterGrade}</div>
                        {cg.finalGrade !== null && <div className="text-[10px] text-muted-foreground tabular-nums">{cg.finalGrade.toFixed(1)}</div>}
                      </div>
                    ) : (
                      <Badge variant="outline" className="text-[10px]">Belum ada nilai</Badge>
                    )}
                  </button>
                  {isExpanded && hasGrades && (
                    <div className="mt-3 pt-3 border-t space-y-1.5">
                      {cg.components.map((comp) => (
                        <div key={comp.id} className="flex items-center gap-2 text-sm">
                          <span className="flex-1 truncate">{comp.componentName}</span>
                          {comp.weight && <span className="text-xs text-muted-foreground">{comp.weight}%</span>}
                          {comp.score !== null && <span className="tabular-nums font-medium">{comp.score}</span>}
                          {comp.letterGrade && <Badge variant="secondary" className={cn("text-[10px]", GRADE_COLORS[comp.letterGrade] ?? "")}>{comp.letterGrade}</Badge>}
                          <Button variant="ghost" size="icon" className="size-7" onClick={() => delGrade.mutate(comp.id)}><Trash2 className="size-3" /></Button>
                        </div>
                      ))}
                      <Button variant="ghost" size="sm" className="w-full mt-2" onClick={() => setAddCourseId(cg.course.id)}>
                        <Plus className="size-3.5" /> Tambah Komponen
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Sheet open={Boolean(addCourseId)} onOpenChange={(o) => { if (!o) setAddCourseId(null); }}>
        <SheetContent className="w-full sm:max-w-md">
          <SheetHeader><SheetTitle>Tambah Komponen Nilai</SheetTitle></SheetHeader>
          {addCourseId ? <AddGradeContent key={addCourseId} initialCourseId={addCourseId} courses={courses ?? []} onClose={() => setAddCourseId(null)} /> : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function AddGradeContent({ initialCourseId, courses }: { initialCourseId: string; courses: Course[]; onClose: () => void }) {
  const qc = useQueryClient();
  const [selectedCourse, setSelectedCourse] = useState(initialCourseId);
  const [componentName, setComponentName] = useState("");
  const [weight, setWeight] = useState("");
  const [score, setScore] = useState("");
  const [letterGrade, setLetterGrade] = useState("none");

  const save = useMutation({
    mutationFn: () => fetchApi("/api/grades", { method: "POST", json: {
      courseId: selectedCourse,
      componentName: componentName.trim(),
      weight: weight ? Number(weight) : null,
      score: score ? Number(score) : null,
      letterGrade: letterGrade === "none" ? null : letterGrade,
    } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.grades() }); toast.success("Nilai ditambahkan"); setComponentName(""); setWeight(""); setScore(""); setLetterGrade("none"); },
  });

  return (
    <div className="space-y-3 px-4 pb-6">
      <div className="space-y-1.5">
        <Label>Mata Kuliah</Label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
          {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div className="space-y-1.5">
        <Label>Komponen</Label>
        <Input value={componentName} onChange={(e) => setComponentName(e.target.value)} placeholder="Mis. UTS, Tugas 1, Quiz" autoFocus />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>Bobot (%)</Label>
          <Input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="30" min={0} max={100} />
        </div>
        <div className="space-y-1.5">
          <Label>Nilai (0-100)</Label>
          <Input type="number" value={score} onChange={(e) => setScore(e.target.value)} placeholder="85" min={0} max={100} />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Nilai Huruf (opsional)</Label>
        <Select value={letterGrade} onValueChange={setLetterGrade}>
          <SelectTrigger><SelectValue placeholder="Otomatis dari nilai" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="none">— Otomatis —</SelectItem>
            {LETTER_GRADES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <SheetFooter><Button onClick={() => save.mutate()} disabled={save.isPending || !componentName.trim() || !selectedCourse} className="w-full"><Plus className="size-4" /> Tambah</Button></SheetFooter>
    </div>
  );
}
