"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Course, AcademicTerm, ClassSchedule } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { DAYS, DAYS_SHORT, COURSE_COLORS } from "@/lib/constants";
import { formatTime } from "@/lib/date";
import { useApp } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Trash2, GraduationCap, Clock, MapPin, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { CourseDetailView } from "@/components/views/course-detail-view";
import { EmptyState } from "@/components/empty-state";

export function CoursesView() {
  const { activeCourseId, setActiveCourseId } = useApp();
  const qc = useQueryClient();
  const [newOpen, setNewOpen] = useState(false);

  const { data: courses, isLoading } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });
  const { data: terms } = useQuery({
    queryKey: apiKeys.terms(),
    queryFn: () => fetchApi<{ terms: AcademicTerm[] }>("/api/terms").then((r) => r.terms),
  });
  const activeTerm = terms?.find((t) => t.isActive);

  const activeCourse = courses?.find((c) => c.id === activeCourseId);

  // If a course is selected, show the full detail view
  if (activeCourseId && activeCourse) {
    return <CourseDetailView courseId={activeCourseId} onBack={() => setActiveCourseId(null)} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mata Kuliah</h1>
          <p className="text-sm text-muted-foreground">{activeTerm?.name ?? "Tanpa semester aktif"}</p>
        </div>
        <Button onClick={()=>setNewOpen(true)}><Plus className="size-4" /> Tambah</Button>
      </div>

      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2">{[...Array(4)].map((_,i)=><Skeleton key={i} className="h-28" />)}</div>
      ) : courses?.length === 0 ? (
        <EmptyState
          icon={GraduationCap}
          title="Belum ada mata kuliah"
          description="Tambahkan mata kuliah pertamamu untuk mulai mengatur jadwal, tugas, dan catatan."
          action={{ label: "Tambah Mata Kuliah", onClick: () => setNewOpen(true) }}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {courses?.map((c) => (
            <button key={c.id} onClick={()=>setActiveCourseId(c.id)} className="text-left">
              <Card className="hover:shadow-md transition overflow-hidden h-full group">
                <CardContent className="p-4 h-full flex flex-col">
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className="size-11 rounded-xl flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-sm"
                      style={{ backgroundColor: c.color || "var(--primary)" }}
                    >
                      {(c.code || c.name).slice(0, 2).toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold truncate leading-tight">{c.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        {c.code && <Badge variant="secondary" className="text-[10px] px-1.5 py-0 font-mono">{c.code}</Badge>}
                        {c.sks && <span>{c.sks} SKS</span>}
                      </div>
                    </div>
                  </div>
                  {c.lecturer && (
                    <p className="text-xs text-muted-foreground truncate mb-2 flex items-center gap-1">
                      <span className="size-1.5 rounded-full bg-muted-foreground/40" />
                      {c.lecturer}
                    </p>
                  )}
                  <div className="flex items-center gap-3 mt-auto pt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <CheckSquare className="size-3.5" />
                      {c._count?.tasks ?? 0} tugas
                    </span>
                    <span className="text-muted-foreground/40">·</span>
                    <span className="group-hover:text-primary transition-colors flex items-center gap-1">
                      Lihat detail →
                    </span>
                  </div>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      )}

      <CourseDialog open={newOpen} onOpenChange={setNewOpen} terms={terms ?? []} />
    </div>
  );
}

function CheckSquare() { return <Clock className="size-3" />; }

function CourseDetailSheet({ course, onClose }: { course: Course | undefined; onClose: () => void }) {
  const qc = useQueryClient();
  const [day, setDay] = useState("1");
  const [start, setStart] = useState("08:00");
  const [end, setEnd] = useState("09:40");
  const [room, setRoom] = useState("");

  const { data: schedules } = useQuery({
    queryKey: apiKeys.courseSchedules(course?.id ?? ""),
    queryFn: () => course ? fetchApi<{ schedules: ClassSchedule[] }>(`/api/courses/${course.id}/schedule`).then(r=>r.schedules) : [],
    enabled: Boolean(course?.id),
  });

  const addSched = useMutation({
    mutationFn: () => fetchApi(`/api/courses/${course!.id}/schedule`, { method: "POST", json: { dayOfWeek: Number(day), startTime: start, endTime: end, room: room || null } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.courseSchedules(course!.id) }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); setRoom(""); toast.success("Jadwal ditambahkan"); },
  });
  const delSched = useMutation({
    mutationFn: (id: string) => fetchApi(`/api/schedules/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.courseSchedules(course!.id) }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); },
  });
  const delCourse = useMutation({
    mutationFn: () => fetchApi(`/api/courses/${course!.id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.courses() }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); toast.success("Mata kuliah dihapus"); onClose(); },
  });

  return (
    <Sheet open={Boolean(course)} onOpenChange={(o)=>{ if(!o) onClose(); }}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto scroll-area-thin">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <span className="size-3 rounded-full" style={{ backgroundColor: course?.color || "var(--primary)" }} />
            {course?.name}
          </SheetTitle>
        </SheetHeader>
        {course && (
          <div className="space-y-4 px-4 pb-6">
            <div className="grid grid-cols-2 gap-3 text-sm">
              {course.code && <div><p className="text-xs text-muted-foreground">Kode</p><p className="font-medium">{course.code}</p></div>}
              {course.sks && <div><p className="text-xs text-muted-foreground">SKS</p><p className="font-medium">{course.sks}</p></div>}
              {course.lecturer && <div className="col-span-2"><p className="text-xs text-muted-foreground">Dosen</p><p className="font-medium">{course.lecturer}</p></div>}
              {course.defaultRoom && <div><p className="text-xs text-muted-foreground">Ruang</p><p className="font-medium">{course.defaultRoom}</p></div>}
            </div>
            {course.onlineUrl && <a href={course.onlineUrl} target="_blank" rel="noreferrer" className="block text-sm text-primary hover:underline">Link Online →</a>}

            <div className="space-y-2">
              <Label className="text-xs font-semibold uppercase text-muted-foreground">Jadwal Mingguan</Label>
              {schedules?.length === 0 && <p className="text-xs text-muted-foreground">Belum ada jadwal.</p>}
              {schedules?.map((s) => (
                <div key={s.id} className="flex items-center gap-2 rounded-md bg-muted/50 px-3 py-2">
                  <Badge variant="outline" className="text-[10px]">{DAYS_SHORT[s.dayOfWeek]}</Badge>
                  <span className="text-sm tabular-nums">{s.startTime}–{s.endTime}</span>
                  {s.room && <span className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="size-3" />{s.room}</span>}
                  <Button variant="ghost" size="icon" className="size-7 ml-auto" onClick={()=>delSched.mutate(s.id)}><Trash2 className="size-3.5" /></Button>
                </div>
              ))}
              <div className="grid grid-cols-[80px_1fr_1fr_1fr] gap-2 pt-1">
                <Select value={day} onValueChange={setDay}><SelectTrigger className="h-9"><SelectValue /></SelectTrigger><SelectContent>{DAYS.map((d,i)=><SelectItem key={i} value={String(i)}>{DAYS_SHORT[i]}</SelectItem>)}</SelectContent></Select>
                <Input type="time" value={start} onChange={(e)=>setStart(e.target.value)} className="h-9" />
                <Input type="time" value={end} onChange={(e)=>setEnd(e.target.value)} className="h-9" />
                <Button size="sm" variant="secondary" onClick={()=>addSched.mutate()} disabled={addSched.isPending}><Plus className="size-4" /></Button>
              </div>
              <Input value={room} onChange={(e)=>setRoom(e.target.value)} placeholder="Ruang (opsional)" className="h-9" />
            </div>

            <SheetFooter className="flex-row sm:justify-start">
              <Button variant="destructive" size="sm" onClick={()=>delCourse.mutate()}><Trash2 className="size-4" /> Hapus Mata Kuliah</Button>
            </SheetFooter>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}

function CourseDialog({ open, onOpenChange, terms }: { open: boolean; onOpenChange: (o:boolean)=>void; terms: AcademicTerm[] }) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [lecturer, setLecturer] = useState("");
  const [sks, setSks] = useState("");
  const [color, setColor] = useState(COURSE_COLORS[0]);
  const [termId, setTermId] = useState("none");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setLoading(true);
    try {
      await fetchApi("/api/courses", { method: "POST", json: { name: name.trim(), code: code||null, lecturer: lecturer||null, sks: sks?Number(sks):null, color, academicTermId: termId==="none"?null:termId } });
      qc.invalidateQueries({ queryKey: apiKeys.courses() });
      toast.success("Mata kuliah ditambahkan");
      setName(""); setCode(""); setLecturer(""); setSks("");
      onOpenChange(false);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setLoading(false); }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader><SheetTitle>Mata Kuliah Baru</SheetTitle></SheetHeader>
        <form onSubmit={submit} className="space-y-3 px-4 pb-6">
          <div className="space-y-1.5"><Label>Nama</Label><Input value={name} onChange={(e)=>setName(e.target.value)} placeholder="Hukum Pidana" autoFocus required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Kode</Label><Input value={code} onChange={(e)=>setCode(e.target.value)} placeholder="HP" /></div>
            <div className="space-y-1.5"><Label>SKS</Label><Input type="number" value={sks} onChange={(e)=>setSks(e.target.value)} min={0} max={12} placeholder="3" /></div>
          </div>
          <div className="space-y-1.5"><Label>Dosen</Label><Input value={lecturer} onChange={(e)=>setLecturer(e.target.value)} placeholder="Nama dosen" /></div>
          <div className="space-y-1.5">
            <Label>Semester</Label>
            <Select value={termId} onValueChange={setTermId}><SelectTrigger><SelectValue placeholder="—" /></SelectTrigger><SelectContent>
              <SelectItem value="none">— Tanpa semester —</SelectItem>
              {terms.map((t)=><SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
            </SelectContent></Select></div>
          <div className="space-y-1.5"><Label>Warna</Label><div className="flex gap-2 flex-wrap">{COURSE_COLORS.map((c)=>(<button type="button" key={c} onClick={()=>setColor(c)} className={cn("size-7 rounded-full transition", color===c && "ring-2 ring-offset-2 ring-ring")} style={{ backgroundColor: c }} />))}</div></div>
          <SheetFooter><Button type="submit" disabled={loading} className="w-full"><Plus className="size-4" /> Tambah</Button></SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
