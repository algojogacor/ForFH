"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { features } from "@/lib/env-features";
import { toast } from "sonner";
import { Scale, Search, Bookmark, Trash2, Loader2, ExternalLink, AlertCircle, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { EmptyState } from "@/components/empty-state";

const TYPE_OPTIONS = [
  { value: "UU", label: "UU" }, { value: "PERPPU", label: "Perppu" }, { value: "PP", label: "PP" },
  { value: "PERPRES", label: "Perpres" }, { value: "KEPPRES", label: "Keppres" }, { value: "PERMEN", label: "Permen" },
  { value: "PMK", label: "PMK" }, { value: "PERGUB", label: "Pergub" }, { value: "PERDA", label: "Perda" },
];

type SearchResult = { frbr_uri: string; title: string; type: string | null; number: string | null; year: number | null; status: string | null; snippet: string | null };
type LawDetail = { title?: string; type?: string; number?: string; year?: number; status?: string; status_uncertain?: boolean; articles?: { number?: string; text?: string }[]; relationships?: unknown[]; content_verified?: boolean };

export function LegalView() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [type, setType] = useState("all");
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<{ uri: string; title: string } | null>(null);
  const [bookmarkedUris, setBookmarkedUris] = useState<Set<string>>(new Set());

  const { data: bookmarks } = useQuery({
    queryKey: apiKeys.legalBookmarks(),
    queryFn: () => fetchApi<{ bookmarks: { id: string; frbrUri: string; title: string; type: string | null; year: number | null }[] }>("/api/legal/bookmarks").then((r) => r.bookmarks),
  });

  // sync bookmarked uris
  useEffect(() => {
    if (bookmarks && bookmarks.length > 0) {
      setBookmarkedUris(new Set(bookmarks.map((b) => b.frbrUri)));
    }
  }, [bookmarks]);

  const legalAvailable = features.pasal;

  async function search(e?: React.FormEvent) {
    e?.preventDefault();
    if (q.trim().length < 2) return;
    setSearching(true);
    setResults(null);
    try {
      const r = await fetchApi<{ results: SearchResult[]; available: boolean }>(`/api/legal?q=${encodeURIComponent(q)}${type !== "all" ? `&type=${type}` : ""}`);
      if (!r.available) { toast.info("Pasal.id belum dikonfigurasi. Hubungkan API token di .env."); }
      setResults(r.results);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setSearching(false); }
  }

  const bookmark = useMutation({
    mutationFn: (r: SearchResult) => fetchApi("/api/legal/bookmarks", { method: "POST", json: { frbrUri: r.frbr_uri, title: r.title, type: r.type, number: r.number, year: r.year } }),
    onSuccess: (_, r) => { setBookmarkedUris((p)=>new Set(p).add(r.frbr_uri)); qc.invalidateQueries({ queryKey: apiKeys.legalBookmarks() }); toast.success("Disimpan ke bookmark"); },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Hukum</h1>
        <p className="text-sm text-muted-foreground">Cari peraturan Indonesia via Pasal.id</p>
      </div>

      {!legalAvailable && (
        <Card className="p-3 border-amber-400/40 bg-amber-50 dark:bg-amber-950/20 flex items-center gap-2 text-sm">
          <AlertCircle className="size-4 text-amber-600 shrink-0" />
          <span className="text-amber-900 dark:text-amber-200">Pasal.id belum dikonfigurasi. Token API dibutuhkan untuk pencarian hukum.</span>
        </Card>
      )}

      <form onSubmit={search} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <Input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Cari: wanprestasi, ketenagakerjaan..." className="pl-9" />
        </div>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua</SelectItem>
            {TYPE_OPTIONS.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button type="submit" disabled={searching || q.trim().length<2}>{searching ? <Loader2 className="size-4 animate-spin" /> : "Cari"}</Button>
      </form>

      {/* Bookmarks */}
      {bookmarks && bookmarks.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase text-muted-foreground mb-2">Bookmark Saya</p>
          <div className="flex flex-wrap gap-2">
            {bookmarks.map((b) => (
              <button key={b.id} onClick={()=>setDetail({ uri: b.frbrUri, title: b.title })} className="text-xs bg-secondary text-secondary-foreground px-2.5 py-1.5 rounded-md hover:bg-secondary/70 flex items-center gap-1.5">
                <Bookmark className="size-3 fill-current" /> {b.title}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {results === null && !searching && bookmarks?.length === 0 && (
        <EmptyState
          icon={Scale}
          title="Cari Peraturan Indonesia"
          description="Telusuri UU, PP, Perpres, Permen, dan peraturan lainnya via Pasal.id. Lihat metadata, artikel, dan dapatkan penjelasan AI."
          className="mt-4"
        />
      )}
      {results === null && !searching && legalAvailable && (
        <div className="mt-4">
          <p className="text-xs font-semibold uppercase text-muted-foreground mb-2">Coba Pencarian Populer</p>
          <div className="flex flex-wrap gap-2">
            {["wanprestasi", "ketenagakerjaan", "perlindungan konsumen", "HAM", "pidana korupsi"].map((s) => (
              <button
                key={s}
                onClick={() => { setQ(s); setTimeout(() => search(), 100); }}
                className="text-xs bg-secondary text-secondary-foreground px-3 py-1.5 rounded-full hover:bg-secondary/70 transition"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      )}
      {results !== null && (
        <div className="space-y-2">
          {results.length === 0 ? (
            <EmptyState
              icon={Scale}
              title="Tidak ada hasil"
              description={`Tidak ditemukan peraturan untuk "${q}". Coba kata kunci lain atau ubah filter tipe.`}
              compact
            />
          ) : (
            results.map((r) => (
              <Card key={r.frbr_uri} className="p-3.5 hover:shadow-sm transition">
                <div className="flex items-start gap-3">
                  <Scale className="size-4 text-primary mt-0.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <button onClick={()=>setDetail({ uri: r.frbr_uri, title: r.title })} className="text-left">
                      <p className="font-medium hover:text-primary">{r.title}</p>
                    </button>
                    <div className="flex items-center gap-2 mt-1 flex-wrap text-xs text-muted-foreground">
                      {r.type && <Badge variant="outline" className="text-[10px]">{r.type}</Badge>}
                      {r.number && <span>No. {r.number}</span>}
                      {r.year && <span>{r.year}</span>}
                      {r.status && <Badge variant="secondary" className={cn("text-[10px]", r.status === "berlaku" && "bg-success/10 text-success")}>{r.status}</Badge>}
                    </div>
                    {r.snippet && <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">{r.snippet}</p>}
                  </div>
                  <Button variant="ghost" size="icon" className="size-8 shrink-0" onClick={()=>bookmark.mutate(r)} disabled={bookmarkedUris.has(r.frbr_uri)}>
                    <Bookmark className={cn("size-4", bookmarkedUris.has(r.frbr_uri) && "fill-primary text-primary")} />
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>
      )}

      <LawDetailSheet detail={detail} onClose={()=>setDetail(null)} />
    </div>
  );
}

function LawDetailSheet({ detail, onClose }: { detail: { uri: string; title: string } | null; onClose: () => void }) {
  const [explain, setExplain] = useState<string | null>(null);
  const [explaining, setExplaining] = useState(false);

  const { data: law, isLoading } = useQuery({
    queryKey: ["legalDetail", detail?.uri],
    queryFn: () => detail ? fetchApi<{ law: LawDetail | null; available: boolean }>(`/api/legal/detail?uri=${encodeURIComponent(detail.uri)}`).then((r) => r.law) : null,
    enabled: Boolean(detail?.uri),
  });

  useEffect(() => { setExplain(null); }, [detail?.uri]);

  const explainLaw = async () => {
    if (!law || !detail) return;
    setExplaining(true);
    try {
      const articles = (law.articles ?? []).slice(0, 8).map((a) => `Pasal ${a.number}: ${a.text}`).join("\n");
      const r = await fetchApi<{ insight: string; available: boolean }>("/api/ai/legal-explain", { method: "POST", json: { title: detail.title, articles } });
      setExplain(r.insight);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setExplaining(false); }
  };

  return (
    <Sheet open={Boolean(detail)} onOpenChange={(o)=>{ if(!o){ setExplain(null); onClose(); } }}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto scroll-area-thin">
        <SheetHeader><SheetTitle className="text-left">{detail?.title}</SheetTitle></SheetHeader>
        <div className="px-4 pb-6 space-y-3">
          {isLoading ? <Skeleton className="h-40" /> : law ? (
            <>
              <div className="flex items-center gap-2 flex-wrap text-xs">
                {law.type && <Badge variant="outline">{law.type}</Badge>}
                {law.number && <span>No. {law.number}</span>}
                {law.year && <span>{law.year}</span>}
                {law.status && <Badge variant="secondary" className={cn(law.status==="berlaku" && "bg-success/10 text-success")}>{law.status}</Badge>}
                {law.status_uncertain && <Badge variant="outline" className="text-amber-600 border-amber-400/40">status belum pasti</Badge>}
                {law.content_verified && <Badge variant="outline" className="text-success border-success/30">terverifikasi</Badge>}
              </div>
              <Button variant="outline" size="sm" onClick={explainLaw} disabled={explaining || !features.ai}>
                <Sparkles className="size-4" /> {explaining ? "Menjelaskan..." : "Jelaskan dengan AI"}
              </Button>
              {explain && (
                <Card className="p-4 bg-primary/5 border-primary/20">
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{explain}</p>
                  <p className="text-[11px] text-muted-foreground mt-3">Penjelasan akademik, bukan nasihat hukum profesional.</p>
                </Card>
              )}
              {law.articles && law.articles.length > 0 ? (
                <div className="space-y-2">
                  {law.articles.map((a, i) => (
                    <div key={i} className="rounded-md border p-3">
                      {a.number && <p className="text-xs font-semibold text-primary mb-1">Pasal {a.number}</p>}
                      <p className="text-sm whitespace-pre-wrap">{a.text}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Tidak ada artikel tersedia.</p>
              )}
            </>
          ) : <p className="text-sm text-muted-foreground">Tidak dapat memuat detail.</p>}
        </div>
      </SheetContent>
    </Sheet>
  );
}
