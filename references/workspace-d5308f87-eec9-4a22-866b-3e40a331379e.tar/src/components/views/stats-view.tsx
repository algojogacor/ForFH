"use client";

import { useQuery } from "@tanstack/react-query";
import { fetchApi } from "@/lib/fetch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle2, Clock, AlertTriangle, CircleDashed, TrendingUp, Zap,
  GraduationCap, BookOpen, Library, BookMarked, BarChart3, Sparkles,
  Flame, Trophy, Target,
} from "lucide-react";
import { cn } from "@/lib/utils";

type StreakData = {
  currentStreak: number;
  longestStreak: number;
  totalCompleted: number;
  achievements: { id: string; label: string; description: string; icon: string; unlocked: boolean }[];
  lastCompletionDate: string | null;
};

type Stats = {
  totals: { courses: number; notes: number; exams: number; readings: number; tasks: number };
  taskStatus: Record<string, number>;
  taskPriority: Record<string, number>;
  taskType: Record<string, number>;
  completionTrend: { date: string; completed: number }[];
  totalEstimatedMinutes: number;
  aiStats: { total: number; success: number; byType: Record<string, number>; avgLatency: number };
};

export function StatsView() {
  const { data, isLoading } = useQuery({
    queryKey: ["stats"],
    queryFn: () => fetchApi<Stats>("/api/stats"),
  });
  const { data: streak } = useQuery<StreakData>({
    queryKey: ["streak"],
    queryFn: () => fetchApi<StreakData>("/api/streak"),
  });

  if (isLoading || !data) {
    return <div className="space-y-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}</div>;
  }

  const totalTasks = Object.values(data.taskStatus).reduce((a, b) => a + b, 0);
  const completionRate = totalTasks > 0 ? Math.round((data.taskStatus.DONE / totalTasks) * 100) : 0;
  const activeTasks = (data.taskStatus.NOT_STARTED ?? 0) + (data.taskStatus.IN_PROGRESS ?? 0) + (data.taskStatus.REVISION ?? 0);
  const maxTrend = Math.max(...data.completionTrend.map((d) => d.completed), 1);
  const aiSuccessRate = data.aiStats.total > 0 ? Math.round((data.aiStats.success / data.aiStats.total) * 100) : 0;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Statistik</h1>
        <p className="text-sm text-muted-foreground">Ringkasan aktivitas akademikmu</p>
      </div>

      {/* Totals row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <TotalCard icon={GraduationCap} label="Mata Kuliah" value={data.totals.courses} tone="primary" />
        <TotalCard icon={CheckCircle2} label="Tugas" value={data.totals.tasks} tone="default" />
        <TotalCard icon={BookOpen} label="Catatan" value={data.totals.notes} tone="default" />
        <TotalCard icon={Library} label="Ujian" value={data.totals.exams} tone="default" />
        <TotalCard icon={BookMarked} label="Bacaan" value={data.totals.readings} tone="default" />
        <TotalCard icon={CheckCircle2} label="Selesai" value={data.taskStatus.DONE} tone="success" />
      </div>

      {/* Streak + Achievements */}
      {streak && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="bg-gradient-to-br from-primary/10 via-card to-card border-primary/20">
            <CardContent className="p-5 flex items-center gap-4">
              <div className="size-12 rounded-2xl bg-primary/15 flex items-center justify-center shrink-0">
                <Flame className="size-6 text-primary" />
              </div>
              <div>
                <div className="text-3xl font-bold tabular-nums leading-none">{streak.currentStreak}</div>
                <div className="text-xs text-muted-foreground mt-1">Hari beruntun saat ini</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="size-12 rounded-2xl bg-high/15 flex items-center justify-center shrink-0">
                <Trophy className="size-6 text-high" />
              </div>
              <div>
                <div className="text-3xl font-bold tabular-nums leading-none">{streak.longestStreak}</div>
                <div className="text-xs text-muted-foreground mt-1">Rekor terpanjang</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="size-12 rounded-2xl bg-success/15 flex items-center justify-center shrink-0">
                <Target className="size-6 text-success" />
              </div>
              <div>
                <div className="text-3xl font-bold tabular-nums leading-none">{streak.totalCompleted}</div>
                <div className="text-xs text-muted-foreground mt-1">Total tugas selesai</div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Achievements */}
      {streak && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Trophy className="size-4 text-high" /> Pencapaian
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {streak.achievements.map((a) => (
                <div
                  key={a.id}
                  className={cn(
                    "rounded-xl border p-3 text-center transition",
                    a.unlocked ? "border-primary/30 bg-primary/5" : "border-border opacity-50",
                  )}
                >
                  <div className="text-2xl mb-1">{a.icon}</div>
                  <div className="text-xs font-semibold leading-tight">{a.label}</div>
                  <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{a.description}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Completion + estimated time */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="bg-gradient-to-br from-primary/5 via-card to-card border-primary/20">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-muted-foreground font-medium uppercase">Tingkat Penyelesaian</p>
              <TrendingUp className="size-4 text-primary" />
            </div>
            <div className="text-4xl font-bold tabular-nums text-primary-strong">{completionRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">{data.taskStatus.DONE} selesai dari {totalTasks} total</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-muted-foreground font-medium uppercase">Estimasi Waktu</p>
              <Clock className="size-4 text-muted-foreground" />
            </div>
            <div className="text-4xl font-bold tabular-nums">{Math.floor(data.totalEstimatedMinutes / 60)}<span className="text-lg text-muted-foreground">j</span></div>
            <p className="text-xs text-muted-foreground mt-1">{activeTasks} tugas aktif tersisa</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-muted-foreground font-medium uppercase">AI Usage</p>
              <Sparkles className="size-4 text-primary" />
            </div>
            <div className="text-4xl font-bold tabular-nums">{data.aiStats.total}</div>
            <p className="text-xs text-muted-foreground mt-1">{aiSuccessRate}% sukses · avg {data.aiStats.avgLatency}ms</p>
          </CardContent>
        </Card>
      </div>

      {/* Completion trend chart */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <BarChart3 className="size-4" /> Tren Penyelesaian (14 Hari)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-end justify-between gap-1 h-32">
            {data.completionTrend.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
                <div className="w-full flex-1 flex items-end">
                  <div
                    className={cn("w-full rounded-t transition-all", d.completed > 0 ? "bg-primary" : "bg-muted")}
                    style={{ height: `${Math.max((d.completed / maxTrend) * 100, 4)}%` }}
                    title={`${d.date}: ${d.completed} tugas`}
                  />
                </div>
                <span className="text-[9px] text-muted-foreground tabular-nums">{new Date(d.date).getDate()}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Task breakdowns */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Status breakdown */}
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Status Tugas</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <StatusBar icon={CircleDashed} label="Belum Mulai" count={data.taskStatus.NOT_STARTED} total={totalTasks} color="text-muted-foreground" barClass="bg-muted-foreground" />
            <StatusBar icon={Clock} label="Berjalan" count={data.taskStatus.IN_PROGRESS} total={totalTasks} color="text-medium" barClass="bg-medium" />
            <StatusBar icon={AlertTriangle} label="Revisi" count={data.taskStatus.REVISION} total={totalTasks} color="text-high" barClass="bg-high" />
            <StatusBar icon={CheckCircle2} label="Selesai" count={data.taskStatus.DONE} total={totalTasks} color="text-success" barClass="bg-success" />
            <StatusBar icon={AlertTriangle} label="Terlambat" count={data.taskStatus.OVERDUE} total={totalTasks} color="text-urgent" barClass="bg-urgent" />
          </CardContent>
        </Card>

        {/* Priority breakdown */}
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm font-semibold">Prioritas (Aktif)</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <StatusBar icon={Zap} label="Mendesak" count={data.taskPriority.urgent} total={activeTasks} color="text-urgent" barClass="bg-urgent" />
            <StatusBar icon={TrendingUp} label="Tinggi" count={data.taskPriority.high} total={activeTasks} color="text-high" barClass="bg-high" />
            <StatusBar icon={Clock} label="Sedang" count={data.taskPriority.medium} total={activeTasks} color="text-medium" barClass="bg-medium" />
            <StatusBar icon={CircleDashed} label="Rendah" count={data.taskPriority.low} total={activeTasks} color="text-muted-foreground" barClass="bg-muted-foreground" />
          </CardContent>
        </Card>
      </div>

      {/* AI usage by type */}
      {data.aiStats.total > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="size-4 text-primary" /> Penggunaan AI per Fitur
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {Object.entries(data.aiStats.byType).map(([type, count]) => (
                <Badge key={type} variant="secondary" className="text-xs">
                  {type.replace(/_/g, " ")}: {count}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function TotalCard({ icon: Icon, label, value, tone }: { icon: typeof Clock; label: string; value: number; tone: "primary" | "default" | "success" }) {
  const toneClasses = {
    primary: "bg-primary/10 text-primary",
    default: "bg-muted text-muted-foreground",
    success: "bg-success/10 text-success",
  };
  return (
    <Card className="p-3.5">
      <div className={cn("size-9 rounded-lg flex items-center justify-center mb-2.5", toneClasses[tone])}>
        <Icon className="size-4.5" />
      </div>
      <div className="text-2xl font-bold tabular-nums leading-none">{value}</div>
      <div className="text-xs text-muted-foreground truncate mt-1 font-medium">{label}</div>
    </Card>
  );
}

function StatusBar({ icon: Icon, label, count, total, color, barClass }: { icon: typeof Clock; label: string; count: number; total: number; color: string; barClass: string }) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <div className="flex items-center gap-2.5">
      <Icon className={cn("size-4 shrink-0", color)} />
      <span className="text-sm flex-1">{label}</span>
      <span className="text-sm font-semibold tabular-nums w-8 text-right">{count}</span>
      <div className="w-20 h-1.5 rounded-full bg-muted overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", barClass)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
