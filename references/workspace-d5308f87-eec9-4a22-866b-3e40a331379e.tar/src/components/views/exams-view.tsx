"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Exam, Course, ExamTopic } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { EXAM_TYPES } from "@/lib/constants";
import { formatDateTime, relativeTime, toLocalInput, fromLocalInput } from "@/lib/date";
import { toast } from "sonner";
import { Plus, Library, Trash2, Loader2, CheckCircle2, Circle, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { EmptyState } from "@/components/empty-state";

export function ExamsView() {
  const qc = useQueryClient();
  const [newOpen, setNewOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  const { data: exams, isLoading } = useQuery({
    queryKey: apiKeys.exams(),
    queryFn: () => fetchApi<{ exams: Exam[] }>("/api/exams").then((r) => r.exams),
  });
  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });
  const editExam = exams?.find((e) => e.id === editId);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Ujian</h1>
          <p className="text-sm text-muted-foreground">{exams?.length ?? 0} ujian terjadwal</p>
        </div>
        <Button onClick={()=>setNewOpen(true)}><Plus className="size-4" /> Tambah</Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_,i)=><Skeleton key={i} className="h-24" />)}</div>
      ) : exams?.length === 0 ? (
        <EmptyState
          icon={Library}
          title="Belum ada ujian"
          description="Jadwalkan UTS, UAS, atau quiz untuk melacak hari tersisa dan progres belajar topik."
          action={{ label: "Tambah Ujian Pertama", onClick: () => setNewOpen(true) }}
        />
      ) : (
        <div className="space-y-2">
          {exams?.map((e) => {
            const daysUntil = Math.ceil((new Date(e.examAt).getTime() - Date.now()) / 86400000);
            const total = e._count?.topics ?? e.topics?.length ?? 0;
            const done = e.topics?.filter((t) => t.completed).length ?? 0;
            const progress = total ? Math.round((done/total)*100) : 0;
            return (
              <button key={e.id} onClick={()=>setEditId(e.id)} className="w-full text-left">
                <Card className={cn("p-4 hover:shadow-sm transition", daysUntil <= 3 && daysUntil >= 0 && "border-urgent/40")}>
                  <div className="flex items-start gap-3">
                    <div className={cn("text-center shrink-0 w-14 rounded-lg p-2", daysUntil < 0 ? "bg-muted text-muted-foreground" : daysUntil <= 3 ? "bg-urgent/10 text-urgent" : "bg-primary/10 text-primary")}>
                      <div className="text-lg font-bold leading-none">{daysUntil < 0 ? "—" : daysUntil}</div>
                      <div className="text-[10px]">{daysUntil < 0 ? "selesai" : "hari"}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium truncate flex-1">{e.name}</p>
                        <Badge variant="outline" className="text-[10px]">{e.type}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{e.course?.name} · {formatDateTime(e.examAt)}</p>
                      {total > 0 && (
                        <div className="mt-2">
                          <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1"><span>Topik: {done}/{total}</span><span>{progress}%</span></div>
                          <Progress value={progress} className="h-1" />
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              </button>
            );
          })}
        </div>
      )}

      <Sheet open={Boolean(editExam)} onOpenChange={(o)=>{ if(!o) setEditId(null); }}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto scroll-area-thin">
          <SheetHeader><SheetTitle>Detail Ujian</SheetTitle></SheetHeader>
          {editExam ? <ExamSheetContent key={editExam.id} exam={editExam} courses={courses ?? []} onClose={()=>setEditId(null)} /> : null}
        </SheetContent>
      </Sheet>
      <ExamDialog open={newOpen} onOpenChange={setNewOpen} courses={courses ?? []} />
    </div>
  );
}

function ExamSheetContent({ exam, courses, onClose }: { exam: Exam; courses: Course[]; onClose: () => void }) {
  const qc = useQueryClient();
  const [name, setName] = useState(exam.name);
  const [type, setType] = useState(exam.type);
  const [examAt, setExamAt] = useState(toLocalInput(exam.examAt));
  const [location, setLocation] = useState(exam.location ?? "");
  const [notes, setNotes] = useState(exam.notes ?? "");
  const [topics, setTopics] = useState<ExamTopic[]>(exam.topics ?? []);
  const [newTopic, setNewTopic] = useState("");

  const save = useMutation({
    mutationFn: () => fetchApi(`/api/exams/${exam.id}`, { method: "PATCH", json: { name, type, examAt: fromLocalInput(examAt), location: location||null, notes: notes||null } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.exams() }); toast.success("Ujian diperbarui"); },
  });
  const del = useMutation({
    mutationFn: () => fetchApi(`/api/exams/${exam.id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.exams() }); toast.success("Ujian dihapus"); onClose(); },
  });
  const addTopic = useMutation({
    mutationFn: () => fetchApi(`/api/exams/${exam.id}/topics`, { method: "POST", json: { title: newTopic } }),
    onSuccess: (r) => { setTopics((p)=>[...p, r.topic]); setNewTopic(""); qc.invalidateQueries({ queryKey: apiKeys.exams() }); },
  });
  const toggleTopic = useMutation({
    mutationFn: (t: ExamTopic) => fetchApi(`/api/exams/${exam.id}/topics`, { method: "PATCH", json: { topicId: t.id, completed: !t.completed } }),
    onSuccess: (r) => { setTopics((p)=>p.map((t)=>t.id===r.topic.id?r.topic:t)); qc.invalidateQueries({ queryKey: apiKeys.exams() }); },
  });

  return (
    <div className="space-y-3 px-4 pb-6">
      <Input value={name} onChange={(e)=>setName(e.target.value)} className="text-lg font-semibold border-0 px-0 focus-visible:ring-0" />
      <div className="flex items-center gap-2">
        <Badge variant="outline">{type}</Badge>
        <Badge variant="secondary">{exam.course?.name}</Badge>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5"><Label className="text-xs">Tipe</Label><Select value={type} onValueChange={setType}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{EXAM_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent></Select></div>
        <div className="space-y-1.5"><Label className="text-xs">Waktu</Label><Input type="datetime-local" value={examAt} onChange={(e)=>setExamAt(e.target.value)} /></div>
      </div>
      <div className="space-y-1.5"><Label className="text-xs">Lokasi</Label><Input value={location} onChange={(e)=>setLocation(e.target.value)} placeholder="Ruang / link" /></div>

      <div className="space-y-1.5">
        <Label className="text-xs font-semibold uppercase text-muted-foreground">Topik Ujian</Label>
        {topics.length === 0 && <p className="text-xs text-muted-foreground">Belum ada topik. Tambahkan materi yang harus dipelajari.</p>}
        {topics.map((t) => (
          <label key={t.id} className="flex items-center gap-2.5 rounded-md p-2 hover:bg-accent/50 cursor-pointer">
            <Checkbox checked={t.completed} onCheckedChange={()=>toggleTopic.mutate(t)} />
            <span className={cn("text-sm flex-1", t.completed && "line-through text-muted-foreground")}>{t.title}</span>
          </label>
        ))}
        <form onSubmit={(e)=>{e.preventDefault(); if(newTopic.trim()){addTopic.mutate();}}} className="flex gap-2">
          <Input value={newTopic} onChange={(e)=>setNewTopic(e.target.value)} placeholder="Tambah topik..." />
          <Button type="submit" size="icon" variant="secondary"><Plus className="size-4" /></Button>
        </form>
      </div>

      <div className="space-y-1.5"><Label className="text-xs">Catatan</Label><Textarea value={notes} onChange={(e)=>setNotes(e.target.value)} rows={3} /></div>

      <SheetFooter className="flex-row gap-2 sm:justify-between">
        <Button variant="destructive" size="sm" onClick={()=>del.mutate()}><Trash2 className="size-4" /> Hapus</Button>
        <Button size="sm" onClick={()=>save.mutate()} disabled={save.isPending}>{save.isPending && <Loader2 className="size-4 animate-spin" />} Simpan</Button>
      </SheetFooter>
    </div>
  );
}

function ExamDialog({ open, onOpenChange, courses }: { open: boolean; onOpenChange:(o:boolean)=>void; courses: Course[] }) {
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [type, setType] = useState("UTS");
  const [courseId, setCourseId] = useState("");
  const [examAt, setExamAt] = useState("");
  const [location, setLocation] = useState("");
  const [topics, setTopics] = useState<string[]>([""]);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !courseId || !examAt) { toast.error("Lengkapi nama, mata kuliah, dan waktu."); return; }
    setLoading(true);
    try {
      await fetchApi("/api/exams", { method: "POST", json: { name: name.trim(), type, courseId, examAt: fromLocalInput(examAt), location: location||null, topics: topics.filter(t=>t.trim()).map(t=>({title:t.trim()})) } });
      qc.invalidateQueries({ queryKey: apiKeys.exams() });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Ujian ditambahkan");
      setName(""); setCourseId(""); setExamAt(""); setLocation(""); setTopics([""]);
      onOpenChange(false);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setLoading(false); }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md overflow-y-auto scroll-area-thin">
        <SheetHeader><SheetTitle>Ujian Baru</SheetTitle></SheetHeader>
        <form onSubmit={submit} className="space-y-3 px-4 pb-6">
          <div className="space-y-1.5"><Label>Nama</Label><Input value={name} onChange={(e)=>setName(e.target.value)} placeholder="UTS Hukum Pidana" autoFocus required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Tipe</Label><Select value={type} onValueChange={setType}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{EXAM_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-1.5"><Label>Mata Kuliah</Label><Select value={courseId} onValueChange={setCourseId}><SelectTrigger><SelectValue placeholder="Pilih..." /></SelectTrigger><SelectContent>{courses.map((c)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
          </div>
          <div className="space-y-1.5"><Label>Waktu</Label><Input type="datetime-local" value={examAt} onChange={(e)=>setExamAt(e.target.value)} required /></div>
          <div className="space-y-1.5"><Label>Lokasi</Label><Input value={location} onChange={(e)=>setLocation(e.target.value)} placeholder="Ruang / link" /></div>
          <div className="space-y-1.5">
            <Label>Topik (opsional)</Label>
            {topics.map((t, i) => (
              <div key={i} className="flex gap-2">
                <Input value={t} onChange={(e)=>setTopics(topics.map((x,j)=>j===i?e.target.value:x))} placeholder={`Topik ${i+1}`} />
                {topics.length > 1 && <Button type="button" variant="ghost" size="icon" onClick={()=>setTopics(topics.filter((_,j)=>j!==i))}><X className="size-4" /></Button>}
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={()=>setTopics([...topics,""])}><Plus className="size-4" /> Topik</Button>
          </div>
          <SheetFooter><Button type="submit" className="w-full" disabled={loading}><Plus className="size-4" /> Tambah</Button></SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
