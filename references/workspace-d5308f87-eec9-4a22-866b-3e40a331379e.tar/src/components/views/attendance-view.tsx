"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { AttendanceStats, Course } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import { ClipboardCheck, Plus, Trash2, Check, X, Clock, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { formatDate } from "@/lib/date";

const STATUS_CFG = {
  PRESENT: { label: "Hadir", color: "bg-success/15 text-success border-success/30", dot: "bg-success" },
  PERMIT: { label: "Izin", color: "bg-high/15 text-high border-high/30", dot: "bg-high" },
  SICK: { label: "Sakit", color: "bg-medium/15 text-medium border-medium/30", dot: "bg-medium" },
  ABSENT: { label: "Alpha", color: "bg-urgent/15 text-urgent border-urgent/30", dot: "bg-urgent" },
} as const;

type Status = keyof typeof STATUS_CFG;

export function AttendanceView() {
  const qc = useQueryClient();
  const [markCourseId, setMarkCourseId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: apiKeys.attendance(),
    queryFn: () => fetchApi<{ stats: AttendanceStats[] }>("/api/attendance").then((r) => r.stats),
  });
  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });

  const overallPercentage = data && data.length > 0
    ? Math.round(data.reduce((s, c) => s + c.percentage, 0) / data.length)
    : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Kehadiran</h1>
          <p className="text-sm text-muted-foreground">Pantau kehadiran per mata kuliah</p>
        </div>
        <Button onClick={() => courses && courses.length > 0 && setMarkCourseId(courses[0].id)} disabled={!courses?.length}>
          <Plus className="size-4" /> Tandai
        </Button>
      </div>

      {/* Overall summary */}
      {data && data.length > 0 && (
        <Card className="bg-gradient-to-br from-primary/5 via-card to-card border-primary/20">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground font-medium uppercase">Rata-rata Kehadiran</p>
                <div className="text-3xl font-bold tabular-nums mt-1">{overallPercentage}%</div>
              </div>
              <div className="size-14 rounded-2xl bg-primary/10 flex items-center justify-center">
                <ClipboardCheck className="size-7 text-primary" />
              </div>
            </div>
            <Progress value={overallPercentage} className="h-2 mt-3" />
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28" />)}</div>
      ) : !data || data.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
          <ClipboardCheck className="size-8 mx-auto mb-2 opacity-40" />
          Belum ada data kehadiran. Tandai kehadiran setelah kelas.
        </Card>
      ) : (
        <div className="space-y-3">
          {data.map((s) => (
            <Card key={s.course.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="size-3 rounded-full shrink-0" style={{ backgroundColor: s.course.color || "var(--primary)" }} />
                    <div className="min-w-0">
                      <p className="font-semibold truncate">{s.course.name}</p>
                      {s.course.code && <p className="text-xs text-muted-foreground">{s.course.code}</p>}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className={cn("text-lg font-bold tabular-nums", s.percentage >= 80 ? "text-success" : s.percentage >= 60 ? "text-high" : "text-urgent")}>{s.percentage}%</div>
                    <div className="text-[10px] text-muted-foreground">{s.total} pertemuan</div>
                  </div>
                </div>
                {s.total > 0 ? (
                  <>
                    <div className="grid grid-cols-4 gap-2 mb-3">
                      {(["PRESENT", "PERMIT", "SICK", "ABSENT"] as Status[]).map((st) => (
                        <div key={st} className="text-center rounded-md bg-muted/40 py-1.5">
                          <div className={cn("text-base font-bold tabular-nums", STATUS_CFG[st].dot.replace("bg-", "text-"))}>{s[st.toLowerCase() as "present" | "permit" | "sick" | "absent"]}</div>
                          <div className="text-[10px] text-muted-foreground">{STATUS_CFG[st].label}</div>
                        </div>
                      ))}
                    </div>
                    <Button variant="ghost" size="sm" className="w-full" onClick={() => setMarkCourseId(s.course.id)}>
                      <Plus className="size-3.5" /> Tandai Pertemuan
                    </Button>
                  </>
                ) : (
                  <Button variant="outline" size="sm" className="w-full" onClick={() => setMarkCourseId(s.course.id)}>
                    <Plus className="size-3.5" /> Mulai Pencatatan
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Sheet open={Boolean(markCourseId)} onOpenChange={(o) => { if (!o) setMarkCourseId(null); }}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto scroll-area-thin">
          <SheetHeader><SheetTitle>Tandai Kehadiran</SheetTitle></SheetHeader>
          {markCourseId ? <MarkAttendanceContent key={markCourseId} initialCourseId={markCourseId} courses={courses ?? []} onClose={() => setMarkCourseId(null)} /> : null}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function MarkAttendanceContent({ initialCourseId, courses, onClose }: { initialCourseId: string; courses: Course[]; onClose: () => void }) {
  const qc = useQueryClient();
  const [selectedCourse, setSelectedCourse] = useState(initialCourseId);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [status, setStatus] = useState<Status>("PRESENT");
  const [notes, setNotes] = useState("");

  const { data: records } = useQuery({
    queryKey: ["attendance", selectedCourse],
    queryFn: () => fetchApi<{ records: { id: string; classDate: string; status: Status; notes: string | null }[] }>(`/api/attendance?courseId=${selectedCourse}`).then(r => r.records),
    enabled: Boolean(selectedCourse),
  });

  const save = useMutation({
    mutationFn: () => fetchApi("/api/attendance", { method: "POST", json: { records: [{ courseId: selectedCourse, classDate: new Date(date + "T12:00+07:00").toISOString(), status, notes: notes || null }] } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.attendance() }); qc.invalidateQueries({ queryKey: ["attendance", selectedCourse] }); toast.success("Kehadiran dicatat"); setNotes(""); },
  });
  const del = useMutation({
    mutationFn: (id: string) => fetchApi(`/api/attendance?id=${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.attendance() }); qc.invalidateQueries({ queryKey: ["attendance", selectedCourse] }); },
  });

  const course = courses.find((c) => c.id === selectedCourse);

  return (
    <div className="space-y-4 px-4 pb-6">
      <div className="space-y-1.5">
        <label className="text-xs font-medium">Mata Kuliah</label>
        <select value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
          {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div className="space-y-1.5">
        <label className="text-xs font-medium">Tanggal</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <div className="space-y-1.5">
        <label className="text-xs font-medium">Status</label>
        <div className="grid grid-cols-2 gap-2">
          {(Object.keys(STATUS_CFG) as Status[]).map((st) => (
            <button key={st} onClick={() => setStatus(st)} className={cn("rounded-lg border p-3 text-sm font-medium transition", status === st ? STATUS_CFG[st].color : "bg-card text-muted-foreground hover:bg-accent")}>
              <div className="flex items-center justify-center gap-1.5">
                <span className={cn("size-2 rounded-full", STATUS_CFG[st].dot)} />
                {STATUS_CFG[st].label}
              </div>
            </button>
          ))}
        </div>
      </div>
      <div className="space-y-1.5">
        <label className="text-xs font-medium">Catatan (opsional)</label>
        <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Mis. terlambat 15 menit" className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
      </div>
      <Button onClick={() => save.mutate()} disabled={save.isPending || !selectedCourse} className="w-full">
        <Check className="size-4" /> Simpan
      </Button>

      {/* History */}
      {records && records.length > 0 && (
        <div className="space-y-2 pt-2">
          <p className="text-xs font-semibold uppercase text-muted-foreground">Riwayat ({course?.name})</p>
          <div className="space-y-1.5 max-h-64 overflow-y-auto scroll-area-thin">
            {records.map((r) => (
              <div key={r.id} className="flex items-center gap-2 rounded-md bg-muted/40 px-3 py-2">
                <span className={cn("size-2 rounded-full", STATUS_CFG[r.status].dot)} />
                <span className="text-sm flex-1">{formatDate(r.classDate)}</span>
                <Badge variant="outline" className={cn("text-[10px]", STATUS_CFG[r.status].color)}>{STATUS_CFG[r.status].label}</Badge>
                <Button variant="ghost" size="icon" className="size-7" onClick={() => del.mutate(r.id)}><Trash2 className="size-3" /></Button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
