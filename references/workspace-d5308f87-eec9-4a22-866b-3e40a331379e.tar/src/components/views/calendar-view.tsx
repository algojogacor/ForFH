"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchApi } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Task, ClassSchedule, Course, Exam } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DAYS_SHORT } from "@/lib/constants";
import { TaskStatusBadge, PriorityDot } from "@/components/task-status-badge";
import { displayStatus, formatTime, addDays, startOfWeek, jakartaDow, jakartaDateKey } from "@/lib/date";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight, CalendarDays, Clock, MapPin, BookOpen, AlertCircle } from "lucide-react";
import { EmptyState } from "@/components/empty-state";

const HOURS = Array.from({ length: 16 }, (_, i) => i + 7); // 07:00 - 22:00
const HOUR_HEIGHT = 48; // px per hour

function timeToMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

export function CalendarView() {
  const [weekStart, setWeekStart] = useState(() => startOfWeek());
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const { setActiveTaskId, setView } = useApp();

  const { data: tasks } = useQuery({
    queryKey: apiKeys.tasks(),
    queryFn: () => fetchApi<{ tasks: Task[] }>("/api/tasks").then((r) => r.tasks),
  });
  const { data: schedules } = useQuery({
    queryKey: apiKeys.schedules(),
    queryFn: () => fetchApi<{ schedules: (ClassSchedule & { course: Course })[] }>("/api/schedules").then((r) => r.schedules),
  });
  const { data: exams } = useQuery({
    queryKey: apiKeys.exams(),
    queryFn: () => fetchApi<{ exams: Exam[] }>("/api/exams").then((r) => r.exams),
  });

  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const today = new Date();

  const agendaDay = selectedDay ?? today;
  const agendaDayKey = jakartaDateKey(agendaDay);
  const agendaDow = jakartaDow(agendaDay);

  const dayTasks = tasks?.filter((t) => {
    const s = displayStatus(t.status as never, t.dueAt);
    if (s === "DONE") return false;
    if (!t.dueAt && !t.internalTargetAt) return false;
    return jakartaDateKey(new Date(t.dueAt ?? t.internalTargetAt!)) === agendaDayKey;
  }) ?? [];
  const dayExams = exams?.filter((e) => jakartaDateKey(new Date(e.examAt)) === agendaDayKey) ?? [];
  const daySchedules = (schedules?.filter((s) => s.dayOfWeek === agendaDow) ?? []).sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Compute positioned class blocks for the time grid
  const classBlocks = daySchedules.map((s) => {
    const startMin = timeToMinutes(s.startTime);
    const endMin = timeToMinutes(s.endTime);
    const top = ((startMin - 7 * 60) / 60) * HOUR_HEIGHT;
    const height = ((endMin - startMin) / 60) * HOUR_HEIGHT;
    return { schedule: s, top, height };
  });

  // Current time indicator
  const nowInJakarta = new Date();
  const jakartaHourStr = new Intl.DateTimeFormat("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta", hour12: false }).format(nowInJakarta);
  const [nowH, nowM] = jakartaHourStr.split(":").map(Number);
  const nowTop = ((nowH * 60 + nowM - 7 * 60) / 60) * HOUR_HEIGHT;
  const showNowLine = nowTop >= 0 && nowTop <= HOURS.length * HOUR_HEIGHT;

  const hasAnyEvents = daySchedules.length > 0 || dayTasks.length > 0 || dayExams.length > 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Kalender</h1>
          <p className="text-sm text-muted-foreground">
            {new Intl.DateTimeFormat("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Jakarta" }).format(today)}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" onClick={() => setWeekStart(addDays(weekStart, -7))}><ChevronLeft className="size-4" /></Button>
          <Button variant="outline" size="sm" onClick={() => { setWeekStart(startOfWeek()); setSelectedDay(null); }}>Hari ini</Button>
          <Button variant="outline" size="icon" onClick={() => setWeekStart(addDays(weekStart, 7))}><ChevronRight className="size-4" /></Button>
        </div>
      </div>

      {/* Week day selector */}
      <div className="grid grid-cols-7 gap-1.5">
        {days.map((d, i) => {
          const dKey = jakartaDateKey(d);
          const isToday = dKey === jakartaDateKey(today);
          const isSelected = dKey === agendaDayKey;
          const dow = jakartaDow(d);
          const daySched = schedules?.filter((s) => s.dayOfWeek === dow) ?? [];
          const dayTaskCount = tasks?.filter((t) => t.dueAt && jakartaDateKey(new Date(t.dueAt)) === dKey && displayStatus(t.status as never, t.dueAt) !== "DONE").length ?? 0;
          const dayExamCount = exams?.filter((e) => jakartaDateKey(new Date(e.examAt)) === dKey).length ?? 0;
          const eventCount = daySched.length + dayTaskCount + dayExamCount;
          return (
            <button
              key={i}
              onClick={() => setSelectedDay(d)}
              className={cn(
                "rounded-lg border p-2 text-center min-h-[72px] transition flex flex-col items-center justify-center gap-1",
                isSelected ? "border-primary bg-primary/10" : "bg-card hover:bg-accent/50",
                isToday && !isSelected && "ring-1 ring-primary/40",
              )}
            >
              <span className="text-[10px] font-medium text-muted-foreground">{DAYS_SHORT[dow]}</span>
              <span className={cn("text-lg font-bold tabular-nums leading-none", isToday ? "text-primary" : "")}>{d.getDate()}</span>
              {eventCount > 0 && (
                <div className="flex items-center gap-1">
                  {daySched.length > 0 && <span className="size-1.5 rounded-full bg-primary" />}
                  {dayTaskCount > 0 && <span className="size-1.5 rounded-full bg-high" />}
                  {dayExamCount > 0 && <span className="size-1.5 rounded-full bg-urgent" />}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Selected day header */}
      <div className="flex items-center gap-2">
        <CalendarDays className="size-5 text-primary" />
        <h2 className="text-lg font-semibold">
          {new Intl.DateTimeFormat("id-ID", { weekday: "long", day: "numeric", month: "long", timeZone: "Asia/Jakarta" }).format(agendaDay)}
        </h2>
        {hasAnyEvents && (
          <Badge variant="secondary" className="text-[10px] ml-auto">
            {daySchedules.length + dayTasks.length + dayExams.length} agenda
          </Badge>
        )}
      </div>

      {/* Time grid for classes */}
      {daySchedules.length > 0 ? (
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="relative" style={{ height: `${HOURS.length * HOUR_HEIGHT}px` }}>
              {/* Hour lines */}
              {HOURS.map((h, i) => (
                <div
                  key={h}
                  className="absolute inset-x-0 flex items-center"
                  style={{ top: `${i * HOUR_HEIGHT}px`, height: `${HOUR_HEIGHT}px` }}
                >
                  <div className="w-14 shrink-0 text-[10px] text-muted-foreground text-right pr-2 tabular-nums">
                    {String(h).padStart(2, "0")}:00
                  </div>
                  <div className="flex-1 border-t border-border/50" />
                </div>
              ))}
              {/* Current time indicator */}
              {showNowLine && (
                <div className="absolute inset-x-0 z-10 flex items-center" style={{ top: `${nowTop}px` }}>
                  <div className="w-14 shrink-0 flex justify-end pr-2">
                    <div className="size-2 rounded-full bg-primary" />
                  </div>
                  <div className="flex-1 h-0.5 bg-primary" />
                </div>
              )}
              {/* Class blocks */}
              <div className="absolute left-14 right-0">
                {classBlocks.map(({ schedule: s, top, height }) => (
                  <button
                    key={s.id}
                    onClick={() => { setActiveTaskId(null); }}
                    className="absolute inset-x-2 rounded-lg p-2 text-left text-white shadow-sm hover:shadow-md transition overflow-hidden"
                    style={{
                      top: `${top + 2}px`,
                      height: `${height - 4}px`,
                      backgroundColor: s.course.color || "var(--primary)",
                    }}
                  >
                    <div className="text-xs font-semibold truncate">{s.course.name}</div>
                    <div className="text-[10px] opacity-90 tabular-nums">{s.startTime}–{s.endTime}</div>
                    {s.room && height > 60 && (
                      <div className="text-[10px] opacity-80 flex items-center gap-1 mt-1">
                        <MapPin className="size-2.5" /> {s.room}
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}

      {/* Exams */}
      {dayExams.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase text-urgent mb-2 flex items-center gap-1.5">
            <AlertCircle className="size-3.5" /> Ujian
          </p>
          <div className="space-y-1.5">
            {dayExams.map((e) => (
              <div key={e.id} className="flex items-center gap-3 rounded-lg border border-urgent/30 bg-urgent/5 px-3 py-2.5">
                <Badge variant="outline" className="text-urgent border-urgent/30 text-[10px]">{e.type}</Badge>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{e.name}</p>
                  <p className="text-xs text-muted-foreground">{e.course?.name}</p>
                </div>
                <span className="text-xs text-muted-foreground tabular-nums">{formatTime(e.examAt)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tasks & Deadlines */}
      {dayTasks.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase text-muted-foreground mb-2 flex items-center gap-1.5">
            <BookOpen className="size-3.5" /> Tugas & Deadline
          </p>
          <div className="space-y-1.5">
            {dayTasks.map((t) => (
              <button
                key={t.id}
                onClick={() => { setActiveTaskId(t.id); setView("tasks"); }}
                className="w-full flex items-center gap-3 rounded-lg border bg-card px-3 py-2.5 hover:shadow-sm transition text-left"
              >
                <PriorityDot priority={t.priority} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{t.title}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {t.course && <span className="truncate">{t.course.name}</span>}
                    {t.dueAt && <span className="flex items-center gap-0.5 tabular-nums"><Clock className="size-2.5" />{formatTime(t.dueAt)}</span>}
                  </div>
                </div>
                <TaskStatusBadge status={t.status as never} dueAt={t.dueAt} />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {!hasAnyEvents && (
        <EmptyState
          icon={CalendarDays}
          title="Tidak ada agenda"
          description="Tidak ada kelas, tugas, atau ujian untuk hari ini. Pilih hari lain atau tambah jadwal di Mata Kuliah."
        />
      )}
    </div>
  );
}
