"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Task, Course, Subtask } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { TaskStatusBadge, PriorityDot } from "@/components/task-status-badge";
import { TaskDialog } from "@/components/task-dialog";
import { displayStatus, relativeTime, formatDateTime, toLocalInput, fromLocalInput } from "@/lib/date";
import { STATUSES, PRIORITIES, TASK_TYPES } from "@/lib/constants";
import { useApp } from "@/lib/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Plus, Filter, Sparkles, CalendarClock, Clock, Trash2, ListChecks, Wand2, Download, CheckCircle2, CheckSquare } from "lucide-react";
import { EmptyState } from "@/components/empty-state";
import { SortableSubtask } from "@/components/sortable-subtask";
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { arrayMove } from "@dnd-kit/sortable";

type Filter = "all" | "today" | "overdue" | "week" | "done";

export function TasksView() {
  const { activeTaskId, setActiveTaskId } = useApp();
  const [filter, setFilter] = useState<Filter>("all");
  const [newOpen, setNewOpen] = useState(false);
  const [bulkMode, setBulkMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const qc = useQueryClient();

  const { data: tasks, isLoading } = useQuery({
    queryKey: apiKeys.tasks(),
    queryFn: () => fetchApi<{ tasks: Task[] }>("/api/tasks").then((r) => r.tasks),
  });

  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });
  const courseMap = new Map((courses ?? []).map((c) => [c.id, c]));

  const filtered = (() => {
    if (!tasks) return [];
    const now = new Date();
    const startToday = new Date(now); startToday.setHours(0,0,0,0);
    const endToday = new Date(now); endToday.setHours(23,59,59,999);
    const weekEnd = new Date(now); weekEnd.setDate(weekEnd.getDate()+7);
    return tasks.filter((t) => {
      const s = displayStatus(t.status as never, t.dueAt);
      if (filter === "today") return t.dueAt && new Date(t.dueAt) <= endToday && new Date(t.dueAt) >= startToday && s !== "DONE";
      if (filter === "overdue") return s === "OVERDUE";
      if (filter === "week") return t.dueAt && new Date(t.dueAt) <= weekEnd && s !== "DONE";
      if (filter === "done") return s === "DONE";
      return true;
    });
  })();

  const activeTask = tasks?.find((t) => t.id === activeTaskId);

  const activeCount = tasks?.filter(t => t.status !== "DONE").length ?? 0;
  const overdueCount = tasks?.filter(t => displayStatus(t.status as never, t.dueAt) === "OVERDUE").length ?? 0;
  const doneCount = tasks?.filter(t => t.status === "DONE").length ?? 0;

  const filterCounts: Record<Filter, number> = {
    all: activeCount,
    today: tasks?.filter(t => {
      const s = displayStatus(t.status as never, t.dueAt);
      if (s === "DONE") return false;
      if (!t.dueAt) return false;
      const d = new Date(t.dueAt);
      const now = new Date();
      return d.toDateString() === now.toDateString();
    }).length ?? 0,
    overdue: overdueCount,
    week: tasks?.filter(t => {
      const s = displayStatus(t.status as never, t.dueAt);
      if (s === "DONE") return false;
      if (!t.dueAt) return false;
      const d = new Date(t.dueAt);
      const weekEnd = new Date(); weekEnd.setDate(weekEnd.getDate() + 7);
      return d <= weekEnd;
    }).length ?? 0,
    done: doneCount,
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Tugas</h1>
          <p className="text-sm text-muted-foreground">{activeCount} tugas aktif{overdueCount > 0 && <span className="text-urgent font-medium"> · {overdueCount} terlambat</span>}</p>
        </div>
        <div className="flex items-center gap-2">
          {(tasks?.length ?? 0) > 0 && (
            <Button variant="outline" size="sm" onClick={() => window.open("/api/export/tasks", "_blank")}>
              <Download className="size-4" /> Export
            </Button>
          )}
          {(activeCount > 0 || doneCount > 0) && (
            <Button
              variant={bulkMode ? "secondary" : "outline"}
              size="sm"
              onClick={() => { setBulkMode(!bulkMode); setSelected(new Set()); }}
            >
              <CheckSquare className="size-4" /> {bulkMode ? "Selesai" : "Pilih"}
            </Button>
          )}
          <Button onClick={() => setNewOpen(true)}><Plus className="size-4" /> Tugas Baru</Button>
        </div>
      </div>

      <div className="flex gap-1.5 overflow-x-auto pb-1 scroll-area-thin">
        {(["all","today","overdue","week","done"] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition border",
              filter === f ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground border-border hover:bg-accent",
            )}
          >
            {f === "all" ? "Semua" : f === "today" ? "Hari Ini" : f === "overdue" ? "Terlambat" : f === "week" ? "Minggu Ini" : "Selesai"}
            {filterCounts[f] > 0 && (
              <span className={cn(
                "rounded-full px-1.5 text-[10px] font-semibold tabular-nums min-w-5 text-center",
                filter === f ? "bg-primary-foreground/25 text-primary-foreground" : "bg-muted-foreground/15 text-foreground",
              )}>{filterCounts[f]}</span>
            )}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(5)].map((_,i)=><Skeleton key={i} className="h-16 w-full" />)}</div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={ListChecks}
          title={filter === "done" ? "Belum ada tugas selesai" : filter === "overdue" ? "Tidak ada tugas terlambat" : "Belum ada tugas"}
          description={filter === "all" ? "Buat tugas pertamamu atau gunakan Quick Capture untuk menambah dengan bahasa natural." : "Coba filter lain atau buat tugas baru."}
          action={filter === "all" || filter === "today" ? { label: "Buat Tugas", onClick: () => setNewOpen(true) } : undefined}
        />
      ) : (
        <div className="space-y-2">
          {bulkMode && selected.size > 0 && (
            <div className="sticky top-16 z-10 flex items-center gap-2 rounded-xl border bg-card p-3 shadow-md">
              <span className="text-sm font-medium">{selected.size} dipilih</span>
              <div className="ml-auto flex items-center gap-2">
                <Button size="sm" variant="secondary" onClick={async () => {
                  await Promise.all([...selected].map(id => fetchApi(`/api/tasks/${id}`, { method: "PATCH", json: { status: "DONE", progress: 100 } })));
                  qc.invalidateQueries({ queryKey: apiKeys.tasks() });
                  qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
                  setSelected(new Set());
                  setBulkMode(false);
                  toast.success(`${selected.size} tugas diselesaikan`);
                }}>
                  <CheckCircle2 className="size-3.5" /> Selesaikan
                </Button>
                <Button size="sm" variant="destructive" onClick={async () => {
                  await Promise.all([...selected].map(id => fetchApi(`/api/tasks/${id}`, { method: "DELETE" })));
                  qc.invalidateQueries({ queryKey: apiKeys.tasks() });
                  qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
                  setSelected(new Set());
                  setBulkMode(false);
                  toast.success(`${selected.size} tugas dihapus`);
                }}>
                  <Trash2 className="size-3.5" /> Hapus
                </Button>
              </div>
            </div>
          )}
          {filtered.map((t) => {
            const s = displayStatus(t.status as never, t.dueAt);
            return (
              <div
                key={t.id}
                onClick={() => bulkMode ? toggleSelect(t.id) : setActiveTaskId(t.id)}
                className={cn(
                  "w-full text-left rounded-xl border bg-card p-4 transition group cursor-pointer",
                  bulkMode ? "hover:border-primary/40" : "hover:shadow-md hover:border-primary/30",
                  s === "OVERDUE" && "border-urgent/40 bg-urgent/5",
                  bulkMode && selected.has(t.id) && "border-primary ring-1 ring-primary/30 bg-primary/5",
                )}
              >
                <div className="flex items-center gap-3">
                  {bulkMode && (
                    <Checkbox
                      checked={selected.has(t.id)}
                      onCheckedChange={() => toggleSelect(t.id)}
                      onClick={(e) => e.stopPropagation()}
                      className="shrink-0"
                    />
                  )}
                  <PriorityDot priority={t.priority} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={cn("text-sm font-medium truncate flex-1", s === "DONE" && "line-through text-muted-foreground")}>{t.title}</p>
                      <TaskStatusBadge status={t.status as never} dueAt={t.dueAt} />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                      {t.course && <Badge variant="outline" className="text-[10px] px-1.5 py-0" style={{ borderColor: t.course.color || undefined }}>{t.course.code || t.course.name}</Badge>}
                      {t.dueAt && <span className="flex items-center gap-1"><CalendarClock className="size-3" /> {relativeTime(t.dueAt)}</span>}
                      {t.estimatedMinutes && <span className="flex items-center gap-1"><Clock className="size-3" /> {t.estimatedMinutes}m</span>}
                    </div>
                    {(t.progress > 0 && s !== "DONE") && (
                      <Progress value={t.progress} className="h-1 mt-2" />
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Sheet open={Boolean(activeTaskId)} onOpenChange={(o) => { if (!o) setActiveTaskId(null); }}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto scroll-area-thin">
          <SheetHeader><SheetTitle className="sr-only">Detail Tugas</SheetTitle></SheetHeader>
          {activeTask ? (
            <TaskDetailContent key={activeTask.id} task={activeTask} courses={courses ?? []} onClose={() => setActiveTaskId(null)} />
          ) : null}
        </SheetContent>
      </Sheet>
      <TaskDialog open={newOpen} onOpenChange={setNewOpen} courses={courses ?? []} />
    </div>
  );
}

function TaskDetailContent({
  task, courses, onClose,
}: {
  task: Task;
  courses: Course[];
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const taskId = task.id;
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description ?? "");
  const [type, setType] = useState(task.type);
  const [priority, setPriority] = useState(task.priority);
  const [status, setStatus] = useState(task.status);
  const [courseId, setCourseId] = useState<string | null>(task.courseId);
  const [dueAt, setDueAt] = useState(toLocalInput(task.dueAt));
  const [est, setEst] = useState(task.estimatedMinutes?.toString() ?? "");
  const [progress, setProgress] = useState(task.progress);
  const [breakdown, setBreakdown] = useState<{ title: string; estimatedMinutes: number | null }[] | null>(null);
  const [breakingDown, setBreakingDown] = useState(false);
  const [plan, setPlan] = useState<{ date: string; title: string; estimatedMinutes: number; rationale: string }[] | null>(null);
  const [planning, setPlanning] = useState(false);
  const [localSubtasks, setLocalSubtasks] = useState<Subtask[] | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const reorderSubs = useMutation({
    mutationFn: (items: { id: string; orderIndex: number }[]) => fetchApi("/api/subtasks/reorder", { method: "PATCH", json: { subtasks: items } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] }); },
  });

  const update = useMutation({
    mutationFn: () => fetchApi(`/api/tasks/${taskId}`, {
      method: "PATCH",
      json: {
        title, description, type, priority, status,
        courseId: courseId ?? null,
        dueAt: dueAt ? fromLocalInput(dueAt) : null,
        estimatedMinutes: est ? Number(est) : null,
        progress,
      },
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.tasks() }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); toast.success("Tugas diperbarui"); },
    onError: (e) => toast.error((e as ApiError).message),
  });

  const del = useMutation({
    mutationFn: () => fetchApi(`/api/tasks/${taskId}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.tasks() }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); toast.success("Tugas dihapus"); onClose(); },
  });

  const complete = useMutation({
    mutationFn: () => fetchApi(`/api/tasks/${taskId}`, { method: "PATCH", json: { status: "DONE", progress: 100 } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.tasks() }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); toast.success("Tugas selesai! 🎉"); },
  });

  const { data: subtasks } = useQuery({
    queryKey: ["task", taskId, "subtasks"],
    queryFn: () => taskId ? fetchApi<{ subtasks: import("@/lib/types").Subtask[] }>(`/api/tasks/${taskId}/subtasks`).then(r=>r.subtasks) : [],
    enabled: Boolean(taskId),
  });

  const toggleSub = useMutation({
    mutationFn: (vars: { id: string; completed: boolean }) => fetchApi(`/api/subtasks/${vars.id}`, { method: "PATCH", json: { completed: vars.completed } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] }); qc.invalidateQueries({ queryKey: apiKeys.tasks() }); qc.invalidateQueries({ queryKey: apiKeys.dashboard() }); },
  });

  const addSub = useMutation({
    mutationFn: (title: string) => fetchApi(`/api/tasks/${taskId}/subtasks`, { method: "POST", json: { title } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] }); },
  });

  const delSub = useMutation({
    mutationFn: (id: string) => fetchApi(`/api/subtasks/${id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] }); qc.invalidateQueries({ queryKey: apiKeys.tasks() }); toast.success("Subtask dihapus"); },
  });

  const displaySubtasks = localSubtasks ?? subtasks ?? [];

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = displaySubtasks.findIndex((s) => s.id === active.id);
    const newIndex = displaySubtasks.findIndex((s) => s.id === over.id);
    if (oldIndex < 0 || newIndex < 0) return;
    const reordered = arrayMove(displaySubtasks, oldIndex, newIndex);
    setLocalSubtasks(reordered);
    reorderSubs.mutate(reordered.map((s, i) => ({ id: s.id, orderIndex: i })));
  };

  const doBreakdown = async () => {
    setBreakingDown(true);
    try {
      const r = await fetchApi<{ subtasks: { title: string; estimatedMinutes: number | null }[] }>("/api/ai/breakdown", { method: "POST", json: { taskId } });
      setBreakdown(r.subtasks);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setBreakingDown(false); }
  };

  const applyBreakdown = () => {
    if (!breakdown || !taskId) return;
    Promise.all(breakdown.map((s) => fetchApi(`/api/tasks/${taskId}/subtasks`, { method: "POST", json: { title: s.title, estimatedMinutes: s.estimatedMinutes } })))
      .then(() => { qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] }); setBreakdown(null); toast.success("Subtask ditambahkan"); });
  };

  const doPlan = async () => {
    setPlanning(true);
    try {
      const r = await fetchApi<{ plan: { date: string; title: string; estimatedMinutes: number; rationale: string }[] }>("/api/ai/smart-deadline", { method: "POST", json: { taskId } });
      setPlan(r.plan);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setPlanning(false); }
  };

  const applyPlan = () => {
    if (!plan || !taskId) return;
    Promise.all(plan.map((s) => fetchApi(`/api/tasks/${taskId}/subtasks`, { method: "POST", json: { title: `${s.title} (${s.date})`, estimatedMinutes: s.estimatedMinutes } })))
      .then(() => {
        qc.invalidateQueries({ queryKey: ["task", taskId, "subtasks"] });
        setPlan(null);
        toast.success(`${plan.length} sesi belajar ditambahkan ke subtask`);
      });
  };

  return (
    <div className="space-y-4 px-4 pb-6 pt-2">
            <Input value={title} onChange={(e)=>setTitle(e.target.value)} className="text-lg font-semibold border-0 px-0 focus-visible:ring-0" />
            <div className="flex items-center gap-2 flex-wrap">
              <TaskStatusBadge status={task.status as never} dueAt={task.dueAt} />
              {task.course && <Badge variant="outline" style={{ borderColor: task.course.color || undefined }}>{task.course.name}</Badge>}
            </div>

            {task.dueAt && (
              <div className={cn("rounded-lg p-3 text-sm", displayStatus(task.status as never, task.dueAt)==="OVERDUE" ? "bg-urgent/10 text-urgent" : "bg-muted")}>
                <div className="flex items-center gap-2"><CalendarClock className="size-4" /> Deadline: {formatDateTime(task.dueAt, { weekday: true })}</div>
                <p className="text-xs mt-1">{relativeTime(task.dueAt)}</p>
              </div>
            )}

            {/* Subtasks */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-semibold uppercase text-muted-foreground">Subtask</Label>
                <Button variant="ghost" size="sm" onClick={doBreakdown} disabled={breakingDown}>
                  <Sparkles className="size-3.5" /> {breakingDown ? "Memecah..." : "AI Pecah"}
                </Button>
              </div>
              {displaySubtasks.length > 0 && (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext items={displaySubtasks.map((s) => s.id)} strategy={verticalListSortingStrategy}>
                    <div className="space-y-1.5">
                      {displaySubtasks.map((s) => (
                        <SortableSubtask
                          key={s.id}
                          subtask={s}
                          onToggle={(id, completed) => toggleSub.mutate({ id, completed })}
                          onDelete={(id) => delSub.mutate(id)}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              )}
              <form onSubmit={(e)=>{e.preventDefault(); const f=e.target as HTMLFormElement; const i=f.elements.namedItem("sub") as HTMLInputElement; if(i.value.trim()){addSub.mutate(i.value.trim()); i.value="";}}} className="flex gap-2">
                <Input name="sub" placeholder="Tambah subtask..." />
                <Button type="submit" size="icon" variant="secondary"><Plus className="size-4" /></Button>
              </form>
              {breakdown && (
                <Card className="p-3 mt-2 bg-primary/5 border-primary/30">
                  <p className="text-xs font-semibold mb-2 flex items-center gap-1.5"><Wand2 className="size-3.5" /> Saran AI ({breakdown.length} subtask)</p>
                  <ul className="space-y-1 text-sm mb-2">
                    {breakdown.map((s,i)=><li key={i} className="flex justify-between"><span>{s.title}</span><span className="text-muted-foreground">{s.estimatedMinutes ?? "?"}m</span></li>)}
                  </ul>
                  <Button size="sm" onClick={applyBreakdown} className="w-full">Terapkan</Button>
                </Card>
              )}
            </div>

            {/* Smart Deadline */}
            {task.dueAt && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label className="text-xs font-semibold uppercase text-muted-foreground">Smart Deadline</Label>
                  <Button variant="ghost" size="sm" onClick={doPlan} disabled={planning}>
                    <CalendarClock className="size-3.5" /> {planning ? "Merencanakan..." : "Rencana AI"}
                  </Button>
                </div>
                {plan && (
                  <Card className="p-3 mt-2 bg-primary/5 border-primary/30">
                    <p className="text-xs font-semibold mb-2 flex items-center gap-1.5"><Wand2 className="size-3.5" /> Rencana Pengerjaan ({plan.length} sesi)</p>
                    <div className="space-y-2 mb-2">
                      {plan.map((s, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm">
                          <Badge variant="outline" className="text-[10px] shrink-0 mt-0.5">{s.date.slice(5)}</Badge>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium">{s.title}</p>
                            {s.rationale && <p className="text-[11px] text-muted-foreground">{s.rationale}</p>}
                          </div>
                          <span className="text-xs text-muted-foreground shrink-0">{s.estimatedMinutes}m</span>
                        </div>
                      ))}
                    </div>
                    <Button size="sm" onClick={applyPlan} className="w-full"><Plus className="size-3.5" /> Terapkan Rencana</Button>
                  </Card>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">Mata Kuliah</Label>
                <Select value={courseId ?? "none"} onValueChange={(v)=>setCourseId(v==="none"?null:v)}>
                  <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">— Tanpa MK —</SelectItem>{courses.map((c)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Jenis</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TASK_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Prioritas</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRIORITIES.map((p)=><SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Status</Label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUSES.filter(s=>s.value!=="OVERDUE").map((s)=><SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label className="text-xs">Deadline</Label>
                <Input type="datetime-local" value={dueAt} onChange={(e)=>setDueAt(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Estimasi (menit)</Label>
                <Input type="number" value={est} onChange={(e)=>setEst(e.target.value)} min={0} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Progress: {progress}%</Label>
                <input type="range" min={0} max={100} value={progress} onChange={(e)=>setProgress(Number(e.target.value))} className="w-full accent-[var(--primary)]" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">Deskripsi</Label>
              <Textarea value={description} onChange={(e)=>setDescription(e.target.value)} rows={4} />
            </div>

            <SheetFooter className="flex-row gap-2 sm:justify-between">
              <Button variant="destructive" size="sm" onClick={()=>del.mutate()}><Trash2 className="size-4" /> Hapus</Button>
              <div className="flex gap-2">
                {task.status !== "DONE" && <Button variant="secondary" size="sm" onClick={()=>complete.mutate()}><ListChecks className="size-4" /> Selesai</Button>}
                <Button size="sm" onClick={()=>update.mutate()} disabled={update.isPending}>Simpan</Button>
              </div>
            </SheetFooter>
    </div>
  );
}
