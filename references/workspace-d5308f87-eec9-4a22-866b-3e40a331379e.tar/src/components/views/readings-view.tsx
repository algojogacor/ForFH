"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Reading, Course } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { READING_TYPES } from "@/lib/constants";
import { relativeTime, formatDate, toLocalInput, fromLocalInput } from "@/lib/date";
import { toast } from "sonner";
import { Plus, BookMarked, Trash2, BookOpen, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { EmptyState } from "@/components/empty-state";

const STATUS_LABEL: Record<string, string> = { NOT_STARTED: "Belum", READING: "Sedang Baca", DONE: "Selesai" };

export function ReadingsView() {
  const qc = useQueryClient();
  const [newOpen, setNewOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  const { data: readings, isLoading } = useQuery({
    queryKey: apiKeys.readings(),
    queryFn: () => fetchApi<{ readings: Reading[] }>("/api/readings").then((r) => r.readings),
  });
  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });
  const courseMap = new Map((courses ?? []).map((c) => [c.id, c]));
  const editReading = readings?.find((r) => r.id === editId);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Bacaan</h1>
          <p className="text-sm text-muted-foreground">{readings?.length ?? 0} bahan bacaan</p>
        </div>
        <Button onClick={()=>setNewOpen(true)}><Plus className="size-4" /> Tambah</Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_,i)=><Skeleton key={i} className="h-20" />)}</div>
      ) : readings?.length === 0 ? (
        <EmptyState
          icon={BookMarked}
          title="Belum ada bacaan"
          description="Simpan buku, jurnal, modul, atau materi kuliah di sini agar mudah ditemukan dan lacak progres bacanya."
          action={{ label: "Tambah Bacaan Pertama", onClick: () => setNewOpen(true) }}
        />
      ) : (
        <div className="space-y-2">
          {readings?.map((r) => {
            const progress = r.startPage && r.endPage && r.currentPage
              ? Math.round(((r.currentPage - r.startPage) / (r.endPage - r.startPage)) * 100)
              : (r.status === "DONE" ? 100 : 0);
            return (
              <button key={r.id} onClick={()=>setEditId(r.id)} className="w-full text-left">
                <Card className="p-4 hover:shadow-sm transition">
                  <div className="flex items-start gap-3">
                    <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <BookOpen className="size-4.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium truncate flex-1">{r.title}</p>
                        <Badge variant="secondary" className="text-[10px]">{READING_TYPES.find(t=>t.value===r.type)?.label ?? r.type}</Badge>
                      </div>
                      {r.author && <p className="text-xs text-muted-foreground">{r.author}</p>}
                      <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                        {r.course && <span>{courseMap.get(r.courseId ?? "")?.name}</span>}
                        {r.currentPage && r.endPage && <span>Hal. {r.currentPage}/{r.endPage}</span>}
                        {r.deadline && <span className={cn(relativeTime(r.deadline).includes("lagi") ? "text-high" : "")}>📅 {formatDate(r.deadline)}</span>}
                      </div>
                      {progress > 0 && progress < 100 && <Progress value={progress} className="h-1 mt-2" />}
                    </div>
                    <Badge variant="outline" className={cn("text-[10px]", r.status==="DONE" && "bg-success/10 text-success")}>{STATUS_LABEL[r.status] ?? r.status}</Badge>
                  </div>
                </Card>
              </button>
            );
          })}
        </div>
      )}

      <Sheet open={Boolean(editReading)} onOpenChange={(o)=>{ if(!o) setEditId(null); }}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto scroll-area-thin">
          <SheetHeader><SheetTitle>Edit Bacaan</SheetTitle></SheetHeader>
          {editReading ? <ReadingSheetContent key={editReading.id} reading={editReading} onClose={()=>setEditId(null)} /> : null}
        </SheetContent>
      </Sheet>
      <ReadingDialog open={newOpen} onOpenChange={setNewOpen} courses={courses ?? []} />
    </div>
  );
}

function ReadingSheetContent({ reading, onClose }: { reading: Reading; onClose: () => void }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState(reading.title);
  const [author, setAuthor] = useState(reading.author ?? "");
  const [type, setType] = useState(reading.type);
  const [start, setStart] = useState(reading.startPage?.toString() ?? "");
  const [end, setEnd] = useState(reading.endPage?.toString() ?? "");
  const [current, setCurrent] = useState(reading.currentPage?.toString() ?? "");
  const [status, setStatus] = useState(reading.status);
  const [deadline, setDeadline] = useState(toLocalInput(reading.deadline));

  const save = useMutation({
    mutationFn: () => fetchApi(`/api/readings/${reading.id}`, { method: "PATCH", json: {
      title, author: author||null, type,
      startPage: start?Number(start):null, endPage: end?Number(end):null, currentPage: current?Number(current):null,
      status, deadline: deadline?fromLocalInput(`${deadline}T23:59`):null,
    } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.readings() }); toast.success("Bacaan diperbarui"); },
  });
  const del = useMutation({
    mutationFn: () => fetchApi(`/api/readings/${reading.id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.readings() }); toast.success("Dihapus"); onClose(); },
  });

  return (
    <div className="space-y-3 px-4 pb-6">
            <div className="space-y-1.5"><Label>Judul</Label><Input value={title} onChange={(e)=>setTitle(e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Penulis</Label><Input value={author} onChange={(e)=>setAuthor(e.target.value)} /></div>
              <div className="space-y-1.5"><Label>Tipe</Label><Select value={type} onValueChange={setType}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{READING_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent></Select></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1.5"><Label>Hal. Awal</Label><Input type="number" value={start} onChange={(e)=>setStart(e.target.value)} min={0} /></div>
              <div className="space-y-1.5"><Label>Hal. Akhir</Label><Input type="number" value={end} onChange={(e)=>setEnd(e.target.value)} min={0} /></div>
              <div className="space-y-1.5"><Label>Hal. Saat ini</Label><Input type="number" value={current} onChange={(e)=>setCurrent(e.target.value)} min={0} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Status</Label><Select value={status} onValueChange={setStatus}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="NOT_STARTED">Belum</SelectItem><SelectItem value="READING">Sedang Baca</SelectItem><SelectItem value="DONE">Selesai</SelectItem></SelectContent></Select></div>
              <div className="space-y-1.5"><Label>Deadline</Label><Input type="date" value={deadline} onChange={(e)=>setDeadline(e.target.value)} /></div>
            </div>
            <SheetFooter className="flex-row gap-2 sm:justify-between">
              <Button variant="destructive" size="sm" onClick={()=>del.mutate()}><Trash2 className="size-4" /> Hapus</Button>
              <Button size="sm" onClick={()=>save.mutate()} disabled={save.isPending}>{save.isPending && <Loader2 className="size-4 animate-spin" />} Simpan</Button>
            </SheetFooter>
    </div>
  );
}

function ReadingDialog({ open, onOpenChange, courses }: { open: boolean; onOpenChange:(o:boolean)=>void; courses: Course[] }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [type, setType] = useState("book");
  const [end, setEnd] = useState("");
  const [deadline, setDeadline] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setLoading(true);
    try {
      await fetchApi("/api/readings", { method: "POST", json: { title: title.trim(), author: author||null, type, endPage: end?Number(end):null, deadline: deadline?fromLocalInput(`${deadline}T23:59`):null } });
      qc.invalidateQueries({ queryKey: apiKeys.readings() });
      toast.success("Bacaan ditambahkan");
      setTitle(""); setAuthor(""); setEnd(""); setDeadline("");
      onOpenChange(false);
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setLoading(false); }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader><SheetTitle>Bacaan Baru</SheetTitle></SheetHeader>
        <form onSubmit={submit} className="space-y-3 px-4 pb-6">
          <div className="space-y-1.5"><Label>Judul</Label><Input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Pengantar Ilmu Hukum" autoFocus required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Penulis</Label><Input value={author} onChange={(e)=>setAuthor(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Tipe</Label><Select value={type} onValueChange={setType}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{READING_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent></Select></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Halaman Akhir</Label><Input type="number" value={end} onChange={(e)=>setEnd(e.target.value)} min={0} /></div>
            <div className="space-y-1.5"><Label>Deadline</Label><Input type="date" value={deadline} onChange={(e)=>setDeadline(e.target.value)} /></div>
          </div>
          <SheetFooter><Button type="submit" className="w-full" disabled={loading}><Plus className="size-4" /> Tambah</Button></SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
