"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useDashboard } from "@/lib/hooks";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Clock, AlertTriangle, CalendarClock, BookOpen, Sparkles, GraduationCap,
  Video, MapPin, CheckCircle2, Circle, Plus, Loader2, ArrowRight, TrendingUp,
  Target, Zap,
} from "lucide-react";
import {
  formatDuration, formatTime, relativeTime, displayStatus,
} from "@/lib/date";
import { PRIORITIES } from "@/lib/constants";
import { useApp } from "@/lib/store";
import { TaskStatusBadge } from "@/components/task-status-badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function DashboardView() {
  const { data, isLoading } = useDashboard();
  const { setView, setActiveTaskId, setActiveCourseId, setQuickCaptureOpen } = useApp();
  const [insightLoading, setInsightLoading] = useState(false);
  const [insight, setInsight] = useState<string | null>(null);

  const weekProgress = data?.weekStats.total
    ? Math.round((data.weekStats.completed / data.weekStats.total) * 100)
    : 0;

  async function generateInsight() {
    setInsightLoading(true);
    try {
      const r = await fetchApi<{ insight: string | null; available: boolean }>("/api/ai/insight", { method: "POST" });
      if (r.insight) setInsight(r.insight);
      else toast.info("AI tidak dapat membuat insight saat ini.");
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setInsightLoading(false); }
  }

  if (isLoading || !data) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-9 w-56" />
        <Skeleton className="h-44 w-full" />
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      </div>
    );
  }

  const now = new Date(data.now);
  const greeting = (() => {
    const h = now.getHours();
    if (h < 11) return "Selamat pagi";
    if (h < 15) return "Selamat siang";
    if (h < 19) return "Selamat sore";
    return "Selamat malam";
  })();

  const totalActiveTasks = data.todaysTasks.length + data.overdue.length + data.nearestDeadlines.length;

  return (
    <div className="space-y-5">
      {/* Header with quick stats */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{greeting} 👋</h1>
          <p className="text-sm text-muted-foreground">
            {new Intl.DateTimeFormat("id-ID", { weekday: "long", day: "numeric", month: "long", timeZone: "Asia/Jakarta" }).format(now)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => setQuickCaptureOpen(true)} className="lg:hidden">
            <Plus className="size-4" /> Tambah
          </Button>
        </div>
      </div>

      {/* Quick stat chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatChip icon={Clock} label="Kelas Hari Ini" value={String(data.todaysClasses.length)} tone="primary" />
        <StatChip icon={Target} label="Tugas Aktif" value={String(totalActiveTasks)} tone={data.overdue.length > 0 ? "urgent" : "default"} />
        <StatChip icon={AlertTriangle} label="Terlambat" value={String(data.overdue.length)} tone={data.overdue.length > 0 ? "urgent" : "muted"} />
        <StatChip icon={BookOpen} label="Ujian" value={String(data.upcomingExams.length)} tone="default" />
      </div>

      {/* Academic summary banner */}
      {data.academicSummary && (data.academicSummary.courseCount > 0 || data.academicSummary.ipk !== null) && (
        <Card className="bg-gradient-to-r from-primary/5 via-card to-card border-primary/20">
          <CardContent className="p-4 flex items-center gap-4 flex-wrap">
            <div className="size-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <GraduationCap className="size-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground font-medium uppercase">Semester Aktif</p>
              <p className="text-sm font-semibold truncate">{data.academicSummary.termName ?? "Tanpa semester"}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-lg font-bold tabular-nums leading-none">{data.academicSummary.courseCount}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">MK</div>
              </div>
              <div className="h-8 w-px bg-border" />
              <div className="text-center">
                <div className="text-lg font-bold tabular-nums leading-none">{data.academicSummary.totalSks}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">SKS</div>
              </div>
              {data.academicSummary.ipk !== null && (
                <>
                  <div className="h-8 w-px bg-border" />
                  <div className="text-center">
                    <div className="text-lg font-bold tabular-nums leading-none text-primary">{data.academicSummary.ipk.toFixed(2)}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">IPK</div>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next class hero */}
      {data.nextClass ? (
        <Card className="overflow-hidden border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card relative">
          <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
          <CardContent className="p-5 sm:p-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 text-xs font-semibold text-primary mb-1.5">
                  <Clock className="size-3.5" />
                  {data.nextClass.minutesUntil > 0 ? "KELAS BERIKUTNYA" : "SEDANG BERLANGSUNG"}
                </div>
                <h2 className="text-xl sm:text-2xl font-bold leading-tight">{data.nextClass.course.name}</h2>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 mt-2.5 text-sm">
                  <span className="font-semibold text-foreground tabular-nums">{formatTime(data.nextClass.startsAt)} – {formatTime(data.nextClass.endsAt)}</span>
                  {data.nextClass.room && (
                    <span className="flex items-center gap-1 text-muted-foreground"><MapPin className="size-3.5" /> {data.nextClass.room}</span>
                  )}
                  {data.nextClass.onlineUrl && (
                    <a href={data.nextClass.onlineUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-primary hover:underline font-medium">
                      <Video className="size-3.5" /> Gabung Online
                    </a>
                  )}
                </div>
                {data.nextClass.minutesUntil > 0 && (
                  <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-sm">
                    <span className="font-bold text-primary tabular-nums">{formatDuration(data.nextClass.minutesUntil)}</span>
                    <span className="text-muted-foreground">lagi</span>
                  </div>
                )}
              </div>
              <div
                className="size-14 rounded-2xl shrink-0 flex items-center justify-center text-white font-bold text-lg shadow-md"
                style={{ backgroundColor: data.nextClass.course.color || "var(--primary)" }}
              >
                {(data.nextClass.course.code || data.nextClass.course.name).slice(0, 2).toUpperCase()}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-dashed">
          <CardContent className="p-6 text-center">
            <GraduationCap className="size-10 mx-auto mb-2 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">Tidak ada kelas terjadwal.</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={() => setView("courses")}>
              Tambah Mata Kuliah
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Today's classes (full width if present) */}
      {data.todaysClasses.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <GraduationCap className="size-4" /> Kelas Hari Ini
              <Badge variant="secondary" className="text-[10px] ml-auto">{data.todaysClasses.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.todaysClasses.map((c) => {
              const isPast = c.minutesUntil < 0 && Math.abs(c.minutesUntil) > 60;
              const isNext = data.nextClass?.schedule.id === c.schedule.id;
              return (
                <button
                  key={c.schedule.id}
                  onClick={() => { setActiveCourseId(c.course.id); setView("courses"); }}
                  className={cn(
                    "w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition hover:bg-accent/50",
                    isPast && "opacity-50",
                    isNext && "bg-primary/5 ring-1 ring-primary/20",
                  )}
                >
                  <div className="text-right text-sm w-14 shrink-0">
                    <div className="font-semibold tabular-nums">{formatTime(c.startsAt)}</div>
                    <div className="text-[11px] text-muted-foreground tabular-nums">{formatTime(c.endsAt)}</div>
                  </div>
                  <div className="h-8 w-1 rounded-full shrink-0" style={{ backgroundColor: c.course.color || "var(--primary)" }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{c.course.name}</p>
                    {c.room && <p className="text-xs text-muted-foreground truncate">{c.room}</p>}
                  </div>
                  {isNext && <Badge className="text-[10px] shrink-0">Berikutnya</Badge>}
                  {c.minutesUntil > 0 && c.minutesUntil <= 60 && !isNext && (
                    <Badge variant="secondary" className="text-[10px] shrink-0">{formatDuration(c.minutesUntil)}</Badge>
                  )}
                </button>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Overdue */}
      {data.overdue.length > 0 && (
        <Card className="border-urgent/30 bg-urgent/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2 text-urgent">
              <AlertTriangle className="size-4" /> Terlambat
              <Badge variant="secondary" className="text-[10px] ml-auto bg-urgent/15 text-urgent">{data.overdue.length}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.overdue.slice(0, 5).map((t) => (
              <TaskRow key={t.id} task={t} onClick={() => { setActiveTaskId(t.id); setView("tasks"); }} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Three-column grid: today's tasks, deadlines, week progress */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Today's tasks */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <CheckCircle2 className="size-4" /> Tugas Hari Ini
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => setView("tasks")}>Semua</Button>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.todaysTasks.length === 0 ? (
              <div className="py-6 text-center">
                <CheckCircle2 className="size-8 mx-auto mb-2 text-success/40" />
                <p className="text-sm text-muted-foreground">Tidak ada tugas hari ini</p>
              </div>
            ) : (
              data.todaysTasks.map((t) => (
                <TaskRow key={t.id} task={t} onClick={() => { setActiveTaskId(t.id); setView("tasks"); }} />
              ))
            )}
          </CardContent>
        </Card>

        {/* Nearest deadlines */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <CalendarClock className="size-4" /> Deadline Terdekat
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.nearestDeadlines.length === 0 ? (
              <div className="py-6 text-center">
                <CalendarClock className="size-8 mx-auto mb-2 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">Belum ada deadline</p>
              </div>
            ) : (
              data.nearestDeadlines.slice(0, 5).map((t) => (
                <TaskRow key={t.id} task={t} onClick={() => { setActiveTaskId(t.id); setView("tasks"); }} />
              ))
            )}
          </CardContent>
        </Card>

        {/* Week progress */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <TrendingUp className="size-4" /> Progres Minggu Ini
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between mb-3">
              <div>
                <div className="text-3xl font-bold tabular-nums">{weekProgress}%</div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {data.weekStats.total > 0
                    ? `${data.weekStats.completed} selesai dari ${data.weekStats.total}`
                    : "Tidak ada tugas pekan ini"}
                </p>
              </div>
              {data.weekStats.total > 0 && (
                <div className="text-right">
                  <div className="text-lg font-semibold tabular-nums">{data.weekStats.remaining}</div>
                  <div className="text-[11px] text-muted-foreground">tersisa</div>
                </div>
              )}
            </div>
            <Progress value={weekProgress} className="h-2.5" />
            <div className="flex justify-between mt-1.5 text-[10px] text-muted-foreground">
              <span>Sen</span><span>Jum</span><span>Ming</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming exams + AI insight */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Upcoming exams */}
        <Card>
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <BookOpen className="size-4" /> Ujian Mendatang
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={() => setView("exams")}>Lihat</Button>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {data.upcomingExams.length === 0 ? (
              <div className="py-6 text-center">
                <BookOpen className="size-8 mx-auto mb-2 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">Tidak ada ujian terjadwal</p>
              </div>
            ) : (
              data.upcomingExams.map((e) => (
                <button key={e.id} onClick={() => setView("exams")} className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-accent/50 transition text-left">
                  <div className="text-center shrink-0 w-12">
                    <div className={cn("text-xl font-bold leading-none tabular-nums", e.daysUntil <= 3 ? "text-urgent" : "text-primary")}>{e.daysUntil}</div>
                    <div className="text-[10px] text-muted-foreground">hari</div>
                  </div>
                  <div className="h-8 w-px bg-border" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{e.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{e.course?.name}</p>
                  </div>
                  <Badge variant="outline" className="text-[10px]">{e.type}</Badge>
                </button>
              ))
            )}
          </CardContent>
        </Card>

        {/* AI insight */}
        <Card className={cn("bg-gradient-to-br", data.aiAvailable ? "from-primary/5 via-card to-card border-primary/20" : "opacity-60")}>
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Sparkles className="size-4 text-primary" /> Insight AI
            </CardTitle>
            {data.aiAvailable && !insight && (
              <Button variant="ghost" size="sm" onClick={generateInsight} disabled={insightLoading}>
                {insightLoading ? <Loader2 className="size-3.5 animate-spin" /> : <Zap className="size-3.5" />}
                Buat
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {insight ? (
              <p className="text-sm leading-relaxed">{insight}</p>
            ) : insightLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                {data.aiAvailable
                  ? "Klik \"Buat\" untuk mendapat ringkasan harian dan saran prioritas dari AI."
                  : "Aktifkan AI di Pengaturan untuk mendapat ringkasan harian otomatis."}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatChip({ icon: Icon, label, value, tone }: { icon: typeof Clock; label: string; value: string; tone: "primary" | "urgent" | "default" | "muted" }) {
  const toneClasses = {
    primary: "text-primary bg-primary/10",
    urgent: "text-urgent bg-urgent/10",
    default: "text-foreground bg-muted",
    muted: "text-muted-foreground bg-muted",
  };
  return (
    <Card className="p-3 h-full">
      <div className="flex items-center gap-2.5 h-full">
        <div className={cn("size-9 rounded-lg flex items-center justify-center shrink-0", toneClasses[tone])}>
          <Icon className="size-4.5" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-xl font-bold leading-none tabular-nums">{value}</div>
          <div className="text-xs text-muted-foreground mt-1 leading-tight">{label}</div>
        </div>
      </div>
    </Card>
  );
}

function TaskRow({ task, onClick }: { task: import("@/lib/types").Task; onClick: () => void }) {
  const status = displayStatus(task.status as never, task.dueAt);
  const priority = PRIORITIES.find((p) => p.value === task.priority);
  const qc = useQueryClient();
  const [toggling, setToggling] = useState(false);

  const quickComplete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (toggling) return;
    setToggling(true);
    try {
      const newStatus = status === "DONE" ? "NOT_STARTED" : "DONE";
      await fetchApi(`/api/tasks/${task.id}`, { method: "PATCH", json: { status: newStatus, progress: newStatus === "DONE" ? 100 : 0 } });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      qc.invalidateQueries({ queryKey: apiKeys.tasks() });
    } catch { /* ignore */ }
    finally { setToggling(false); }
  };

  return (
    <div className="w-full flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-accent/50 transition">
      <button onClick={quickComplete} disabled={toggling} className="shrink-0" title={status === "DONE" ? "Batalkan selesai" : "Tandai selesai"}>
        {status === "DONE" ? (
          <CheckCircle2 className="size-5 text-success fill-success/20 shrink-0" />
        ) : status === "OVERDUE" ? (
          <Circle className="size-5 text-urgent fill-urgent/10 shrink-0" />
        ) : (
          <Circle className="size-5 text-muted-foreground shrink-0 hover:text-primary transition" />
        )}
      </button>
      <button onClick={onClick} className="flex-1 min-w-0 text-left">
        <p className={cn("text-sm font-medium truncate", status === "DONE" && "line-through text-muted-foreground")}>{task.title}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {task.course && <span className="truncate">{task.course.name}</span>}
          {task.dueAt && <span>· {relativeTime(task.dueAt)}</span>}
        </div>
      </button>
      {priority && <span className={cn("text-[10px] font-semibold uppercase shrink-0", priority.className)}>{priority.label}</span>}
    </div>
  );
}
