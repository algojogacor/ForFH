"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import type { Course, Task, Note, Exam, ClassSchedule, Reading } from "@/lib/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import {
  ArrowLeft, Clock, MapPin, Video, CheckSquare, BookOpen, Library,
  BookMarked, Plus, Trash2, Calendar, GraduationCap, User, Video as VideoIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { DAYS, DAYS_SHORT, TASK_TYPES, PRIORITIES, EXAM_TYPES, READING_TYPES } from "@/lib/constants";
import { formatTime, formatDateTime, relativeTime, formatDate, displayStatus, toLocalInput, fromLocalInput } from "@/lib/date";
import { TaskStatusBadge, PriorityDot } from "@/components/task-status-badge";
import { toast } from "sonner";
import { useApp } from "@/lib/store";

type Tab = "overview" | "tasks" | "notes" | "exams" | "readings";

type CourseDetail = {
  course: Course;
  schedules: ClassSchedule[];
  tasks: Task[];
  notes: Note[];
  exams: (Exam & { topics: { id: string; title: string; completed: boolean }[] })[];
  readings: Reading[];
};

export function CourseDetailView({ courseId, onBack }: { courseId: string; onBack: () => void }) {
  const [tab, setTab] = useState<Tab>("overview");
  const qc = useQueryClient();
  const { setActiveTaskId, setActiveNoteId } = useApp();
  const [newDay, setNewDay] = useState("1");
  const [newStart, setNewStart] = useState("08:00");
  const [newEnd, setNewEnd] = useState("09:40");
  const [newRoom, setNewRoom] = useState("");
  const [showAddSched, setShowAddSched] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["courseDetail", courseId],
    queryFn: () => fetchApi<CourseDetail>(`/api/courses/${courseId}/detail`),
  });

  const addSchedule = async () => {
    try {
      await fetchApi(`/api/courses/${courseId}/schedule`, { method: "POST", json: { dayOfWeek: Number(newDay), startTime: newStart, endTime: newEnd, room: newRoom || null } });
      qc.invalidateQueries({ queryKey: ["courseDetail", courseId] });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Jadwal ditambahkan");
      setNewRoom(""); setShowAddSched(false);
    } catch (e) { toast.error((e as ApiError).message); }
  };

  const deleteSchedule = async (id: string) => {
    try {
      await fetchApi(`/api/schedules/${id}`, { method: "DELETE" });
      qc.invalidateQueries({ queryKey: ["courseDetail", courseId] });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Jadwal dihapus");
    } catch (e) { toast.error((e as ApiError).message); }
  };

  const deleteCourse = async () => {
    try {
      await fetchApi(`/api/courses/${courseId}`, { method: "DELETE" });
      qc.invalidateQueries({ queryKey: apiKeys.courses() });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Mata kuliah dihapus");
      onBack();
    } catch (e) { toast.error((e as ApiError).message); }
  };

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-32" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const { course, schedules, tasks, notes, exams, readings } = data;
  const activeTasks = tasks.filter((t) => displayStatus(t.status as never, t.dueAt) !== "DONE");
  const completedTasks = tasks.filter((t) => t.status === "DONE");
  const taskProgress = tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0;

  const TABS: { id: Tab; label: string; icon: typeof Clock; count: number }[] = [
    { id: "overview", label: "Overview", icon: GraduationCap, count: 0 },
    { id: "tasks", label: "Tugas", icon: CheckSquare, count: activeTasks.length },
    { id: "notes", label: "Catatan", icon: BookOpen, count: notes.length },
    { id: "exams", label: "Ujian", icon: Library, count: exams.length },
    { id: "readings", label: "Bacaan", icon: BookMarked, count: readings.length },
  ];

  return (
    <div className="space-y-4">
      {/* Back button */}
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition">
        <ArrowLeft className="size-4" /> Kembali ke Mata Kuliah
      </button>

      {/* Course header */}
      <Card className="overflow-hidden border-l-4" style={{ borderLeftColor: course.color || "var(--primary)" }}>
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            <div
              className="size-14 rounded-2xl flex items-center justify-center text-white font-bold text-lg shrink-0 shadow-sm"
              style={{ backgroundColor: course.color || "var(--primary)" }}
            >
              {(course.code || course.name).slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold tracking-tight">{course.name}</h1>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1.5 text-sm text-muted-foreground">
                {course.code && <Badge variant="secondary" className="text-[10px] font-mono">{course.code}</Badge>}
                {course.sks && <span>{course.sks} SKS</span>}
                {course.lecturer && <span className="flex items-center gap-1"><User className="size-3.5" /> {course.lecturer}</span>}
                {course.defaultRoom && <span className="flex items-center gap-1"><MapPin className="size-3.5" /> {course.defaultRoom}</span>}
                {course.onlineUrl && <a href={course.onlineUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-primary hover:underline"><VideoIcon className="size-3.5" /> Online</a>}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto pb-1 scroll-area-thin border-b">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition whitespace-nowrap",
              tab === t.id
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            <t.icon className="size-4" />
            {t.label}
            {t.count > 0 && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{t.count}</Badge>
            )}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === "overview" && (
        <div className="space-y-4">
          {/* Schedule */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2"><Calendar className="size-4" /> Jadwal Mingguan</h3>
                <Button variant="ghost" size="sm" onClick={() => setShowAddSched(!showAddSched)}>
                  <Plus className="size-3.5" /> {showAddSched ? "Tutup" : "Tambah"}
                </Button>
              </div>
              {schedules.length === 0 && !showAddSched ? (
                <p className="text-sm text-muted-foreground py-2">Belum ada jadwal. Klik "Tambah" untuk membuat.</p>
              ) : (
                <div className="space-y-1.5 mb-2">
                  {schedules.map((s) => (
                    <div key={s.id} className="flex items-center gap-3 rounded-lg bg-muted/40 px-3 py-2 group">
                      <Badge variant="outline" className="text-[10px] w-10 justify-center">{DAYS_SHORT[s.dayOfWeek]}</Badge>
                      <span className="text-sm font-medium tabular-nums">{s.startTime}–{s.endTime}</span>
                      {s.room && <span className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="size-3" />{s.room}</span>}
                      <Button variant="ghost" size="icon" className="size-7 ml-auto opacity-0 group-hover:opacity-100 transition" onClick={() => deleteSchedule(s.id)}>
                        <Trash2 className="size-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
              {showAddSched && (
                <div className="grid grid-cols-[80px_1fr_1fr_1fr] gap-2 pt-2 border-t">
                  <select value={newDay} onChange={(e) => setNewDay(e.target.value)} className="rounded-md border border-input bg-background px-2 py-1.5 text-sm">
                    {DAYS.map((d, i) => <option key={i} value={String(i)}>{DAYS_SHORT[i]}</option>)}
                  </select>
                  <Input type="time" value={newStart} onChange={(e) => setNewStart(e.target.value)} className="h-8 text-sm" />
                  <Input type="time" value={newEnd} onChange={(e) => setNewEnd(e.target.value)} className="h-8 text-sm" />
                  <Button size="sm" onClick={addSchedule}><Plus className="size-3.5" /></Button>
                  <Input value={newRoom} onChange={(e) => setNewRoom(e.target.value)} placeholder="Ruang (opsional)" className="h-8 text-sm col-span-4" />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Task progress */}
          <Card>
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><CheckSquare className="size-4" /> Progres Tugas</h3>
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl font-bold tabular-nums">{taskProgress}%</span>
                <span className="text-xs text-muted-foreground">{completedTasks.length} selesai dari {tasks.length}</span>
              </div>
              <Progress value={taskProgress} className="h-2" />
            </CardContent>
          </Card>

          {/* Quick stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <StatBox icon={CheckSquare} label="Tugas Aktif" value={activeTasks.length} />
            <StatBox icon={BookOpen} label="Catatan" value={notes.length} />
            <StatBox icon={Library} label="Ujian" value={exams.length} />
            <StatBox icon={BookMarked} label="Bacaan" value={readings.length} />
          </div>

          {/* Upcoming deadlines */}
          {activeTasks.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold mb-3">Deadline Mendatang</h3>
                <div className="space-y-1.5">
                  {activeTasks.slice(0, 5).map((t) => (
                    <div key={t.id} className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-accent/50 cursor-pointer" onClick={() => setActiveTaskId(t.id)}>
                      <PriorityDot priority={t.priority} />
                      <span className="text-sm flex-1 truncate">{t.title}</span>
                      {t.dueAt && <span className="text-xs text-muted-foreground">{relativeTime(t.dueAt)}</span>}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Danger zone */}
          <Card className="border-destructive/20">
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold text-destructive mb-2">Zona Berbahaya</h3>
              <p className="text-xs text-muted-foreground mb-3">Menghapus mata kuliah akan menghapus semua jadwal terkait. Tugas dan catatan tetap ada tapi tidak terkait.</p>
              <Button variant="destructive" size="sm" onClick={deleteCourse}>
                <Trash2 className="size-4" /> Hapus Mata Kuliah
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "tasks" && (
        <div className="space-y-2">
          {activeTasks.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
              <CheckSquare className="size-8 mx-auto mb-2 opacity-40" />
              Tidak ada tugas aktif untuk mata kuliah ini.
            </Card>
          ) : (
            activeTasks.map((t) => (
              <button key={t.id} onClick={() => setActiveTaskId(t.id)} className="w-full text-left">
                <Card className="p-3.5 hover:shadow-sm transition">
                  <div className="flex items-center gap-3">
                    <PriorityDot priority={t.priority} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{t.title}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <Badge variant="outline" className="text-[9px]">{TASK_TYPES.find(x=>x.value===t.type)?.label ?? t.type}</Badge>
                        {t.dueAt && <span>{relativeTime(t.dueAt)}</span>}
                      </div>
                    </div>
                    <TaskStatusBadge status={t.status as never} dueAt={t.dueAt} />
                  </div>
                </Card>
              </button>
            ))
          )}
        </div>
      )}

      {tab === "notes" && (
        <div className="space-y-2">
          {notes.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
              <BookOpen className="size-8 mx-auto mb-2 opacity-40" />
              Belum ada catatan untuk mata kuliah ini.
            </Card>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {notes.map((n) => (
                <button key={n.id} onClick={() => setActiveNoteId(n.id)} className="text-left">
                  <Card className="p-4 hover:shadow-sm transition h-full">
                    <p className="font-medium truncate">{n.title}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{n.content || "Catatan kosong"}</p>
                    <p className="text-[10px] text-muted-foreground mt-2">{relativeTime(n.updatedAt)}</p>
                  </Card>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === "exams" && (
        <div className="space-y-2">
          {exams.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
              <Library className="size-8 mx-auto mb-2 opacity-40" />
              Belum ada ujian untuk mata kuliah ini.
            </Card>
          ) : (
            exams.map((e) => {
              const daysUntil = Math.ceil((new Date(e.examAt).getTime() - Date.now()) / 86400000);
              const total = e.topics?.length ?? 0;
              const done = e.topics?.filter((t) => t.completed).length ?? 0;
              return (
                <Card key={e.id} className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={cn("text-center shrink-0 w-12 rounded-lg p-2", daysUntil <= 3 && daysUntil >= 0 ? "bg-urgent/10 text-urgent" : "bg-primary/10 text-primary")}>
                      <div className="text-lg font-bold leading-none">{daysUntil < 0 ? "—" : daysUntil}</div>
                      <div className="text-[10px]">{daysUntil < 0 ? "selesai" : "hari"}</div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium">{e.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <Badge variant="outline" className="text-[9px]">{e.type}</Badge>
                        <span>{formatDateTime(e.examAt)}</span>
                      </div>
                      {total > 0 && (
                        <div className="mt-2">
                          <div className="flex justify-between text-[11px] text-muted-foreground mb-1"><span>Topik: {done}/{total}</span></div>
                          <Progress value={Math.round((done/total)*100)} className="h-1" />
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })
          )}
        </div>
      )}

      {tab === "readings" && (
        <div className="space-y-2">
          {readings.length === 0 ? (
            <Card className="p-8 text-center text-sm text-muted-foreground border-dashed">
              <BookMarked className="size-8 mx-auto mb-2 opacity-40" />
              Belum ada bacaan untuk mata kuliah ini.
            </Card>
          ) : (
            readings.map((r) => (
              <Card key={r.id} className="p-4">
                <div className="flex items-start gap-3">
                  <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <BookMarked className="size-4.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{r.title}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                      <Badge variant="secondary" className="text-[9px]">{READING_TYPES.find(t=>t.value===r.type)?.label ?? r.type}</Badge>
                      {r.currentPage && r.endPage && <span>Hal. {r.currentPage}/{r.endPage}</span>}
                      {r.deadline && <span>· {formatDate(r.deadline)}</span>}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-[9px]">{r.status === "DONE" ? "Selesai" : r.status === "READING" ? "Sedang Baca" : "Belum"}</Badge>
                </div>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function StatBox({ icon: Icon, label, value }: { icon: typeof Clock; label: string; value: number }) {
  return (
    <Card className="p-3">
      <div className="flex items-center gap-2.5">
        <div className="size-8 rounded-lg bg-muted flex items-center justify-center shrink-0">
          <Icon className="size-4 text-muted-foreground" />
        </div>
        <div>
          <div className="text-lg font-bold tabular-nums leading-none">{value}</div>
          <div className="text-[11px] text-muted-foreground truncate mt-0.5">{label}</div>
        </div>
      </div>
    </Card>
  );
}
