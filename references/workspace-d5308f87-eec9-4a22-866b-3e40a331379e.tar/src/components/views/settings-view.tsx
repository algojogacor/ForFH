"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTheme } from "next-themes";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { UserSettings } from "@/lib/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useApp } from "@/lib/store";
import { features } from "@/lib/env-features";
import { toast } from "sonner";
import { User, Palette, Clock, Bell, Sparkles, Smartphone, Save, Loader2 } from "lucide-react";
import { CLASS_REMINDER_OFFSETS, TASK_REMINDER_OFFSETS } from "@/lib/constants";
import { cn } from "@/lib/utils";

const TIMEZONES = ["Asia/Jakarta", "Asia/Makassar", "Asia/Jayapura", "Asia/Pontianak", "Europe/London", "America/New_York"];

export function SettingsView() {
  const { user, setUser } = useApp();
  const { setTheme: setAppTheme } = useTheme();
  const qc = useQueryClient();
  const [displayName, setDisplayName] = useState(user?.displayName ?? "");
  const [theme, setTheme] = useState("system");
  const [timezone, setTimezone] = useState("Asia/Jakarta");
  const [aiEnabled, setAiEnabled] = useState(true);
  const [classReminders, setClassReminders] = useState<number[]>([120, 60, 30, 20]);
  const [taskReminders, setTaskReminders] = useState<number[]>([1440, 360, 60]);
  const [primaryAlert, setPrimaryAlert] = useState(240);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);

  const { data: settings, isLoading } = useQuery({
    queryKey: apiKeys.settings(),
    queryFn: () => fetchApi<{ settings: UserSettings }>("/api/settings").then((r) => r.settings),
  });

  useEffect(() => {
    if (settings) {
      setTheme(settings.theme);
      setAppTheme(settings.theme);
      setTimezone(settings.timezone);
      setAiEnabled(settings.aiEnabled);
      setClassReminders(settings.defaultClassReminders.split(",").map(Number).filter(Boolean));
      setTaskReminders(settings.defaultTaskReminders.split(",").map(Number).filter(Boolean));
      setPrimaryAlert(settings.primaryClassAlertMinutes);
    }
  }, [settings, setAppTheme]);

  // live-apply theme toggle
  useEffect(() => { setAppTheme(theme); }, [theme, setAppTheme]);

  const saveProfile = async () => {
    setSavingProfile(true);
    try {
      const r = await fetchApi<{ user: { id: string; username: string; displayName: string | null } }>("/api/settings/profile", { method: "PATCH", json: { displayName: displayName.trim() || null } });
      if (user) setUser({ ...user, displayName: r.user.displayName });
      toast.success("Profil disimpan");
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setSavingProfile(false); }
  };

  const saveSettings = async () => {
    setSavingSettings(true);
    try {
      await fetchApi("/api/settings", { method: "PATCH", json: {
        theme, timezone, aiEnabled,
        defaultClassReminders: classReminders.join(","),
        defaultTaskReminders: taskReminders.join(","),
        primaryClassAlertMinutes: primaryAlert,
      } });
      qc.invalidateQueries({ queryKey: apiKeys.settings() });
      toast.success("Pengaturan disimpan");
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setSavingSettings(false); }
  };

  const toggleReminder = (list: number[], setList: (v: number[]) => void, val: number) => {
    setList(list.includes(val) ? list.filter((x) => x !== val) : [...list, val].sort((a, b) => a - b));
  };

  if (isLoading || !settings) return <div className="space-y-3">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}</div>;

  return (
    <div className="space-y-4 max-w-3xl">
      <h1 className="text-2xl font-bold tracking-tight">Pengaturan</h1>

      {/* Profile */}
      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><User className="size-4" /> Profil</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Username</Label>
            <Input value={user?.username ?? ""} disabled className="bg-muted/50" />
          </div>
          <div className="space-y-1.5">
            <Label>Nama Tampilan</Label>
            <Input value={displayName} onChange={(e)=>setDisplayName(e.target.value)} placeholder="Nama panggilanmu" />
          </div>
          <Button onClick={saveProfile} disabled={savingProfile} size="sm">{savingProfile ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} Simpan Profil</Button>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Palette className="size-4" /> Tampilan</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <Label>Tema</Label>
          <div className="grid grid-cols-3 gap-2">
            {["system","light","dark"].map((t) => (
              <button key={t} onClick={()=>setTheme(t)} className={cn(
                "rounded-lg border p-4 text-sm font-medium capitalize transition flex flex-col items-center gap-2",
                theme===t ? "border-primary bg-primary/10 text-primary ring-1 ring-primary/20" : "hover:bg-accent text-muted-foreground hover:text-foreground",
              )}>
                <span className={cn("size-6 rounded-full", t === "system" ? "bg-gradient-to-br from-background to-foreground/40 ring-1 ring-border" : t === "light" ? "bg-background border border-border" : "bg-foreground")} />
                {t === "system" ? "Sistem" : t === "light" ? "Terang" : "Gelap"}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Localization */}
      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Clock className="size-4" /> Zona Waktu</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Zona Waktu</Label>
            <select value={timezone} onChange={(e)=>setTimezone(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
              {TIMEZONES.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Bell className="size-4" /> Pengingat Kelas</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Peringatan utama (sebelum kelas)</Label>
            <select value={primaryAlert} onChange={(e)=>setPrimaryAlert(Number(e.target.value))} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
              <option value={240}>4 jam (default)</option>
              <option value={180}>3 jam</option>
              <option value={120}>2 jam</option>
            </select>
            <p className="text-[11px] text-muted-foreground">Pada versi web, ini hanya notifikasi push (bukan alarm persisten).</p>
          </div>
          <div className="space-y-1.5">
            <Label>Pengingat tambahan</Label>
            <div className="flex flex-wrap gap-2">
              {CLASS_REMINDER_OFFSETS.map((m) => (
                <button key={m} onClick={()=>toggleReminder(classReminders, setClassReminders, m)} className={`rounded-full px-3 py-1.5 text-xs font-medium border transition ${classReminders.includes(m) ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground hover:bg-accent"}`}>
                  {m >= 60 ? `${m/60} jam` : `${m} mnt`}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Bell className="size-4" /> Pengingat Tugas</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Pengingat default sebelum deadline</Label>
            <div className="flex flex-wrap gap-2">
              {TASK_REMINDER_OFFSETS.map((m) => (
                <button key={m} onClick={()=>toggleReminder(taskReminders, setTaskReminders, m)} className={`rounded-full px-3 py-1.5 text-xs font-medium border transition ${taskReminders.includes(m) ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground hover:bg-accent"}`}>
                  {m >= 1440 ? `${m/1440} hari` : m >= 60 ? `${m/60} jam` : `${m} mnt`}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI */}
      <Card>
        <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Sparkles className="size-4" /> AI</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label>Aktifkan AI</Label>
              <p className="text-[11px] text-muted-foreground">Quick Capture, pecah tugas, smart deadline, insight</p>
            </div>
            <Switch checked={aiEnabled} onCheckedChange={setAiEnabled} />
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Badge variant="secondary">Status: {features.ai ? "Tersedia" : "Tidak aktif"}</Badge>
          </div>
        </CardContent>
      </Card>

      {/* PWA & Notifications */}
      <PushNotificationCard />

      <Button onClick={saveSettings} disabled={savingSettings} className="w-full">
        {savingSettings ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />} Simpan Pengaturan
      </Button>
    </div>
  );
}

function PushNotificationCard() {
  const [subscribed, setSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);

  const checkStatus = async () => {
    try {
      const r = await fetchApi<{ subscribed: boolean; vapidEnabled: boolean }>("/api/push/subscribe");
      setSubscribed(r.subscribed);
    } catch { /* ignore */ }
  };
  useEffect(() => { checkStatus(); }, []);

  const subscribe = async () => {
    setLoading(true);
    try {
      const { subscribeToPush } = await import("@/lib/push-client");
      const sub = await subscribeToPush();
      await fetchApi("/api/push/subscribe", { method: "POST", json: sub });
      setSubscribed(true);
      toast.success("Notifikasi push diaktifkan!");
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setLoading(false); }
  };

  const test = async () => {
    setTesting(true);
    try {
      const r = await fetchApi<{ sent: number; failed: number }>("/api/push/test", { method: "POST" });
      if (r.sent > 0) toast.success(`Notifikasi tes terkirim! (${r.sent})`);
      else toast.error("Tidak ada notifikasi terkirim.");
    } catch (e) { toast.error((e as ApiError).message); }
    finally { setTesting(false); }
  };

  return (
    <Card>
      <CardHeader><CardTitle className="text-sm font-semibold flex items-center gap-2"><Smartphone className="size-4" /> Notifikasi & PWA</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Status Push</p>
            <p className="text-[11px] text-muted-foreground">{subscribed ? "Aktif — kamu akan menerima pengingat" : "Belum aktif"}</p>
          </div>
          <Badge variant={subscribed ? "secondary" : "outline"} className={subscribed ? "bg-success/10 text-success" : ""}>
            {subscribed ? "Aktif" : "Nonaktif"}
          </Badge>
        </div>
        {!subscribed ? (
          <Button onClick={subscribe} disabled={loading} className="w-full">
            {loading ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />} Aktifkan Push Notification
          </Button>
        ) : (
          <Button variant="outline" onClick={test} disabled={testing} className="w-full">
            {testing ? <Loader2 className="size-4 animate-spin" /> : <Bell className="size-4" />} Kirim Notifikasi Tes
          </Button>
        )}
        <p className="text-[11px] text-muted-foreground">Pengingat kelas & deadline otomatis diproses setiap 5 menit. ForFH juga dapat dipasang sebagai PWA (Add to Home Screen).</p>
      </CardContent>
    </Card>
  );
}
