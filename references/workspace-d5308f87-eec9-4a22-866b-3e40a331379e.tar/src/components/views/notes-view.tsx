"use client";

import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Note, Course } from "@/lib/types";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from "@/components/ui/sheet";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { useApp } from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pin, Trash2, FileText, Eye, Pencil, Download } from "lucide-react";
import { cn } from "@/lib/utils";
import { EmptyState } from "@/components/empty-state";
import { formatDateTime, relativeTime } from "@/lib/date";

export function NotesView() {
  const { activeNoteId, setActiveNoteId } = useApp();
  const qc = useQueryClient();
  const [newOpen, setNewOpen] = useState(false);

  const { data: notes, isLoading } = useQuery({
    queryKey: apiKeys.notes(),
    queryFn: () => fetchApi<{ notes: Note[] }>("/api/notes").then((r) => r.notes),
  });
  const { data: courses } = useQuery({
    queryKey: apiKeys.courses(),
    queryFn: () => fetchApi<{ courses: Course[] }>("/api/courses").then((r) => r.courses),
  });

  const activeNote = notes?.find((n) => n.id === activeNoteId);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Catatan</h1>
          <p className="text-sm text-muted-foreground">{notes?.length ?? 0} catatan</p>
        </div>
        <div className="flex items-center gap-2">
          {(notes?.length ?? 0) > 0 && (
            <Button variant="outline" size="sm" onClick={() => window.open("/api/export/notes", "_blank")}>
              <Download className="size-4" /> Export
            </Button>
          )}
          <Button onClick={()=>setNewOpen(true)} className="lg:hidden"><Plus className="size-4" /> Baru</Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{[...Array(6)].map((_,i)=><Skeleton key={i} className="h-32" />)}</div>
      ) : notes?.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="Belum ada catatan"
          description="Catat poin kuliah, rangkuman, atau ide belajarmu dalam Markdown."
          action={{ label: "Buat Catatan Pertama", onClick: () => setNewOpen(true) }}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {notes?.map((n) => (
            <button key={n.id} onClick={()=>setActiveNoteId(n.id)} className="text-left">
              <Card className="h-full hover:shadow-sm transition p-4 flex flex-col">
                <div className="flex items-start gap-2">
                  <p className="font-medium flex-1 line-clamp-2">{n.title}</p>
                  {n.pinned && <Pin className="size-3.5 text-primary shrink-0 fill-primary" />}
                </div>
                <p className="text-xs text-muted-foreground mt-1.5 line-clamp-3 flex-1">{n.content || "Catatan kosong"}</p>
                <div className="flex items-center gap-2 mt-3 text-[11px] text-muted-foreground">
                  {n.course && <span className="truncate">{n.course.name}</span>}
                  <span>· {relativeTime(n.updatedAt)}</span>
                </div>
              </Card>
            </button>
          ))}
        </div>
      )}

      <Sheet open={Boolean(activeNote)} onOpenChange={(o)=>{ if(!o) setActiveNoteId(null); }}>
        <SheetContent className="w-full sm:max-w-2xl flex flex-col">
          <SheetHeader className="sr-only"><SheetTitle>Catatan</SheetTitle></SheetHeader>
          {activeNote ? <NoteEditorContent key={activeNote.id} note={activeNote} courses={courses ?? []} onClose={()=>setActiveNoteId(null)} /> : null}
        </SheetContent>
      </Sheet>
      <NoteDialog open={newOpen} onOpenChange={setNewOpen} courses={courses ?? []} />
    </div>
  );
}

function NoteEditorContent({ note, courses, onClose }: { note: Note; courses: Course[]; onClose: () => void }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState(note.title);
  const [content, setContent] = useState(note.content);
  const [courseId, setCourseId] = useState<string | null>(note.courseId);
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const save = useMutation({
    mutationFn: () => fetchApi(`/api/notes/${note.id}`, { method: "PATCH", json: { title, content, courseId } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.notes() }); },
  });

  const del = useMutation({
    mutationFn: () => fetchApi(`/api/notes/${note.id}`, { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: apiKeys.notes() }); toast.success("Catatan dihapus"); onClose(); },
  });

  // track latest values for unmount flush
  const latest = useRef({ title, content, courseId, note });

  // autosave (component is keyed by note.id, so initial state matches)
  useEffect(() => {
    latest.current = { title, content, courseId, note };
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      save.mutate();
    }, 1500);
    return () => { if (saveTimer.current) clearTimeout(saveTimer.current); };
  }, [title, content, courseId, note]);

  // flush pending changes on unmount
  useEffect(() => {
    return () => {
      const { title: t, content: c, courseId: ci, note: n } = latest.current;
      if (t !== n.title || c !== n.content || ci !== n.courseId) {
        fetchApi(`/api/notes/${n.id}`, { method: "PATCH", json: { title: t, content: c, courseId: ci } }).catch(() => {});
      }
    };
  }, []);

  const handleClose = () => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    save.mutate();
    onClose();
  };

  return (
    <>
      <div className="flex items-center gap-2 px-4 pt-3">
        <Input value={title} onChange={(e)=>setTitle(e.target.value)} className="text-lg font-semibold border-0 px-0 focus-visible:ring-0" placeholder="Judul catatan" />
        <Button variant="ghost" size="icon" onClick={()=>setMode(mode==="edit"?"preview":"edit")}>
          {mode==="edit" ? <Eye className="size-4" /> : <Pencil className="size-4" />}
        </Button>
      </div>
      <div className="flex-1 flex flex-col overflow-hidden px-4 pb-4">
        <div className="flex items-center gap-2 mb-3">
          <Select value={courseId ?? "none"} onValueChange={(v)=>setCourseId(v==="none"?null:v)}>
            <SelectTrigger className="h-8 w-auto text-xs"><SelectValue placeholder="Tanpa MK" /></SelectTrigger>
            <SelectContent><SelectItem value="none">— Tanpa MK —</SelectItem>{courses.map((c)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
          </Select>
          <span className="text-xs text-muted-foreground ml-auto">Tersimpan otomatis · {formatDateTime(note.updatedAt)}</span>
        </div>
        {mode === "edit" ? (
          <textarea
            value={content}
            onChange={(e)=>setContent(e.target.value)}
            placeholder="Tulis dalam Markdown... # Judul, **tebal**, - list, [link](url)"
            className="flex-1 w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm font-mono outline-none focus-visible:ring-2 focus-visible:ring-ring scroll-area-thin"
            autoFocus
          />
        ) : (
          <div className="flex-1 overflow-y-auto scroll-area-thin rounded-md border bg-muted/20 p-4 prose prose-sm dark:prose-invert max-w-none">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>{content || "*Catatan kosong*"}</ReactMarkdown>
          </div>
        )}
        <div className="flex items-center gap-2 mt-3">
          <Button variant="destructive" size="sm" onClick={()=>del.mutate()}><Trash2 className="size-4" /> Hapus</Button>
          <Button variant="ghost" size="sm" onClick={handleClose} className="ml-auto">Tutup</Button>
        </div>
      </div>
    </>
  );
}

function NoteDialog({ open, onOpenChange, courses }: { open: boolean; onOpenChange:(o:boolean)=>void; courses: Course[] }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [courseId, setCourseId] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      const r = await fetchApi<{ note: Note }>("/api/notes", { method: "POST", json: { title: title.trim(), content: "", courseId } });
      qc.invalidateQueries({ queryKey: apiKeys.notes() });
      onOpenChange(false);
      setTitle("");
      // open editor
      setTimeout(()=>{ window.dispatchEvent(new CustomEvent("forfh:openNote", { detail: r.note.id })); }, 100);
    } catch (e) { toast.error((e as ApiError).message); }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader><SheetTitle>Catatan Baru</SheetTitle></SheetHeader>
        <form onSubmit={submit} className="space-y-3 px-4 pb-6">
          <div className="space-y-1.5"><Label>Judul</Label><Input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Catatan kuliah..." autoFocus required /></div>
          <div className="space-y-1.5"><Label>Mata Kuliah (opsional)</Label>
            <Select value={courseId ?? "none"} onValueChange={(v)=>setCourseId(v==="none"?null:v)}><SelectTrigger><SelectValue placeholder="—" /></SelectTrigger><SelectContent><SelectItem value="none">— Tanpa MK —</SelectItem>{courses.map((c)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select>
          </div>
          <SheetFooter><Button type="submit" className="w-full"><Plus className="size-4" /> Buat</Button></SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
