"use client";

import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

type EmptyStateProps = {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
  className?: string;
  compact?: boolean;
};

export function EmptyState({ icon: Icon, title, description, action, className, compact }: EmptyStateProps) {
  return (
    <div className={cn(
      "flex flex-col items-center justify-center text-center rounded-xl border border-dashed bg-muted/20",
      compact ? "py-8 px-4" : "py-10 px-6",
      className,
    )}>
      <div className={cn(
        "rounded-2xl bg-muted/60 flex items-center justify-center mb-3 ring-1 ring-border",
        compact ? "size-10" : "size-12",
      )}>
        <Icon className={cn("text-muted-foreground/70", compact ? "size-5" : "size-6")} />
      </div>
      <p className={cn("font-semibold", compact ? "text-sm" : "text-base")}>{title}</p>
      {description && (
        <p className="text-sm text-muted-foreground mt-1 max-w-sm leading-relaxed">{description}</p>
      )}
      {action && (
        <Button onClick={action.onClick} size="sm" className="mt-4 gap-1.5">
          {action.label}
        </Button>
      )}
    </div>
  );
}
