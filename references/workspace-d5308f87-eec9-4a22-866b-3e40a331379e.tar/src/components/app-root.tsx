"use client";

import { useEffect } from "react";
import { fetchApi } from "@/lib/fetch";
import { useApp } from "@/lib/store";
import type { User } from "@/lib/types";
import { AuthScreen } from "@/components/auth-screen";
import { AppShell } from "@/components/app-shell";
import { OnboardingDialog } from "@/components/onboarding-dialog";

export function AppRoot({ initialUser }: { initialUser: User | null }) {
  const { user, setUser, setOnboardingOpen } = useApp();

  useEffect(() => {
    setUser(initialUser);
  }, [initialUser, setUser]);

  // Handle 401 globally -> sign out
  useEffect(() => {
    const handler = () => setUser(null);
    window.addEventListener("forfh:unauthorized", handler);
    return () => window.removeEventListener("forfh:unauthorized", handler);
  }, [setUser]);

  // Check onboarding status once authed
  useEffect(() => {
    if (!user) return;
    fetchApi<{ needsOnboarding: boolean }>("/api/onboarding")
      .then((r) => {
        if (r.needsOnboarding) setOnboardingOpen(true);
      })
      .catch(() => {});
  }, [user, setOnboardingOpen]);

  if (!user) return <AuthScreen onAuthed={(u) => setUser(u)} />;

  return (
    <>
      <AppShell />
      <OnboardingDialog />
    </>
  );
}
