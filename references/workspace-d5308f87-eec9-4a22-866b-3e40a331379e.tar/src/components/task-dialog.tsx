"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import type { Course, Task } from "@/lib/types";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { TASK_TYPES, PRIORITIES } from "@/lib/constants";
import { fromLocalInput, toLocalInput } from "@/lib/date";
import { toast } from "sonner";
import { Loader2, Plus } from "lucide-react";

export function TaskDialog({
  open, onOpenChange, courses, initial,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  courses: Course[];
  initial?: Partial<Task>;
}) {
  const qc = useQueryClient();
  const [title, setTitle] = useState(initial?.title ?? "");
  const [courseId, setCourseId] = useState<string | null>(initial?.courseId ?? null);
  const [type, setType] = useState(initial?.type ?? "assignment");
  const [priority, setPriority] = useState(initial?.priority ?? "medium");
  const [dueAt, setDueAt] = useState(toLocalInput(initial?.dueAt ?? null));
  const [est, setEst] = useState(initial?.estimatedMinutes?.toString() ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setLoading(true);
    try {
      await fetchApi("/api/tasks", {
        method: "POST",
        json: {
          title: title.trim(),
          courseId: courseId ?? null,
          type,
          priority,
          dueAt: dueAt ? fromLocalInput(dueAt) : null,
          estimatedMinutes: est ? Number(est) : null,
          description: description || null,
        },
      });
      qc.invalidateQueries({ queryKey: apiKeys.tasks() });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Tugas ditambahkan");
      setTitle(""); setDueAt(""); setEst(""); setDescription("");
      onOpenChange(false);
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Tugas Baru</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="t-title">Judul</Label>
            <Input id="t-title" value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Contoh: Makalah Hukum Pidana" autoFocus required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Mata Kuliah</Label>
              <Select value={courseId ?? "none"} onValueChange={(v)=>setCourseId(v==="none"?null:v)}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— Tanpa MK —</SelectItem>
                  {courses.map((c)=><SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Jenis</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TASK_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Prioritas</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{PRIORITIES.map((p)=><SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Estimasi (mnt)</Label>
              <Input type="number" value={est} onChange={(e)=>setEst(e.target.value)} min={0} placeholder="60" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Deadline</Label>
            <Input type="datetime-local" value={dueAt} onChange={(e)=>setDueAt(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Deskripsi</Label>
            <Textarea value={description} onChange={(e)=>setDescription(e.target.value)} rows={3} />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading}>
              {loading ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />} Tambah
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
