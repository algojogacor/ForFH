"use client";

import { useApp } from "@/lib/store";
import type { View } from "@/lib/types";
import {
  CalendarDays, CheckSquare, GraduationCap, BookOpen, Library,
  Settings as SettingsIcon, Home, Search, Scale, BookMarked, Plus, LogOut, Menu,
  ClipboardCheck, Award, BarChart3, Timer, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { fetchApi } from "@/lib/fetch";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { QuickCaptureDialog } from "@/components/quick-capture-dialog";
import { SearchDialog } from "@/components/search-dialog";
import { toast } from "sonner";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DashboardView } from "@/components/views/dashboard-view";
import { CalendarView } from "@/components/views/calendar-view";
import { TasksView } from "@/components/views/tasks-view";
import { CoursesView } from "@/components/views/courses-view";
import { NotesView } from "@/components/views/notes-view";
import { ReadingsView } from "@/components/views/readings-view";
import { ExamsView } from "@/components/views/exams-view";
import { LegalView } from "@/components/views/legal-view";
import { SettingsView } from "@/components/views/settings-view";
import { AttendanceView } from "@/components/views/attendance-view";
import { GradesView } from "@/components/views/grades-view";
import { StatsView } from "@/components/views/stats-view";
import { FocusView } from "@/components/views/focus-view";
import { ChatAssistant } from "@/components/chat-assistant";
import { motion, AnimatePresence } from "framer-motion";

const NAV_GROUPS: { label: string; items: { view: View; label: string; icon: typeof Home }[] }[] = [
  {
    label: "Utama",
    items: [
      { view: "dashboard", label: "Beranda", icon: Home },
      { view: "calendar", label: "Kalender", icon: CalendarDays },
      { view: "tasks", label: "Tugas", icon: CheckSquare },
      { view: "focus", label: "Fokus", icon: Timer },
      { view: "stats", label: "Statistik", icon: BarChart3 },
    ],
  },
  {
    label: "Akademik",
    items: [
      { view: "courses", label: "Mata Kuliah", icon: GraduationCap },
      { view: "notes", label: "Catatan", icon: BookOpen },
      { view: "readings", label: "Bacaan", icon: BookMarked },
      { view: "exams", label: "Ujian", icon: Library },
      { view: "attendance", label: "Kehadiran", icon: ClipboardCheck },
      { view: "grades", label: "Nilai & IPK", icon: Award },
    ],
  },
  {
    label: "Lainnya",
    items: [
      { view: "legal", label: "Hukum", icon: Scale },
      { view: "settings", label: "Pengaturan", icon: SettingsIcon },
    ],
  },
];

const MOBILE_NAV: View[] = ["dashboard", "calendar", "tasks", "notes"];

export function AppShell() {
  const { user, view, setView, setQuickCaptureOpen } = useApp();
  const router = useRouter();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  async function logout() {
    try {
      await fetchApi("/api/auth/logout", { method: "POST" });
      router.refresh();
    } catch {
      toast.error("Gagal keluar.");
    }
  }

  const initials = (user?.displayName || user?.username || "U").slice(0, 2).toUpperCase();

  // Keyboard shortcut for search
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === "c" && (e.metaKey || e.ctrlKey) && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        setQuickCaptureOpen(true);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [setQuickCaptureOpen]);

  const ViewComponent = (() => {
    switch (view) {
      case "dashboard": return <DashboardView />;
      case "calendar": return <CalendarView />;
      case "tasks": return <TasksView />;
      case "courses": return <CoursesView />;
      case "notes": return <NotesView />;
      case "readings": return <ReadingsView />;
      case "exams": return <ExamsView />;
      case "legal": return <LegalView />;
      case "settings": return <SettingsView />;
      case "attendance": return <AttendanceView />;
      case "grades": return <GradesView />;
      case "stats": return <StatsView />;
      case "focus": return <FocusView />;
      default: return <DashboardView />;
    }
  })();

  const currentLabel = (() => {
    for (const g of NAV_GROUPS) {
      const found = g.items.find((i) => i.view === view);
      if (found) return found.label;
    }
    return "ForFH";
  })();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r bg-sidebar text-sidebar-foreground fixed inset-y-0 left-0 z-30">
        <div className="flex items-center gap-2.5 px-5 h-16 border-b shrink-0">
          <div className="size-9 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shadow-sm">
            <GraduationCap className="size-5" />
          </div>
          <div>
            <p className="font-bold leading-tight">ForFH</p>
            <p className="text-[11px] text-muted-foreground leading-tight">College OS</p>
          </div>
        </div>
        <nav className="flex-1 px-3 py-3 overflow-y-auto scroll-area-thin space-y-4">
          {NAV_GROUPS.map((group) => (
            <div key={group.label}>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70 px-3 mb-1.5">{group.label}</p>
              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <button
                    key={item.view}
                    onClick={() => setView(item.view)}
                    className={cn(
                      "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors relative group",
                      view === item.view
                        ? "bg-primary/15 text-primary font-semibold"
                        : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
                    )}
                  >
                    {view === item.view && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-1.5 rounded-r-full bg-primary" />
                    )}
                    <item.icon className={cn("size-4 shrink-0", view === item.view ? "text-primary" : "text-muted-foreground group-hover:text-sidebar-foreground")} />
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </nav>
        <div className="p-3 border-t shrink-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-2.5 rounded-lg px-2 py-2 hover:bg-sidebar-accent/50 transition text-left">
                <Avatar className="size-9">
                  <AvatarFallback className="bg-primary/15 text-primary text-xs font-semibold">{initials}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{user?.displayName || user?.username}</p>
                  <p className="text-[11px] text-muted-foreground truncate">@{user?.username}</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>{user?.displayName || user?.username}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setView("settings")}>
                <SettingsIcon className="size-4" /> Pengaturan
              </DropdownMenuItem>
              <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
                <LogOut className="size-4" /> Keluar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Desktop top header */}
      <header className="hidden lg:flex items-center gap-3 fixed top-0 right-0 left-60 z-20 h-16 border-b bg-background/80 backdrop-blur px-6">
        <button
          onClick={() => setSearchOpen(true)}
          className="group flex items-center gap-2.5 rounded-lg border bg-muted/40 px-3.5 py-2 text-sm text-muted-foreground hover:bg-muted hover:border-primary/30 transition flex-1 max-w-md"
        >
          <Search className="size-4 shrink-0 group-hover:text-primary transition-colors" />
          <span>Cari tugas, catatan, mata kuliah...</span>
          <kbd className="ml-auto text-[10px] font-mono bg-background border border-border rounded px-1.5 py-0.5 shrink-0 shadow-sm">/</kbd>
        </button>
        <div className="ml-auto flex items-center gap-2">
          <Button onClick={() => setQuickCaptureOpen(true)} size="sm" className="shrink-0">
            <Plus className="size-4" /> Quick Capture
          </Button>
        </div>
      </header>

      {/* Mobile header */}
      <header className="lg:hidden sticky top-0 z-30 flex items-center justify-between px-4 h-14 border-b bg-background/80 backdrop-blur">
        <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon"><Menu className="size-5" /></Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <SheetHeader className="px-5 py-4 border-b">
              <SheetTitle className="flex items-center gap-2">
                <div className="size-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
                  <GraduationCap className="size-5" />
                </div>
                ForFH
              </SheetTitle>
            </SheetHeader>
            <nav className="p-3 space-y-4 overflow-y-auto scroll-area-thin h-[calc(100%-4rem)]">
              {NAV_GROUPS.map((group) => (
                <div key={group.label}>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70 px-3 mb-1.5">{group.label}</p>
                  <div className="space-y-0.5">
                    {group.items.map((item) => (
                      <button
                        key={item.view}
                        onClick={() => { setView(item.view); setMobileNavOpen(false); }}
                        className={cn(
                          "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium",
                          view === item.view ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-accent/50",
                        )}
                      >
                        <item.icon className="size-4.5" /> {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <button onClick={logout} className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/5">
                <LogOut className="size-4.5" /> Keluar
              </button>
            </nav>
          </SheetContent>
        </Sheet>
        <div className="flex items-center gap-2">
          <div className="size-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center">
            <GraduationCap className="size-4" />
          </div>
          <span className="font-semibold">{currentLabel}</span>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)}><Search className="size-5" /></Button>
      </header>

      {/* Main content */}
      <main className="flex-1 lg:pl-60 lg:pt-16 pb-24 lg:pb-8">
        <div className="px-4 sm:px-6 lg:px-8 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              {ViewComponent}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 border-t bg-background/95 backdrop-blur pb-safe">
        <div className="grid grid-cols-5 items-center h-16">
          {MOBILE_NAV.slice(0, 2).map((v) => {
            const item = NAV_GROUPS[0].items.find((n) => n.view === v)!;
            return (
              <button key={v} onClick={() => setView(v)} className={cn("flex flex-col items-center justify-center gap-0.5 h-full text-[11px]", view === v ? "text-primary" : "text-muted-foreground")}>
                <item.icon className="size-5" /> {item.label}
              </button>
            );
          })}
          <button onClick={() => setQuickCaptureOpen(true)} className="flex items-center justify-center h-full">
            <span className="size-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/30 -mt-4">
              <Plus className="size-6" />
            </span>
          </button>
          {MOBILE_NAV.slice(2).map((v) => {
            const item = NAV_GROUPS[0].items.find((n) => n.view === v) ?? NAV_GROUPS[1].items.find((n) => n.view === v);
            if (!item) return null;
            return (
              <button key={v} onClick={() => setView(v)} className={cn("flex flex-col items-center justify-center gap-0.5 h-full text-[11px]", view === v ? "text-primary" : "text-muted-foreground")}>
                <item.icon className="size-5" /> {item.label}
              </button>
            );
          })}
        </div>
      </nav>

      <QuickCaptureDialog />
      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
      <ChatAssistant />
    </div>
  );
}
