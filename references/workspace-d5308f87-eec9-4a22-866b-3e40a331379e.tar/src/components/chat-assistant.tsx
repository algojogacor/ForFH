"use client";

import { useState, useRef, useEffect } from "react";
import { fetchApi, ApiError } from "@/lib/fetch";
import { Button } from "@/components/ui/button";
import { Sparkles, X, Send, Loader2, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type Message = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  "Apa yang harus saya pelajari hari ini?",
  "Jelaskan asas legalitas dalam hukum pidana",
  "Buat rencana belajar untuk ujian minggu depan",
  "Bagaimana cara menulis makalah hukum yang baik?",
];

export function ChatAssistant() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const send = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { role: "user", content: text.trim() };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const r = await fetchApi<{ reply: string | null; available: boolean }>("/api/ai/chat", {
        method: "POST",
        json: { message: text.trim(), history: messages.slice(-6) },
      });
      if (r.reply) {
        setMessages((m) => [...m, { role: "assistant", content: r.reply! }]);
      } else {
        setMessages((m) => [...m, { role: "assistant", content: "Maaf, AI sedang tidak tersedia. Fitur utama aplikasi tetap dapat digunakan." }]);
      }
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating button — hidden on mobile (bottom nav has FAB), shown on desktop */}
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          "hidden lg:flex fixed bottom-8 right-8 z-40 size-12 rounded-full shadow-xl ring-1 ring-black/5 transition items-center justify-center",
          open ? "bg-destructive text-destructive-foreground rotate-90" : "bg-primary text-primary-foreground hover:scale-105 hover:shadow-2xl",
        )}
        title="ForFH Assistant"
      >
        {open ? <X className="size-5" /> : <Sparkles className="size-5" />}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-24 right-8 z-40 w-[calc(100vw-3rem)] sm:w-96 max-h-[70vh] flex flex-col rounded-2xl border bg-background shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center gap-2.5 p-4 border-b bg-primary/5">
            <div className="size-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
              <Brain className="size-4.5" />
            </div>
            <div>
              <p className="text-sm font-semibold">ForFH Assistant</p>
              <p className="text-[11px] text-muted-foreground">Tanya jawab akademik dengan AI</p>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto scroll-area-thin p-4 space-y-3 min-h-[200px] max-h-[40vh]">
            {messages.length === 0 ? (
              <div className="text-center py-6">
                <Brain className="size-10 mx-auto mb-2 text-primary/30" />
                <p className="text-sm font-medium mb-1">Halo! 👋</p>
                <p className="text-xs text-muted-foreground mb-4">Saya bisa bantu menjelaskan konsep hukum, buat rencana belajar, atau jawab pertanyaan akademik.</p>
                <div className="space-y-1.5">
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      onClick={() => send(s)}
                      className="block w-full text-left text-xs rounded-lg border bg-card px-3 py-2 hover:bg-accent transition"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m, i) => (
                <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                  <div className={cn(
                    "rounded-2xl px-3.5 py-2.5 text-sm max-w-[85%]",
                    m.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-muted rounded-bl-sm",
                  )}>
                    <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
                  </div>
                </div>
              ))
            )}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-2xl rounded-bl-sm px-3.5 py-2.5">
                  <Loader2 className="size-4 animate-spin text-muted-foreground" />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <form
            onSubmit={(e) => { e.preventDefault(); send(input); }}
            className="flex items-center gap-2 p-3 border-t bg-background"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Tulis pertanyaan..."
              className="flex-1 rounded-full border bg-muted/40 px-4 py-2 text-sm outline-none focus:bg-background focus:ring-2 focus:ring-ring transition"
              disabled={loading}
            />
            <Button type="submit" size="icon" disabled={loading || !input.trim()} className="rounded-full shrink-0">
              <Send className="size-4" />
            </Button>
          </form>
        </div>
      )}
    </>
  );
}
