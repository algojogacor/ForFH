"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import { useApp } from "@/lib/store";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { COURSE_COLORS, DAYS } from "@/lib/constants";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, GraduationCap, CalendarDays, Bell, Plus, Check } from "lucide-react";
import { fromLocalInput } from "@/lib/date";

export function OnboardingDialog() {
  const { onboardingOpen: open, setOnboardingOpen, user, setUser } = useApp();
  const qc = useQueryClient();
  const [step, setStep] = useState(0);
  const [displayName, setDisplayName] = useState(user?.displayName ?? "");
  const [termName, setTermName] = useState("");
  const [termStart, setTermStart] = useState("");
  const [termEnd, setTermEnd] = useState("");
  const [courseName, setCourseName] = useState("");
  const [courseCode, setCourseCode] = useState("");
  const [courseColor, setCourseColor] = useState(COURSE_COLORS[0]);
  const [courseDay, setCourseDay] = useState("1");
  const [courseStart, setCourseStart] = useState("08:00");
  const [courseEnd, setCourseEnd] = useState("09:40");
  const [loading, setLoading] = useState(false);
  const [createdCourses, setCreatedCourses] = useState<string[]>([]);

  async function finish() {
    setLoading(true);
    try {
      // 1. display name
      if (displayName.trim() && displayName !== user?.displayName) {
        await fetchApi("/api/settings/profile", { method: "PATCH", json: { displayName: displayName.trim() } }).catch(()=>{});
        if (user) setUser({ ...user, displayName: displayName.trim() });
      }
      // 2. term
      if (termName.trim() && termStart && termEnd) {
        await fetchApi("/api/terms", { method: "POST", json: { name: termName.trim(), startDate: fromLocalInput(`${termStart}T00:00`), endDate: fromLocalInput(`${termEnd}T23:59`), isActive: true } });
      }
      qc.invalidateQueries({ queryKey: apiKeys.terms() });
      qc.invalidateQueries({ queryKey: apiKeys.onboarding() });
      qc.invalidateQueries({ queryKey: apiKeys.courses() });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      setOnboardingOpen(false);
      toast.success("Onboarding selesai. Selamat belajar!");
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setLoading(false);
    }
  }

  async function addCourse() {
    if (!courseName.trim()) return;
    setLoading(true);
    try {
      const c = await fetchApi<{ course: { id: string } }>("/api/courses", { method: "POST", json: { name: courseName.trim(), code: courseCode || null, color: courseColor } });
      const courseId = c.course.id;
      await fetchApi(`/api/courses/${courseId}/schedule`, { method: "POST", json: { dayOfWeek: Number(courseDay), startTime: courseStart, endTime: courseEnd, room: null } });
      setCreatedCourses((p) => [...p, courseName.trim()]);
      setCourseName(""); setCourseCode("");
      setCourseColor(COURSE_COLORS[createdCourses.length % COURSE_COLORS.length]);
      qc.invalidateQueries({ queryKey: apiKeys.courses() });
      toast.success("Mata kuliah ditambahkan");
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setLoading(false);
    }
  }

  const steps = [
    { icon: GraduationCap, title: "Selamat datang di ForFH!", desc: "Mari atur workspace kuliahmu dalam beberapa langkah cepat." },
    { icon: GraduationCap, title: "Profil", desc: "Nama tampilan membantu personalisasi (opsional)." },
    { icon: CalendarDays, title: "Semester", desc: "Buat semester aktifmu." },
    { icon: Plus, title: "Mata Kuliah & Jadwal", desc: "Tambahkan mata kuliah pertama beserta jadwal mingguan." },
    { icon: Bell, title: "Notifikasi", desc: "Aktifkan notifikasi agar tidak ketinggalan kelas & deadline." },
  ];

  return (
    <Dialog open={open} onOpenChange={(o)=>{ if(!o && step===0) {/* allow close */} setOnboardingOpen(o); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2 text-primary mb-1">
            {(() => { const I = steps[step].icon; return <I className="size-5" />; })()}
            <span className="text-xs font-medium">Langkah {step+1} dari {steps.length}</span>
          </div>
          <DialogTitle>{steps[step].title}</DialogTitle>
          <p className="text-sm text-muted-foreground">{steps[step].desc}</p>
        </DialogHeader>

        <div className="space-y-3 min-h-[120px]">
          {step === 0 && (
            <div className="text-sm text-muted-foreground space-y-2">
              <p>ForFH adalah satu tempat untuk semua kebutuhan akademikmu: jadwal, tugas, catatan, deadline, dan asisten AI.</p>
              <p className="text-foreground font-medium">Pertanyaan utama yang akan dijawab dashboard: <span className="text-primary">"Sekarang aku harus ngapain?"</span></p>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-1.5">
              <Label>Nama Tampilan</Label>
              <Input value={displayName} onChange={(e)=>setDisplayName(e.target.value)} placeholder="Nama panggilanmu" />
            </div>
          )}
          {step === 2 && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Nama Semester</Label>
                <Input value={termName} onChange={(e)=>setTermName(e.target.value)} placeholder="Contoh: Semester 3 2026/2027" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Mulai</Label>
                  <Input type="date" value={termStart} onChange={(e)=>setTermStart(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Selesai</Label>
                  <Input type="date" value={termEnd} onChange={(e)=>setTermEnd(e.target.value)} />
                </div>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-3">
              {createdCourses.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {createdCourses.map((c, i) => <span key={i} className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-md flex items-center gap-1"><Check className="size-3" />{c}</span>)}
                </div>
              )}
              <div className="grid grid-cols-[1fr_80px] gap-2">
                <div className="space-y-1.5"><Label>Nama MK</Label><Input value={courseName} onChange={(e)=>setCourseName(e.target.value)} placeholder="Hukum Pidana" /></div>
                <div className="space-y-1.5"><Label>Kode</Label><Input value={courseCode} onChange={(e)=>setCourseCode(e.target.value)} placeholder="HP" /></div>
              </div>
              <div className="grid grid-cols-[80px_1fr_1fr] gap-2">
                <div className="space-y-1.5"><Label>Warna</Label><Input type="color" value={courseColor} onChange={(e)=>setCourseColor(e.target.value)} className="h-9 p-1" /></div>
                <div className="space-y-1.5">
                  <Label>Hari</Label>
                  <Select value={courseDay} onValueChange={setCourseDay}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{DAYS.map((d,i)=><SelectItem key={i} value={String(i)}>{d}</SelectItem>)}</SelectContent></Select>
                </div>
                <div className="space-y-1.5"><Label>Mulai</Label><Input type="time" value={courseStart} onChange={(e)=>setCourseStart(e.target.value)} /></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5"><Label>Selesai</Label><Input type="time" value={courseEnd} onChange={(e)=>setCourseEnd(e.target.value)} /></div>
                <div className="flex items-end"><Button variant="secondary" size="sm" onClick={addCourse} disabled={loading || !courseName.trim()} className="w-full"><Plus className="size-4" /> Tambah MK</Button></div>
              </div>
            </div>
          )}
          {step === 4 && (
            <div className="space-y-3 text-sm">
              <p className="text-muted-foreground">Aktifkan izin notifikasi browser untuk menerima pengingat kelas & deadline.</p>
              <Button variant="outline" className="w-full" onClick={async () => {
                const perm = await Notification.requestPermission();
                if (perm === "granted") toast.success("Notifikasi diaktifkan!");
                else toast.info("Kamu bisa aktifkan nanti di Pengaturan.");
              }}>
                <Bell className="size-4" /> Aktifkan Notifikasi
              </Button>
              <p className="text-xs text-muted-foreground">Kamu bisa menyelesaikan ini nanti. Aplikasi tetap berfungsi tanpa notifikasi.</p>
            </div>
          )}
        </div>

        <DialogFooter className="flex-row gap-2 sm:justify-between">
          <div className="flex items-center gap-2">
            {step > 0 && <Button variant="ghost" onClick={()=>setStep(step-1)}>Kembali</Button>}
            {step < steps.length - 1 && (
              <Button variant="ghost" size="sm" onClick={() => setOnboardingOpen(false)} className="text-muted-foreground">
                Lewati
              </Button>
            )}
          </div>
          {step < steps.length - 1 ? (
            <Button onClick={()=>setStep(step+1)} disabled={step===2 && !termName.trim()}>Lanjut</Button>
          ) : (
            <Button onClick={finish} disabled={loading}>{loading ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />} Selesai</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
