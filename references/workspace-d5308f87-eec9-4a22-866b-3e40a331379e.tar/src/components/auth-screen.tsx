"use client";

import { useState } from "react";
import { fetchApi, ApiError } from "@/lib/fetch";
import type { User } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GraduationCap, Loader2, LogIn, UserPlus } from "lucide-react";
import { toast } from "sonner";

export function AuthScreen({ onAuthed }: { onAuthed: (u: User) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    if (mode === "register" && password !== confirm) {
      toast.error("Password dan konfirmasi tidak cocok.");
      return;
    }
    setLoading(true);
    try {
      const body =
        mode === "login"
          ? { username, password }
          : { username, password, displayName: displayName || undefined };
      const res = await fetchApi<{ user: User; onboardingRequired?: boolean }>(
        `/api/auth/${mode}`,
        { method: "POST", json: body },
      );
      toast.success(mode === "login" ? `Selamat datang, ${res.user.username}!` : "Akun dibuat!");
      onAuthed(res.user);
    } catch (e) {
      const err = e as ApiError;
      toast.error(err.message ?? "Gagal.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 via-background to-emerald-50/40 dark:from-emerald-950/30 dark:via-background dark:to-emerald-950/10 p-4">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center gap-3 mb-8">
          <div className="size-16 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center shadow-lg shadow-primary/20">
            <GraduationCap className="size-9" />
          </div>
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight">ForFH</h1>
            <p className="text-sm text-muted-foreground">College OS pribadimu</p>
          </div>
        </div>

        <div className="rounded-xl border bg-card text-card-foreground shadow-sm p-6">
          <div className="grid grid-cols-2 gap-1 p-1 bg-muted rounded-lg mb-6">
            <button
              onClick={() => setMode("login")}
              className={`text-sm font-medium py-2 rounded-md transition ${mode === "login" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"}`}
            >
              Masuk
            </button>
            <button
              onClick={() => setMode("register")}
              className={`text-sm font-medium py-2 rounded-md transition ${mode === "register" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground"}`}
            >
              Daftar
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="3–32 karakter"
                autoComplete="username"
                autoCapitalize="none"
                required
                minLength={mode === "register" ? 3 : 1}
                maxLength={32}
              />
            </div>

            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="displayName">Nama Tampilan (opsional)</Label>
                <Input
                  id="displayName"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Nama panggilanmu"
                  maxLength={64}
                />
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === "register" ? "Minimal 8 karakter" : "Password"}
                autoComplete={mode === "login" ? "current-password" : "new-password"}
                required
                minLength={mode === "register" ? 8 : 1}
                maxLength={128}
              />
            </div>

            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="confirm">Konfirmasi Password</Label>
                <Input
                  id="confirm"
                  type="password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  autoComplete="new-password"
                  required
                  minLength={8}
                  maxLength={128}
                />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : mode === "login" ? (
                <>
                  <LogIn className="size-4" /> Masuk
                </>
              ) : (
                <>
                  <UserPlus className="size-4" /> Buat Akun
                </>
              )}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground mt-4 text-center">
            {mode === "login" ? "Belum punya akun? " : "Sudah punya akun? "}
            <button
              onClick={() => setMode(mode === "login" ? "register" : "login")}
              className="text-primary font-medium hover:underline"
            >
              {mode === "login" ? "Daftar di sini" : "Masuk"}
            </button>
          </p>
        </div>

        <p className="text-center text-xs text-muted-foreground mt-6 px-4">
          Sistem kuliah pribadimu. Datamu terisolasi — pengguna lain tidak dapat mengaksesnya.
        </p>
      </div>
    </div>
  );
}
