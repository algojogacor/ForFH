"use client";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { fetchApi, ApiError } from "@/lib/fetch";
import { apiKeys } from "@/lib/query-keys";
import { useApp } from "@/lib/store";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Sparkles, Loader2, Mic, Send, Wand2 } from "lucide-react";
import { TASK_TYPES, PRIORITIES } from "@/lib/constants";
import { fromLocalInput } from "@/lib/date";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

type Parsed = {
  title: string;
  courseGuess: string | null;
  type: string;
  dueDate: string | null;
  dueTime: string | null;
  priority: string;
  estimatedMinutes: number | null;
  notes: string | null;
  subtasks: { title: string; estimatedMinutes: number | null }[];
};

export function QuickCaptureDialog() {
  const { quickCaptureOpen: open, setQuickCaptureOpen, user } = useApp();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<Parsed | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [listening, setListening] = useState(false);

  // editable parsed fields
  const [title, setTitle] = useState("");
  const [type, setType] = useState("assignment");
  const [priority, setPriority] = useState("medium");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");

  async function parse() {
    if (text.trim().length < 3) return;
    setLoading(true);
    setParsed(null);
    try {
      const r = await fetchApi<{ parsed: Parsed }>("/api/ai/quick-capture", { method: "POST", json: { text } });
      setParsed(r.parsed);
      setTitle(r.parsed.title);
      setType(r.parsed.type);
      setPriority(r.parsed.priority);
      setDueDate(r.parsed.dueDate ?? "");
      setDueTime(r.parsed.dueTime ?? "");
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setText(""); setParsed(null); setTitle(""); setType("assignment"); setPriority("medium"); setDueDate(""); setDueTime("");
  }

  function close() { setQuickCaptureOpen(false); setTimeout(reset, 200); }

  async function save() {
    if (!title.trim()) return;
    setSaving(true);
    const dueAt = dueDate ? fromLocalInput(`${dueDate}T${dueTime || "23:59"}`) : null;
    try {
      await fetchApi("/api/tasks", {
        method: "POST",
        json: {
          title: title.trim(),
          type,
          priority,
          dueAt,
          estimatedMinutes: parsed?.estimatedMinutes ?? null,
          description: parsed?.notes ?? null,
          source: "quick_capture",
          subtasks: parsed?.subtasks ?? [],
        },
      });
      qc.invalidateQueries({ queryKey: apiKeys.tasks() });
      qc.invalidateQueries({ queryKey: apiKeys.dashboard() });
      toast.success("Tugas ditambahkan dari Quick Capture");
      close();
    } catch (e) {
      toast.error((e as ApiError).message);
    } finally {
      setSaving(false);
    }
  }

  function voiceInput() {
    const SR = (window as unknown as { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any }).SpeechRecognition
      || (window as unknown as { webkitSpeechRecognition?: new () => any }).webkitSpeechRecognition;
    if (!SR) { toast.error("Browser tidak mendukung voice input."); return; }
    const rec = new SR();
    rec.lang = "id-ID";
    rec.interimResults = false;
    setListening(true);
    rec.onresult = (e: any) => { setText(e.results[0][0].transcript); setListening(false); };
    rec.onerror = () => setListening(false);
    rec.onend = () => setListening(false);
    rec.start();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) close(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Sparkles className="size-5 text-primary" /> Quick Capture</DialogTitle>
        </DialogHeader>

        {!parsed ? (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Tulis tugas dengan bahasa natural</Label>
              <textarea
                value={text}
                onChange={(e)=>setText(e.target.value)}
                placeholder="Contoh: Senin depan tugas hukum pidana analisis putusan deadline jam 9 malam"
                rows={3}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                autoFocus
                onKeyDown={(e)=>{ if((e.metaKey||e.ctrlKey)&&e.key==="Enter"){e.preventDefault();parse();} }}
              />
              <p className="text-[11px] text-muted-foreground">AI akan menerjemahkan jadi tugas terstruktur. Tekan Cmd/Ctrl+Enter untuk parse.</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={parse} disabled={loading || text.trim().length<3} className="flex-1">
                {loading ? <><Loader2 className="size-4 animate-spin" /> Memproses...</> : <><Wand2 className="size-4" /> Parse dengan AI</>}
              </Button>
              <Button variant="outline" size="icon" onClick={voiceInput} disabled={listening} title="Voice input">
                {listening ? <Loader2 className="size-4 animate-spin" /> : <Mic className="size-4" />}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-md bg-primary/5 border border-primary/20 p-2 text-[11px] text-muted-foreground">
              Interpretasi AI — periksa & edit sebelum menyimpan.
            </div>
            <div className="space-y-1.5">
              <Label>Judul</Label>
              <Input value={title} onChange={(e)=>setTitle(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Jenis</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TASK_TYPES.map((t)=><SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Prioritas</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PRIORITIES.map((p)=><SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Tanggal</Label>
                <Input type="date" value={dueDate} onChange={(e)=>setDueDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Jam</Label>
                <Input type="time" value={dueTime} onChange={(e)=>setDueTime(e.target.value)} />
              </div>
            </div>
            {parsed.courseGuess && (
              <div className="text-xs text-muted-foreground">Mata kuliah terdeteksi: <Badge variant="secondary" className="text-[10px]">{parsed.courseGuess}</Badge></div>
            )}
            {parsed.subtasks && parsed.subtasks.length > 0 && (
              <div className="text-xs text-muted-foreground">+ {parsed.subtasks.length} subtask akan dibuat</div>
            )}
            {parsed.estimatedMinutes && (
              <div className="text-xs text-muted-foreground">Estimasi: {parsed.estimatedMinutes} menit</div>
            )}
            <DialogFooter>
              <Button variant="ghost" onClick={()=>setParsed(null)}>Edit Teks</Button>
              <Button onClick={save} disabled={saving || !title.trim()}>
                {saving ? <Loader2 className="size-4 animate-spin" /> : null} Simpan
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
