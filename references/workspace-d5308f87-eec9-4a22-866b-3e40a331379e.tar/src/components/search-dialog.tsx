"use client";

import { useState, useEffect } from "react";
import { fetchApi } from "@/lib/fetch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useApp } from "@/lib/store";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, GraduationCap, CheckSquare, BookOpen, BookMarked, Library, CornerDownLeft } from "lucide-react";
import type { Course, Task, Note, Reading, Exam } from "@/lib/types";
import { formatDateTime, relativeTime } from "@/lib/date";

type Results = { courses: Course[]; tasks: Task[]; notes: Note[]; readings: Reading[]; exams: Exam[] };

export function SearchDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { setView, setActiveCourseId, setActiveTaskId, setActiveNoteId } = useApp();
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Results | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!q.trim()) { setResults(null); return; }
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const r = await fetchApi<{ results: Results }>(`/api/search?q=${encodeURIComponent(q)}`);
        setResults(r.results);
      } catch { setResults(null); }
      finally { setLoading(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  // keyboard shortcut "/"
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "/" && document.activeElement?.tagName !== "INPUT" && document.activeElement?.tagName !== "TEXTAREA") {
        e.preventDefault();
        onOpenChange(true);
      }
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onOpenChange]);

  const total = results ? results.courses.length + results.tasks.length + results.notes.length + results.readings.length + results.exams.length : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl p-0 gap-0 overflow-hidden">
        <DialogHeader className="sr-only"><DialogTitle>Cari</DialogTitle></DialogHeader>
        <div className="flex items-center gap-2 px-4 border-b">
          <Search className="size-4 text-muted-foreground" />
          <input
            value={q}
            onChange={(e)=>setQ(e.target.value)}
            placeholder="Cari mata kuliah, tugas, catatan, bacaan, ujian..."
            className="flex-1 bg-transparent py-3.5 text-sm outline-none"
            autoFocus
          />
          {loading && <span className="text-xs text-muted-foreground">...</span>}
        </div>
        <div className="max-h-[60vh] overflow-y-auto scroll-area-thin">
          {!results || total === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              {q ? (loading ? "Mencari..." : "Tidak ada hasil.") : "Ketik untuk mencari di semua datamu."}
            </div>
          ) : (
            <div className="p-2">
              {results.courses.length > 0 && <Section title="Mata Kuliah" icon={GraduationCap}>{results.courses.map((c)=>(
                <ResultItem key={c.id} title={c.name} sub={c.code} onClick={()=>{ setActiveCourseId(c.id); setView("courses"); onOpenChange(false); }} />
              ))}</Section>}
              {results.tasks.length > 0 && <Section title="Tugas" icon={CheckSquare}>{results.tasks.map((t)=>(
                <ResultItem key={t.id} title={t.title} sub={[t.course?.name, t.dueAt && relativeTime(t.dueAt)].filter(Boolean).join(" · ")} onClick={()=>{ setActiveTaskId(t.id); setView("tasks"); onOpenChange(false); }} />
              ))}</Section>}
              {results.notes.length > 0 && <Section title="Catatan" icon={BookOpen}>{results.notes.map((n)=>(
                <ResultItem key={n.id} title={n.title} sub={[n.course?.name, relativeTime(n.updatedAt)].filter(Boolean).join(" · ")} onClick={()=>{ setActiveNoteId(n.id); setView("notes"); onOpenChange(false); }} />
              ))}</Section>}
              {results.readings.length > 0 && <Section title="Bacaan" icon={BookMarked}>{results.readings.map((r)=>(
                <ResultItem key={r.id} title={r.title} sub={r.author ?? undefined} onClick={()=>{ setView("readings"); onOpenChange(false); }} />
              ))}</Section>}
              {results.exams.length > 0 && <Section title="Ujian" icon={Library}>{results.exams.map((e)=>(
                <ResultItem key={e.id} title={e.name} sub={[e.course?.name, formatDateTime(e.examAt)].filter(Boolean).join(" · ")} onClick={()=>{ setView("exams"); onOpenChange(false); }} />
              ))}</Section>}
            </div>
          )}
        </div>
        <div className="border-t px-4 py-2 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>Pencarian lokal di datamu sendiri</span>
          <span className="flex items-center gap-1"><CornerDownLeft className="size-3" /> Enter</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: typeof Search; children: React.ReactNode }) {
  return (
    <div className="mb-1">
      <div className="px-2 py-1.5 text-[11px] font-semibold uppercase text-muted-foreground flex items-center gap-1.5"><Icon className="size-3" /> {title}</div>
      {children}
    </div>
  );
}

function ResultItem({ title, sub, onClick }: { title: string; sub?: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full text-left rounded-md px-2.5 py-2 hover:bg-accent transition flex items-center gap-2">
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium truncate">{title}</p>
        {sub && <p className="text-xs text-muted-foreground truncate">{sub}</p>}
      </div>
    </button>
  );
}
