#!/usr/bin/env node
/**
 * Set up QStash recurring scheduler for ForFH reminders.
 * Creates a single recurring schedule that calls /api/internal/reminders/process every 5 minutes.
 *
 * Usage: bun run scripts/setup-qstash.ts
 */
import { env, features } from "../src/lib/env";

async function setupQStash() {
  if (!features.qstash) {
    console.error("QStash not configured. Set QSTASH_URL, QSTASH_TOKEN, QSTASH_CURRENT_SIGNING_KEY in .env");
    process.exit(1);
  }

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const callbackUrl = `${appUrl}/api/internal/reminders/process`;

  console.log(`Setting up QStash scheduler...`);
  console.log(`  Callback: ${callbackUrl}`);
  console.log(`  Interval: every 5 minutes`);

  const res = await fetch(`${env.QSTASH_URL}/schedules`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.QSTASH_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      destination: callbackUrl,
      cron: "*/5 * * * *",
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    console.error(`Failed to create schedule: ${res.status} ${text}`);
    process.exit(1);
  }

  const data = await res.json();
  console.log(`QStash scheduler created! Schedule ID: ${data.scheduleId}`);
  console.log(`   Reminders will be processed every 5 minutes.`);
}

setupQStash().catch((e) => {
  console.error(e);
  process.exit(1);
});
