# Build Status

## Phase A — Foundation ✅
- [x] TypeScript + Tailwind + shadcn
- [x] Zod env validation (server) + browser-safe publicEnv
- [x] Prisma schema (all core tables)
- [x] Academic emerald theme, dark mode
- [x] Error handling (typed ApiError)

## Phase B — Auth ✅
- [x] scrypt + per-user salt + PASSWORD_PEPPER
- [x] Register / login / logout
- [x] Server sessions (token hash in DB, HttpOnly cookie)
- [x] Rate limiting (Turso/SQLite-backed)
- [x] Settings bootstrap on register
- [x] Multi-user isolation verified (sisca cannot read budi's course → 404)

## Phase C — Academic Core ✅
- [x] Academic terms (active/inactive)
- [x] Courses (code, lecturer, SKS, color, room, online url)
- [x] Weekly class schedules (day/time/room)
- [x] Next-class calculation (Jakarta timezone aware)

## Phase D — Task Core ✅
- [x] Tasks (title, type, priority, status, progress, deadline, est, source)
- [x] Subtasks (ordered, toggle, progress sync)
- [x] Dynamic OVERDUE derivation
- [x] Soft delete

## Phase E — Dashboard & Calendar ✅
- [x] Next class hero, today's classes, today's tasks, overdue, nearest deadlines
- [x] Week progress, upcoming exams, AI insight card
- [x] Calendar weekly grid + day agenda

## Phase F — Notes & Quick Capture & Search ✅
- [x] Markdown notes with autosave + preview + pin
- [x] Quick Capture dialog (text → AI → confirm → save)
- [x] Universal search (courses, tasks, notes, readings, exams) + `/` shortcut

## Phase G — AI ✅
- [x] Provider abstraction (lib/ai/provider.ts) — wired to z-ai-web-dev-sdk
- [x] generateText + generateJson (with JSON repair)
- [x] ai_usage tracking
- [x] Quick Capture parsing (structured)
- [x] Task breakdown
- [x] Smart deadline (planned sessions)
- [x] Today insight
- [x] Legal explanation (grounded on Pasal.id content)
- [x] Graceful "AI unavailable" — non-AI features unaffected

## Phase H — PWA ✅
- [x] manifest.webmanifest (name, icons, theme, standalone)
- [x] service worker (app-shell cache, network-first nav, SWR assets)
- [x] Icons (svg + 192/512 png)
- [x] Installable
- [ ] Web Push subscription + QStash reminder worker (architected, not wired — credentials present but push delivery needs VAPID subscription flow + worker endpoint)

## Phase I — Google Drive ⏳ (deferred)
- [ ] OAuth refresh, per-user folder, resumable upload
- Drive credentials present in env; integration not wired in V1 (file attachments shown as planned feature)

## Phase J — Offline ⏳ (partial)
- [x] App-shell SW cache
- [ ] IndexedDB entity cache + mutation outbox (Phase 2/3)

## Phase K — Legal ✅
- [x] Pasal.id proxy (search + detail), server-side token
- [x] Bookmarks
- [x] AI grounded explanation

## Phase L — Secondary Academic ✅
- [x] Reading tracker (progress, deadline)
- [x] Exams + topics (with progress)
- [x] Attendance (per-course stats, one-tap marking, history) ✅ NEW
- [x] Grades/IPK (components, weighted final, IPK calc, letter mapping) ✅ NEW

## Phase M — Statistics ✅ NEW
- [x] Stats dashboard (task status/priority breakdown, completion trend, AI usage)
- [x] 14-day completion trend bar chart
- [x] AI usage analytics (success rate, latency, by type)

## Styling Improvements (CRON-1) ✅
- [x] Dashboard redesigned: quick stat chips, hero CTA, 3-column grid, AI insight button
- [x] Sidebar: grouped nav, strong active state, left accent bar
- [x] Desktop top header with inline search + Quick Capture button
- [x] WCAG AA contrast fixes (darker urgency colors)
- [x] Calendar day-card centering fixed
- [x] Notes empty state improved
- [x] Keyboard shortcuts (/ for search, Cmd+C for capture)

## QA verified via agent-browser
- [x] Register → onboarding → dashboard
- [x] Quick Capture natural language → AI parse → save task → appears on dashboard
- [x] AI task breakdown → apply subtasks
- [x] Task detail sheet (all fields, subtasks, AI)
- [x] Logout → register second user → empty workspace → cannot access first user's data (404)
- [x] Dashboard renders "next class", today's classes, tasks, deadlines, exams
- [x] Attendance marking flow (mark Hadir → stats update to 100%) ✅ NEW
- [x] Grades view renders IPK card + course list ✅ NEW
- [x] Stats view renders trend chart + breakdowns ✅ NEW
