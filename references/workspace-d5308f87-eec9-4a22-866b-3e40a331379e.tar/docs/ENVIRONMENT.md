# Environment Variables

Copy `.env.example` to `.env` and fill in. **Never commit secret values.**

## Critical (app won't start without these)
- `DATABASE_URL` — Prisma SQLite path (e.g. `file:./db/custom.db`). Production target: Turso libSQL URL.
- `SESSION_SECRET` — ≥32 chars, random. Auto-generated if missing.
- `PASSWORD_PEPPER` — ≥32 chars, random, **different from SESSION_SECRET**. Auto-generated if missing.

## Browser-safe (NEXT_PUBLIC_)
- `NEXT_PUBLIC_APP_URL` — app origin
- `NEXT_PUBLIC_VAPID_PUBLIC_KEY` — Web Push VAPID public key (generated via `npx web-push generate-vapid-keys`)

## Turso (documented target — not used by Prisma sqlite datasource in dev)
- `TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`

## Groq (documented; AI currently uses z-ai-web-dev-sdk in this env)
- `GROQ_API_KEY_1`, `GROQ_API_KEY_2`, `GROQ_MODEL` (default `openai/gpt-oss-120b`)

## Ollama Cloud (documented fallback)
- `OLLAMA_API_KEY_1`, `OLLAMA_API_KEY_2`
- `OLLAMA_MODEL` (default `gpt-oss:120b-cloud`), `OLLAMA_LAST_RESORT_MODEL` (default `minimax-m3:cloud`)

## Pasal.id
- `PASAL_API_BASE_URL` (default `https://pasal.id/api/v1`)
- `PASAL_API_TOKEN`

## QStash
- `QSTASH_URL`, `QSTASH_TOKEN`
- `QSTASH_CURRENT_SIGNING_KEY`, `QSTASH_NEXT_SIGNING_KEY`

## Google Drive (centralized account)
- `GOOGLE_DRIVE_CLIENT_ID`, `GOOGLE_DRIVE_CLIENT_SECRET`, `GOOGLE_DRIVE_REFRESH_TOKEN`
- `GOOGLE_DRIVE_ROOT_FOLDER_ID` (auto-bootstrapped if empty)

## Web Push (VAPID)
- `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT` (default `mailto:admin@forfh.app`)

## Quota
- `DEFAULT_USER_STORAGE_QUOTA_MB` (default 200)

## Validation rules
- Only `NEXT_PUBLIC_*` vars are exposed to the browser.
- Missing critical vars → hard fail at startup.
- Missing optional integration vars → "not configured" state (feature degrades gracefully, app keeps working).
- `features` object (server) derives availability flags; client `env-features.ts` mirrors for UI hints.
