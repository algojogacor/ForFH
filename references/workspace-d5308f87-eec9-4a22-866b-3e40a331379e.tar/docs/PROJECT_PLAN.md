# Project Plan

ForFH — a personal College OS PWA for Indonesian university students.

## Phases (see BUILD_STATUS.md for detail)

- **Phase A — Foundation** ✅ env, prisma, theme, layout, errors
- **Phase B — Auth** ✅ register/login/logout, sessions, rate limit, isolation
- **Phase C — Academic core** ✅ terms, courses, weekly schedules, next-class
- **Phase D — Task core** ✅ tasks, subtasks, status/progress, priority, deadlines
- **Phase E — Dashboard & Calendar** ✅ "Sekarang aku harus ngapain?" + weekly grid
- **Phase F — Notes & Quick Capture & Search** ✅ markdown, AI capture, universal search
- **Phase G — AI** ✅ provider layer, quick capture, breakdown, smart deadline, insight, legal explain
- **Phase H — PWA** ✅ manifest, SW, icons, install (Web Push/QStash worker: architected, deferred)
- **Phase I — Google Drive** ⏳ deferred (credentials present, integration not wired)
- **Phase J — Offline** partial (app-shell cache done; IndexedDB outbox = future)
- **Phase K — Legal** ✅ Pasal.id search/detail + bookmarks + AI explain
- **Phase L — Secondary** ✅ readings, exams+topics (attendance/grades: schema ready, UI deferred)

## Guiding principles
1. Dashboard answers "what now?" with minimal cognitive load
2. Quick Capture: NL → AI → confirm → save in 2-3 interactions
3. AI is an enhancement — outage never breaks core features
4. Multi-user isolation enforced at the query layer
5. Single-route SPA (`/` only) — view switching via client state
6. Mobile-first, thumb-friendly, 44px targets, safe-area aware

## Acceptance test (verified)
1. ✅ Register (budi) → onboarding → dashboard
2. ✅ Course + schedule created → dashboard shows next class
3. ✅ Quick Capture "Senin depan tugas hukum pidana analisis putusan deadline jam 9 malam" → AI parses → user confirms → saved
4. ✅ AI task breakdown → 7 subtasks applied
5. ✅ Second user (sisca) registers → empty workspace → cannot access budi's data (404)

## Deferred (documented, not fake)
- Google Drive file storage (Phase I) — `files` table ready, upload UI not built
- Web Push delivery + QStash reminder worker (Phase H) — VAPID keys + QStash creds present, push subscription flow + `/api/internal/reminders/process` worker not wired
- IndexedDB offline outbox (Phase J) — SW app-shell cache done
- Attendance/Grades UI (Phase L) — schema ready
