# Database

## Current: Prisma + SQLite
`prisma/schema.prisma` defines the schema; `src/lib/db.ts` exports the Prisma client. Local file at `db/custom.db`.

## Production target: Turso / libSQL (Drizzle)
The spec targets Turso (libSQL) with Drizzle ORM. The schema is designed to port cleanly:
- No SQLite-specific types beyond what libSQL supports (all enums as `String` + Zod validation)
- No array columns (CSV strings for reminder offsets)
- `cuid()` IDs are client/server-safe
- All user-owned tables have `user_id` + indexes

To port: convert `schema.prisma` → Drizzle table definitions, swap `db.ts` to use `@libsql/client` + `drizzle-orm/libsql`. Credentials (`TURSO_DATABASE_URL`, `TURSO_AUTH_TOKEN`) are already in `.env`.

## Tables
- **users** — id, username, usernameNormalized (unique), passwordHash, displayName
- **sessions** — tokenHash (unique), userId, expiresAt, lastSeenAt
- **userSettings** — userId (unique), timezone, locale, theme, reminder offsets (CSV), aiEnabled
- **academicTerms** — name, startDate, endDate, isActive
- **courses** — name, code, lecturer, sks, color, defaultRoom, onlineUrl, archived
- **classSchedules** — dayOfWeek, startTime, endTime, room, onlineUrl, enabled (weekly recurring)
- **tasks** — title, type, dueAt, internalTargetAt, priority, status, progress, source, soft delete + version
- **subtasks** — title, completed, orderIndex, soft delete + version
- **taskReminders** — offsetMinutes, enabled
- **notes** — title, content (markdown), pinned, soft delete + version
- **readings** — type, title, author, pages, status, deadline
- **exams** — name, type (UTS/UAS/QUIZ/OTHER), examAt, location + **examTopics**
- **attendance** — classDate, status (PRESENT/PERMIT/SICK/ABSENT), unique per course/date
- **grades** — componentName, weight, score, letterGrade, gradePoint (configurable mapping)
- **files** — Google Drive metadata only (driveFileId, name, mimeType, sizeBytes, category)
- **pushSubscriptions** — endpoint (unique), p256dh, auth
- **notificationDeliveries** — dedupe (unique on userId+entity+occurrence+offset+channel)
- **legalBookmarks** — frbrUri, title, type, number, year (no law mirroring)
- **aiUsage** — provider, accountSlot, model, requestType, status, tokens, latency (no prompts)
- **authRateLimit** — keyHash, windowStart, attemptCount, blockedUntil
- **appConfig** — key/value (e.g. googleDriveRootFolderId)

## Authorization pattern
Every query that reads user-owned data uses `findFirst({ where: { id, userId: user.id } })` (or `findMany({ where: { userId } })`). This guarantees cross-user access returns `null`/404, verified in QA.

## Indexes
Created on: users.usernameNormalized, sessions.tokenHash/expiresAt, courses.userId, classSchedules(dayOfWeek, courseId), tasks(userId, dueAt, status), subtasks.taskId, notes(userId, updatedAt), exams.examAt, files.userId, aiUsage(provider, createdAt), notificationDeliveries (unique dedupe).
