# Architecture

## Routing
Single user-visible route `/` (per environment constraint). `src/app/page.tsx` is a server component:
- Reads session via `getCurrentUser()` (cached per-request)
- Renders `<AppRoot initialUser={user}>` (client)

`<AppRoot>` (client):
- If no user → `<AuthScreen>` (login/register tabs)
- If user → `<AppShell>` + `<OnboardingDialog>` (if `needsOnboarding`)

`<AppShell>`:
- Desktop: fixed left sidebar (Beranda, Kalender, Tugas, Mata Kuliah, Catatan, Bacaan, Ujian, Hukum, Pengaturan) + user menu + search + Quick Capture FAB
- Mobile: top bar (sheet menu) + bottom nav (Beranda, Kalender, +, Tugas, Catatan) + FAB
- View switching via Zustand `useApp().view`

## Data flow
- **Server state**: TanStack Query (`useQuery`/`useMutation`) keyed via `apiKeys`
- **UI state**: Zustand `useApp` (active view, active task/note/course IDs, dialog open states)
- **API**: all `/api/*` route handlers; `fetchApi` helper handles JSON + 401 global event

## Key libraries
- `src/lib/db.ts` — Prisma client (singleton via global)
- `src/lib/env.ts` — Zod server env validation + `features` flags
- `src/lib/crypto.ts` — scrypt password hash, session token gen/hash, username normalize
- `src/lib/session.ts` — `getCurrentUser` (cached), `createSession`, `destroySession`
- `src/lib/rate-limit.ts` — Turso/SQLite-backed auth rate limiter
- `src/lib/date.ts` — Jakarta-timezone-aware date helpers, weekly occurrence calc
- `src/lib/ai/provider.ts` — AI abstraction (z-ai-web-dev-sdk)
- `src/lib/api.ts` — `apiError`/`apiOk`/`parseZod`/`handleApiError`

## Theming
- `next-themes` (attribute="class", defaultTheme="system")
- Academic emerald palette in `globals.css` (`:root` light + `.dark`)
- Urgency semantic colors: `--urgent`, `--high`, `--medium`, `--low`, `--success`

## PWA
- `public/manifest.webmanifest` — standalone, theme color, icons, shortcuts
- `public/sw.js` — app-shell cache, network-first navigation, stale-while-revalidate assets, API calls bypass cache
- `src/components/sw-register.tsx` — registers SW (prod / preview hosts)

## Security boundaries
- All mutations require authenticated session (derived `user.id`)
- All reads scoped by `userId`
- AI output validated with Zod before persisting
- Rate limiting on login/register/AI endpoints
- Secrets only in server env; `NEXT_PUBLIC_*` limited to VAPID public key + app URL
