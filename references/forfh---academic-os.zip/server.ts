import express from 'express';
import path from 'node:path';
import dotenv from 'dotenv';
dotenv.config();

import { initDatabase } from './src/db/init';
import { authenticateUser, authRouter } from './src/server/authRoutes';
import { academicRouter } from './src/server/academicRoutes';
import { taskRouter } from './src/server/taskRoutes';
import { noteRouter } from './src/server/noteRoutes';
import { aiRouter } from './src/server/aiRoutes';
import { pasalRouter } from './src/server/pasalRoutes';
import { fileRouter } from './src/server/fileRoutes';
import { pushRouter } from './src/server/pushRoutes';
import { secondaryRouter } from './src/server/secondaryRoutes';

async function startServer() {
  // Ensure database tables exist in Turso
  await initDatabase().catch((err) => {
    console.error('[DB] Initializer error:', err);
  });

  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Extract Session User on all incoming requests
  app.use(authenticateUser);

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'ForFH Academic OS',
      timestamp: new Date().toISOString(),
    });
  });

  app.use('/api/auth', authRouter);
  app.use('/api', academicRouter);
  app.use('/api', taskRouter);
  app.use('/api', noteRouter);
  app.use('/api', aiRouter);
  app.use('/api', pasalRouter);
  app.use('/api', fileRouter);
  app.use('/api', pushRouter);
  app.use('/api', secondaryRouter);

  // Vite Middleware for Development vs Static Serving in Production
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] ForFH Academic OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
