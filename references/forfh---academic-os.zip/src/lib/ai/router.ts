import { db } from '../../db/client';
import { aiUsage } from '../../db/schema';
import crypto from 'node:crypto';

export interface AISlot {
  provider: 'groq' | 'ollama';
  slot: 1 | 2;
  apiKey: string;
  model: string;
  status: 'HEALTHY' | 'COOLDOWN';
  cooldownUntil?: number;
}

const groqModel = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const ollamaModel = process.env.OLLAMA_MODEL || 'gpt-oss:120b-cloud';
const lastResortModel = process.env.OLLAMA_LAST_RESORT_MODEL || 'minimax-m3';

// Managed slots
const slots: AISlot[] = [
  {
    provider: 'groq',
    slot: 1,
    apiKey: process.env.GROQ_API_KEY_1 || '',
    model: groqModel,
    status: 'HEALTHY',
  },
  {
    provider: 'groq',
    slot: 2,
    apiKey: process.env.GROQ_API_KEY_2 || '',
    model: groqModel,
    status: 'HEALTHY',
  },
  {
    provider: 'ollama',
    slot: 1,
    apiKey: process.env.OLLAMA_API_KEY_1 || '',
    model: ollamaModel,
    status: 'HEALTHY',
  },
  {
    provider: 'ollama',
    slot: 2,
    apiKey: process.env.OLLAMA_API_KEY_2 || '',
    model: ollamaModel,
    status: 'HEALTHY',
  },
];

let roundRobinIndex = 0;

export async function executeAIRequest(
  userId: string | null,
  requestType: string,
  systemPrompt: string,
  userPrompt: string,
  jsonSchemaHint?: boolean
): Promise<{ text: string; provider: string; model: string } | null> {
  const now = Date.now();

  // Filter slots with valid API keys
  const availableSlots = slots.filter((s) => s.apiKey && (s.status === 'HEALTHY' || (s.cooldownUntil && s.cooldownUntil <= now)));

  // Try Groq slots first
  const groqSlots = availableSlots.filter((s) => s.provider === 'groq');
  // Try Ollama slots second
  const ollamaSlots = availableSlots.filter((s) => s.provider === 'ollama');

  const orderedSlots = [...groqSlots, ...ollamaSlots];

  if (orderedSlots.length === 0) {
    console.warn('[AI Router] No configured AI slots available.');
    return null;
  }

  // Rotate starting index for load balancing
  const startIndex = roundRobinIndex % orderedSlots.length;
  roundRobinIndex++;

  const attempts = [
    ...orderedSlots.slice(startIndex),
    ...orderedSlots.slice(0, startIndex),
  ];

  for (const slotCandidate of attempts) {
    const startTime = Date.now();
    try {
      let resultText = '';

      if (slotCandidate.provider === 'groq') {
        const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${slotCandidate.apiKey}`,
          },
          body: JSON.stringify({
            model: slotCandidate.model,
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userPrompt },
            ],
            response_format: jsonSchemaHint ? { type: 'json_object' } : undefined,
            temperature: 0.3,
          }),
        });

        if (res.status === 429 || res.status >= 500) {
          slotCandidate.status = 'COOLDOWN';
          slotCandidate.cooldownUntil = Date.now() + 60 * 1000; // 1 min cooldown
          throw new Error(`Groq HTTP ${res.status}`);
        }

        if (!res.ok) {
          const errBody = await res.text();
          throw new Error(`Groq HTTP ${res.status}: ${errBody}`);
        }

        const data = await res.json();
        resultText = data.choices?.[0]?.message?.content || '';
      } else if (slotCandidate.provider === 'ollama') {
        // Direct Ollama Cloud API endpoint
        const res = await fetch('https://ollama.com/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${slotCandidate.apiKey}`,
          },
          body: JSON.stringify({
            model: slotCandidate.model,
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: userPrompt },
            ],
            stream: false,
          }),
        });

        if (!res.ok) {
          // Try last resort model
          const fallbackRes = await fetch('https://ollama.com/api/chat', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${slotCandidate.apiKey}`,
            },
            body: JSON.stringify({
              model: lastResortModel,
              messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt },
              ],
              stream: false,
            }),
          });

          if (!fallbackRes.ok) {
            slotCandidate.status = 'COOLDOWN';
            slotCandidate.cooldownUntil = Date.now() + 60 * 1000;
            throw new Error(`Ollama Cloud HTTP ${res.status}`);
          }

          const fallbackData = await fallbackRes.json();
          resultText = fallbackData.message?.content || '';
        } else {
          const data = await res.json();
          resultText = data.message?.content || '';
        }
      }

      const latencyMs = Date.now() - startTime;
      slotCandidate.status = 'HEALTHY';

      // Record AI usage
      db.insert(aiUsage)
        .values({
          id: crypto.randomUUID(),
          userId,
          provider: slotCandidate.provider,
          accountSlot: slotCandidate.slot,
          model: slotCandidate.model,
          requestType,
          status: 'success',
          httpStatus: 200,
          latencyMs,
          createdAt: Date.now(),
        })
        .catch(() => {});

      return {
        text: resultText,
        provider: slotCandidate.provider,
        model: slotCandidate.model,
      };
    } catch (err: any) {
      console.warn(`[AI Router] Candidate ${slotCandidate.provider} slot ${slotCandidate.slot} failed: ${err.message}`);
      db.insert(aiUsage)
        .values({
          id: crypto.randomUUID(),
          userId,
          provider: slotCandidate.provider,
          accountSlot: slotCandidate.slot,
          model: slotCandidate.model,
          requestType,
          status: 'failure',
          errorClass: err.message,
          createdAt: Date.now(),
        })
        .catch(() => {});
    }
  }

  return null;
}

export function cleanJsonOutput(raw: string): string {
  let cleaned = raw.trim();
  // Strip markdown ```json ... ``` fences
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim();
  }
  return cleaned;
}
