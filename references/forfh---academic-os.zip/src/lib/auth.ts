import crypto from 'node:crypto';
import { db } from '../db/client';
import { users, sessions, userSettings, academicTerms } from '../db/schema';
import { eq, and, gt } from 'drizzle-orm';

const PEPPER = process.env.PASSWORD_PEPPER || 'forfh-default-pepper-2026';
const SESSION_SECRET = process.env.SESSION_SECRET || 'forfh-session-secret-2026';

// Scrypt password hashing
export function hashPassword(password: string, saltHex?: string): { hash: string; salt: string } {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const saltedPepperedPassword = password + PEPPER;
  const hashBuffer = crypto.scryptSync(saltedPepperedPassword, salt, 64);
  return {
    hash: hashBuffer.toString('hex'),
    salt: salt.toString('hex'),
  };
}

export function verifyPassword(password: string, storedHashHex: string, saltHex: string): boolean {
  try {
    const { hash } = hashPassword(password, saltHex);
    const hashBuf = Buffer.from(hash, 'hex');
    const storedBuf = Buffer.from(storedHashHex, 'hex');
    if (hashBuf.length !== storedBuf.length) return false;
    return crypto.timingSafeEqual(hashBuf, storedBuf);
  } catch {
    return false;
  }
}

// Token SHA-256 hashing
export function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token + SESSION_SECRET).digest('hex');
}

// Session Creation
export async function createSession(userId: string) {
  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashToken(rawToken);
  const now = Date.now();
  const expiresAt = now + 30 * 24 * 60 * 60 * 1000; // 30 days

  const sessionId = crypto.randomUUID();
  await db.insert(sessions).values({
    id: sessionId,
    userId,
    tokenHash,
    createdAt: now,
    expiresAt,
    lastSeenAt: now,
  });

  return { rawToken, expiresAt };
}

// Session Verification & Resolution
export async function getSessionUser(rawToken: string | undefined) {
  if (!rawToken) return null;

  const tokenHash = hashToken(rawToken);
  const now = Date.now();

  const [session] = await db
    .select({
      sessionId: sessions.id,
      userId: sessions.userId,
      expiresAt: sessions.expiresAt,
      username: users.username,
      displayName: users.displayName,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, tokenHash), gt(sessions.expiresAt, now)));

  if (!session) return null;

  // Touch lastSeenAt asynchronously
  db.update(sessions)
    .set({ lastSeenAt: now })
    .where(eq(sessions.id, session.sessionId))
    .catch(() => {});

  return {
    userId: session.userId,
    username: session.username,
    displayName: session.displayName || session.username,
    sessionId: session.sessionId,
  };
}

// Revoke Session
export async function destroySession(rawToken: string) {
  if (!rawToken) return;
  const tokenHash = hashToken(rawToken);
  await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash));
}
