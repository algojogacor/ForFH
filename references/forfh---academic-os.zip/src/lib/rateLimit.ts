import crypto from 'node:crypto';
import { db } from '../db/client';
import { authRateLimits } from '../db/schema';
import { eq } from 'drizzle-orm';

export async function checkRateLimit(key: string, maxAttempts = 5, windowMs = 15 * 60 * 1000): Promise<{ allowed: boolean; retryAfterMs?: number }> {
  const keyHash = crypto.createHash('sha256').update(key).digest('hex');
  const now = Date.now();

  const [record] = await db.select().from(authRateLimits).where(eq(authRateLimits.keyHash, keyHash));

  if (record) {
    if (record.blockedUntil && record.blockedUntil > now) {
      return { allowed: false, retryAfterMs: record.blockedUntil - now };
    }

    if (now - record.windowStart > windowMs) {
      // Reset window
      await db.update(authRateLimits).set({
        windowStart: now,
        attemptCount: 1,
        blockedUntil: null,
      }).where(eq(authRateLimits.keyHash, keyHash));
      return { allowed: true };
    }

    if (record.attemptCount >= maxAttempts) {
      const blockedUntil = now + windowMs;
      await db.update(authRateLimits).set({
        blockedUntil,
      }).where(eq(authRateLimits.keyHash, keyHash));
      return { allowed: false, retryAfterMs: windowMs };
    }

    await db.update(authRateLimits).set({
      attemptCount: record.attemptCount + 1,
    }).where(eq(authRateLimits.keyHash, keyHash));
    return { allowed: true };
  } else {
    await db.insert(authRateLimits).values({
      keyHash,
      windowStart: now,
      attemptCount: 1,
      blockedUntil: null,
    });
    return { allowed: true };
  }
}

export async function clearRateLimit(key: string) {
  const keyHash = crypto.createHash('sha256').update(key).digest('hex');
  await db.delete(authRateLimits).where(eq(authRateLimits.keyHash, keyHash)).catch(() => {});
}
