import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { AuthModal } from './components/AuthModal';
import { QuickCaptureModal } from './components/QuickCaptureModal';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { TaskView } from './components/TaskView';
import { ScheduleView } from './components/ScheduleView';
import { NotesView } from './components/NotesView';
import { PasalView } from './components/PasalView';
import { SecondaryViews } from './components/SecondaryViews';
import { SettingsView } from './components/SettingsView';
import { Task, Course, ClassSchedule, Note, AcademicTerm } from './types';

export function App() {
  const { isAuthenticated, loading } = useAuth();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [isQuickCaptureOpen, setIsQuickCaptureOpen] = useState(false);

  // App Global State
  const [tasks, setTasks] = useState<Task[]>([]);
  const [schedules, setSchedules] = useState<ClassSchedule[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [terms, setTerms] = useState<AcademicTerm[]>([]);

  // Fetch All App Data
  const fetchAllData = async () => {
    if (!isAuthenticated) return;

    try {
      const [tasksRes, schedRes, courseRes, noteRes, termRes] = await Promise.all([
        fetch('/api/tasks'),
        fetch('/api/schedules'),
        fetch('/api/courses'),
        fetch('/api/notes'),
        fetch('/api/terms'),
      ]);

      if (tasksRes.ok) setTasks(await tasksRes.json());
      if (schedRes.ok) setSchedules(await schedRes.json());
      if (courseRes.ok) setCourses(await courseRes.json());
      if (noteRes.ok) setNotes(await noteRes.json());
      if (termRes.ok) setTerms(await termRes.json());
    } catch (e) {
      console.error('Error fetching app data:', e);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchAllData();
    }
  }, [isAuthenticated]);

  // Task Status Toggle Helper
  const handleTaskStatusToggle = async (taskId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'DONE' ? 'NOT_STARTED' : 'DONE';
    const nextProgress = nextStatus === 'DONE' ? 100 : 0;

    await fetch(`/api/tasks/${taskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus, progress: nextProgress }),
    });

    fetchAllData();
  };

  // Loading Screen
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center text-slate-500 text-sm">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="font-semibold text-xs tracking-wider">MEMUAT FORFH ACADEMIC OS...</p>
        </div>
      </div>
    );
  }

  // Unauthenticated -> Show AuthModal
  if (!isAuthenticated) {
    return <AuthModal />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
        onOpenSettings={() => setActiveTab('settings')}
      />

      {/* Main Content Surface */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            tasks={tasks}
            schedules={schedules}
            courses={courses}
            onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
            onNavigateTab={setActiveTab}
            onTaskStatusToggle={handleTaskStatusToggle}
          />
        )}

        {activeTab === 'tasks' && (
          <TaskView
            tasks={tasks}
            courses={courses}
            onRefreshTasks={fetchAllData}
            onOpenQuickCapture={() => setIsQuickCaptureOpen(true)}
          />
        )}

        {activeTab === 'schedules' && (
          <ScheduleView
            terms={terms}
            courses={courses}
            schedules={schedules}
            onRefreshData={fetchAllData}
          />
        )}

        {activeTab === 'notes' && (
          <NotesView
            notes={notes}
            courses={courses}
            onRefreshNotes={fetchAllData}
          />
        )}

        {activeTab === 'pasal' && <PasalView />}

        {activeTab === 'secondary' && <SecondaryViews courses={courses} />}

        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Quick Capture AI Modal */}
      <QuickCaptureModal
        isOpen={isQuickCaptureOpen}
        onClose={() => setIsQuickCaptureOpen(false)}
        courses={courses}
        onTaskCreated={fetchAllData}
      />
    </div>
  );
}

export default App;
