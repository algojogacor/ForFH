import React, { useState } from 'react';
import { Task, Course, Subtask } from '../types';
import {
  Plus,
  CheckCircle2,
  Clock,
  Sparkles,
  AlertTriangle,
  ChevronRight,
  Search,
  Filter,
  X,
  Trash2,
  Calendar,
  ListTodo
} from 'lucide-react';

interface TaskViewProps {
  tasks: Task[];
  courses: Course[];
  onRefreshTasks: () => void;
  onOpenQuickCapture: () => void;
}

export const TaskView: React.FC<TaskViewProps> = ({
  tasks,
  courses,
  onRefreshTasks,
  onOpenQuickCapture,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterCourse, setFilterCourse] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected Task Detail Modal State
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // New Task Form Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCourseId, setNewCourseId] = useState('');
  const [newType, setNewType] = useState('assignment');
  const [newDueAt, setNewDueAt] = useState('');
  const [newPriority, setNewPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [newEstimatedMinutes, setNewEstimatedMinutes] = useState('60');
  const [newDescription, setNewDescription] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // AI Actions State
  const [isGeneratingBreakdown, setIsGeneratingBreakdown] = useState(false);
  const [isGeneratingSmartDeadline, setIsGeneratingSmartDeadline] = useState(false);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  const nowTimestamp = Date.now();

  // Filter Logic
  const filteredTasks = tasks.filter((t) => {
    if (filterStatus === 'NOT_STARTED' && t.status !== 'NOT_STARTED') return false;
    if (filterStatus === 'IN_PROGRESS' && t.status !== 'IN_PROGRESS') return false;
    if (filterStatus === 'DONE' && t.status !== 'DONE') return false;
    if (filterStatus === 'OVERDUE' && (t.status === 'DONE' || !t.dueAt || t.dueAt >= nowTimestamp)) return false;

    if (filterCourse !== 'ALL' && t.courseId !== filterCourse) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return t.title.toLowerCase().includes(q) || (t.description && t.description.toLowerCase().includes(q));
    }

    return true;
  });

  // Handle Create Task
  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    setIsCreating(true);

    try {
      const dueTimestamp = newDueAt ? new Date(newDueAt).getTime() : null;

      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle.trim(),
          courseId: newCourseId || null,
          type: newType,
          dueAt: dueTimestamp,
          priority: newPriority,
          estimatedMinutes: Number(newEstimatedMinutes) || 60,
          description: newDescription.trim() || null,
        }),
      });

      if (res.ok) {
        setNewTitle('');
        setNewDescription('');
        setIsAddModalOpen(false);
        onRefreshTasks();
      }
    } catch (e) {
      console.error('Gagal membuat tugas', e);
    } finally {
      setIsCreating(false);
    }
  };

  // Toggle Task Status
  const handleToggleStatus = async (task: Task) => {
    const nextStatus = task.status === 'DONE' ? 'NOT_STARTED' : 'DONE';
    const nextProgress = nextStatus === 'DONE' ? 100 : 0;

    await fetch(`/api/tasks/${task.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus, progress: nextProgress }),
    });

    onRefreshTasks();
    if (selectedTask?.id === task.id) {
      setSelectedTask({ ...selectedTask, status: nextStatus as any, progress: nextProgress });
    }
  };

  // Delete Task
  const handleDeleteTask = async (taskId: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus tugas ini?')) return;
    await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
    setSelectedTask(null);
    onRefreshTasks();
  };

  // Add Subtask Manual
  const handleAddSubtask = async () => {
    if (!selectedTask || !newSubtaskTitle.trim()) return;

    const res = await fetch(`/api/tasks/${selectedTask.id}/subtasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: newSubtaskTitle.trim() }),
    });

    if (res.ok) {
      const added = await res.json();
      const updatedSubtasks = [...(selectedTask.subtasks || []), added];
      setSelectedTask({ ...selectedTask, subtasks: updatedSubtasks });
      setNewSubtaskTitle('');
      onRefreshTasks();
    }
  };

  // Toggle Subtask
  const handleToggleSubtask = async (subtaskId: string, currentCompleted: boolean) => {
    if (!selectedTask) return;

    const res = await fetch(`/api/subtasks/${subtaskId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !currentCompleted }),
    });

    if (res.ok) {
      const updatedSt = await res.json();
      const updatedSubtasks = (selectedTask.subtasks || []).map((s) => s.id === subtaskId ? updatedSt : s);
      setSelectedTask({ ...selectedTask, subtasks: updatedSubtasks });
      onRefreshTasks();
    }
  };

  // AI Task Breakdown Action
  const handleAiBreakdown = async () => {
    if (!selectedTask) return;
    setIsGeneratingBreakdown(true);

    try {
      const res = await fetch('/api/ai/task-breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: selectedTask.title,
          description: selectedTask.description,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data.subtasks)) {
          for (const st of data.subtasks) {
            await fetch(`/api/tasks/${selectedTask.id}/subtasks`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ title: st.title }),
            });
          }
          onRefreshTasks();
          // Reload task detail
          const freshRes = await fetch('/api/tasks');
          const allFresh = await freshRes.json();
          const refreshedTask = allFresh.find((t: Task) => t.id === selectedTask.id);
          if (refreshedTask) setSelectedTask(refreshedTask);
        }
      }
    } catch (e) {
      console.error('Breakdown AI error:', e);
    } finally {
      setIsGeneratingBreakdown(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Manajemen Tugas</h1>
          <p className="text-xs text-slate-500">Pantau dan selesaikan semua penugasan akademikmu</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenQuickCapture}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition"
          >
            <Sparkles className="h-4 w-4 text-blue-600" /> Quick Capture
          </button>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition"
          >
            <Plus className="h-4 w-4" /> Buat Tugas
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex flex-wrap gap-1">
            {[
              { id: 'ALL', label: 'Semua' },
              { id: 'NOT_STARTED', label: 'Belum Mulai' },
              { id: 'IN_PROGRESS', label: 'Berlangsung' },
              { id: 'OVERDUE', label: 'Terlewat' },
              { id: 'DONE', label: 'Selesai' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterStatus(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                  filterStatus === tab.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama tugas..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Filter Course Dropdown */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Filter className="h-3.5 w-3.5 text-slate-400" />
          <span className="text-xs text-slate-500 font-medium">Mata Kuliah:</span>
          <select
            value={filterCourse}
            onChange={(e) => setFilterCourse(e.target.value)}
            className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
          >
            <option value="ALL">Semua Mata Kuliah</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Task List Grid */}
      <div className="space-y-3">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 space-y-2">
            <ListTodo className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700" />
            <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Tidak ada tugas ditemukan</p>
            <p className="text-xs">Ubah kata kunci pencarian atau buat tugas baru.</p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const isOverdue = task.dueAt && task.dueAt < nowTimestamp && task.status !== 'DONE';
            const dueStr = task.dueAt
              ? new Date(task.dueAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
              : 'Tanpa Tanggal';

            return (
              <div
                key={task.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 hover:border-blue-300 dark:hover:border-blue-800 transition shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                onClick={() => setSelectedTask(task)}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleStatus(task);
                    }}
                    className={`mt-0.5 transition ${
                      task.status === 'DONE' ? 'text-emerald-600' : 'text-slate-300 hover:text-emerald-600'
                    }`}
                  >
                    <CheckCircle2 className="h-5 w-5" />
                  </button>

                  <div className="min-w-0 space-y-1">
                    <h3 className={`text-sm font-bold text-slate-900 dark:text-white truncate ${task.status === 'DONE' ? 'line-through text-slate-400' : ''}`}>
                      {task.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      {task.courseName && (
                        <span className="px-2 py-0.5 rounded-md font-semibold text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {task.courseName}
                        </span>
                      )}
                      <span className={`flex items-center gap-1 ${isOverdue ? 'text-red-600 font-bold' : 'text-slate-500'}`}>
                        <Clock className="h-3 w-3" /> {dueStr}
                      </span>
                      {task.subtasks && task.subtasks.length > 0 && (
                        <span className="text-[10px] text-slate-400">
                          Subtask: {task.subtasks.filter((s) => s.completed).length}/{task.subtasks.length}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                  <span
                    className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-full ${
                      task.priority === 'urgent'
                        ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                        : task.priority === 'high'
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {task.priority}
                  </span>
                  <ChevronRight className="h-4 w-4 text-slate-400" />
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Task Detail & Subtasks Modal */}
      {selectedTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 my-8 space-y-5">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                  {selectedTask.courseName || 'Tugas Akademik'}
                </span>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">{selectedTask.title}</h2>
              </div>
              <button onClick={() => setSelectedTask(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            {selectedTask.description && (
              <p className="text-sm text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                {selectedTask.description}
              </p>
            )}

            {/* Subtasks Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Subtask & Pengerjaan ({selectedTask.subtasks?.filter((s) => s.completed).length || 0}/{selectedTask.subtasks?.length || 0})
                </h3>
                <button
                  type="button"
                  onClick={handleAiBreakdown}
                  disabled={isGeneratingBreakdown}
                  className="text-xs text-blue-600 font-semibold flex items-center gap-1 hover:underline"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  {isGeneratingBreakdown ? 'Menyusun Subtask AI...' : 'Breakdown AI'}
                </button>
              </div>

              {/* Subtask Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newSubtaskTitle}
                  onChange={(e) => setNewSubtaskTitle(e.target.value)}
                  placeholder="Tambah langkah pekerjaan..."
                  className="flex-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
                <button
                  type="button"
                  onClick={handleAddSubtask}
                  className="px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-semibold hover:bg-blue-700"
                >
                  Tambah
                </button>
              </div>

              {/* Subtasks List */}
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {selectedTask.subtasks?.map((st) => (
                  <div
                    key={st.id}
                    className="flex items-center gap-2 p-2 rounded-lg border border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-xs"
                  >
                    <input
                      type="checkbox"
                      checked={st.completed}
                      onChange={() => handleToggleSubtask(st.id, st.completed)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <span className={`flex-1 ${st.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}`}>
                      {st.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => handleDeleteTask(selectedTask.id)}
                className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
              >
                <Trash2 className="h-4 w-4" /> Hapus Tugas
              </button>

              <button
                onClick={() => setSelectedTask(null)}
                className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-xs font-bold"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Add Task Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Buat Tugas Baru</h2>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 rounded-lg text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Judul Tugas *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Misal: Analisis Putusan Mahkamah Agung"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Mata Kuliah</label>
                  <select
                    value={newCourseId}
                    onChange={(e) => setNewCourseId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="">- Tidak Terikat -</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Prioritas</label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  >
                    <option value="low">Rendah</option>
                    <option value="medium">Sedang</option>
                    <option value="high">Tinggi</option>
                    <option value="urgent">Mendesak</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Tanggal Deadline</label>
                <input
                  type="datetime-local"
                  value={newDueAt}
                  onChange={(e) => setNewDueAt(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">Catatan Tambahan</label>
                <textarea
                  rows={2}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Detail instruksi dosen..."
                  className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-300"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isCreating}
                  className="px-4 py-2 bg-blue-600 text-white text-xs font-semibold rounded-xl hover:bg-blue-700 transition"
                >
                  {isCreating ? 'Menyimpan...' : 'Simpan Tugas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
