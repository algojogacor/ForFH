import React, { useState } from 'react';
import { Course, ClassSchedule, AcademicTerm } from '../types';
import {
  Plus,
  Calendar,
  BookOpen,
  MapPin,
  Clock,
  ExternalLink,
  Trash2,
  X,
  User,
  CheckCircle,
  Tag
} from 'lucide-react';

interface ScheduleViewProps {
  terms: AcademicTerm[];
  courses: Course[];
  schedules: ClassSchedule[];
  onRefreshData: () => void;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  terms,
  courses,
  schedules,
  onRefreshData,
}) => {
  const [activeTab, setActiveTab] = useState<'TIMETABLE' | 'COURSES' | 'TERMS'>('TIMETABLE');

  // Modals state
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isTermModalOpen, setIsTermModalOpen] = useState(false);

  // New Course Form State
  const [courseName, setCourseName] = useState('');
  const [courseCode, setCourseCode] = useState('');
  const [courseLecturer, setCourseLecturer] = useState('');
  const [courseCredits, setCourseCredits] = useState('3');
  const [courseColor, setCourseColor] = useState('#2563eb');
  const [courseRoom, setCourseRoom] = useState('');
  const [courseUrl, setCourseUrl] = useState('');

  // New Schedule Form State
  const [selectedCourseId, setSelectedCourseId] = useState('');
  const [scheduleDay, setScheduleDay] = useState('1'); // 1 = Senin
  const [startTime, setStartTime] = useState('08:00');
  const [endTime, setEndTime] = useState('10:30');
  const [scheduleRoom, setScheduleRoom] = useState('');

  // New Term Form State
  const [termName, setTermName] = useState('');
  const [termStartDate, setTermStartDate] = useState('');
  const [termEndDate, setTermEndDate] = useState('');

  const dayLabels = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

  // Handle Save Course
  const handleSaveCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseName.trim()) return;

    await fetch('/api/courses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: courseName.trim(),
        code: courseCode.trim() || null,
        lecturer: courseLecturer.trim() || null,
        credits: Number(courseCredits) || 3,
        color: courseColor,
        defaultRoom: courseRoom.trim() || null,
        onlineUrl: courseUrl.trim() || null,
      }),
    });

    setCourseName('');
    setCourseCode('');
    setCourseLecturer('');
    setIsCourseModalOpen(false);
    onRefreshData();
  };

  // Handle Save Schedule
  const handleSaveSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCourseId) return;

    await fetch('/api/schedules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        courseId: selectedCourseId,
        dayOfWeek: Number(scheduleDay),
        startTime,
        endTime,
        room: scheduleRoom.trim() || null,
      }),
    });

    setIsScheduleModalOpen(false);
    onRefreshData();
  };

  // Handle Delete Schedule
  const handleDeleteSchedule = async (id: string) => {
    if (!confirm('Hapus jadwal perkuliahan ini?')) return;
    await fetch(`/api/schedules/${id}`, { method: 'DELETE' });
    onRefreshData();
  };

  // Handle Delete Course
  const handleDeleteCourse = async (id: string) => {
    if (!confirm('Hapus mata kuliah ini? Semua jadwal terkait akan dihapus.')) return;
    await fetch(`/api/courses/${id}`, { method: 'DELETE' });
    onRefreshData();
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Section Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Jadwal & Mata Kuliah</h1>
          <p className="text-xs text-slate-500">Kelola kurikulum semester, mata kuliah, dan matriks jadwal mingguan</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsCourseModalOpen(true)}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition"
          >
            <BookOpen className="h-4 w-4 text-blue-600" /> + Mata Kuliah
          </button>
          <button
            onClick={() => setIsScheduleModalOpen(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition"
          >
            <Plus className="h-4 w-4" /> + Jadwal Kuliah
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4">
        <button
          onClick={() => setActiveTab('TIMETABLE')}
          className={`pb-3 text-xs font-bold transition border-b-2 ${
            activeTab === 'TIMETABLE'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Matriks Jadwal Mingguan
        </button>
        <button
          onClick={() => setActiveTab('COURSES')}
          className={`pb-3 text-xs font-bold transition border-b-2 ${
            activeTab === 'COURSES'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          Daftar Mata Kuliah ({courses.length})
        </button>
      </div>

      {/* VIEW 1: TIMETABLE MATRIX */}
      {activeTab === 'TIMETABLE' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {[1, 2, 3, 4, 5].map((dayNum) => {
              const daySchedules = schedules
                .filter((s) => s.dayOfWeek === dayNum)
                .sort((a, b) => a.startTime.localeCompare(b.startTime));

              return (
                <div key={dayNum} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3 min-h-[220px]">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white">
                      {dayLabels[dayNum]}
                    </h3>
                    <span className="text-[10px] text-slate-400 font-semibold">{daySchedules.length} Kuliah</span>
                  </div>

                  {daySchedules.length === 0 ? (
                    <p className="text-[11px] text-slate-400 py-6 text-center italic">Tidak ada jadwal</p>
                  ) : (
                    <div className="space-y-2.5">
                      {daySchedules.map((s) => (
                        <div
                          key={s.id}
                          className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60 space-y-1 relative group"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <div className="h-2 w-2 rounded-full" style={{ backgroundColor: s.courseColor || '#2563eb' }} />
                              <span className="font-bold text-xs text-slate-900 dark:text-white">{s.courseName}</span>
                            </div>
                            <button
                              onClick={() => handleDeleteSchedule(s.id)}
                              className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-600 transition"
                              title="Hapus Jadwal"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          <div className="text-[11px] text-slate-600 dark:text-slate-300 flex items-center gap-2">
                            <Clock className="h-3 w-3 text-blue-600 shrink-0" />
                            <span>{s.startTime} - {s.endTime}</span>
                          </div>

                          {s.room && (
                            <div className="text-[10px] text-slate-500 flex items-center gap-1">
                              <MapPin className="h-3 w-3 shrink-0" /> {s.room}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: COURSES LIST */}
      {activeTab === 'COURSES' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.length === 0 ? (
            <div className="col-span-full text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
              <BookOpen className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
              <p className="text-sm font-semibold">Belum ada mata kuliah terdaftar</p>
            </div>
          ) : (
            courses.map((course) => (
              <div
                key={course.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3 relative group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 rounded-full" style={{ backgroundColor: course.color || '#2563eb' }} />
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white">{course.name}</h3>
                      {course.code && <p className="text-[10px] font-mono text-slate-500">{course.code}</p>}
                    </div>
                  </div>
                  <button
                    onClick={() => handleDeleteCourse(course.id)}
                    className="p-1 text-slate-400 hover:text-red-600 transition"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                  {course.lecturer && (
                    <div className="flex items-center gap-1.5">
                      <User className="h-3.5 w-3.5 text-slate-400" />
                      <span>Dosen: {course.lecturer}</span>
                    </div>
                  )}
                  {course.credits && (
                    <div className="flex items-center gap-1.5">
                      <Tag className="h-3.5 w-3.5 text-slate-400" />
                      <span>{course.credits} SKS</span>
                    </div>
                  )}
                  {course.defaultRoom && (
                    <div className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-400" />
                      <span>{course.defaultRoom}</span>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* CREATE COURSE MODAL */}
      {isCourseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Tambah Mata Kuliah Baru</h2>
              <button onClick={() => setIsCourseModalOpen(false)} className="p-1 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Nama Mata Kuliah *</label>
                <input
                  type="text"
                  required
                  value={courseName}
                  onChange={(e) => setCourseName(e.target.value)}
                  placeholder="Misal: Hukum Pidana"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Kode MK</label>
                  <input
                    type="text"
                    value={courseCode}
                    onChange={(e) => setCourseCode(e.target.value)}
                    placeholder="HKP102"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">SKS</label>
                  <input
                    type="number"
                    value={courseCredits}
                    onChange={(e) => setCourseCredits(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Dosen Pengampu</label>
                <input
                  type="text"
                  value={courseLecturer}
                  onChange={(e) => setCourseLecturer(e.target.value)}
                  placeholder="Prof. Dr. Ahmad SH., MH."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Warna Label</label>
                <input
                  type="color"
                  value={courseColor}
                  onChange={(e) => setCourseColor(e.target.value)}
                  className="h-10 w-full rounded-xl cursor-pointer"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCourseModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700"
                >
                  Simpan MK
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE SCHEDULE MODAL */}
      {isScheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Tambah Jadwal Perkuliahan</h2>
              <button onClick={() => setIsScheduleModalOpen(false)} className="p-1 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSchedule} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Mata Kuliah *</label>
                <select
                  required
                  value={selectedCourseId}
                  onChange={(e) => setSelectedCourseId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="">-- Pilih Mata Kuliah --</option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Hari *</label>
                <select
                  value={scheduleDay}
                  onChange={(e) => setScheduleDay(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="1">Senin</option>
                  <option value="2">Selasa</option>
                  <option value="3">Rabu</option>
                  <option value="4">Kamis</option>
                  <option value="5">Jumat</option>
                  <option value="6">Sabtu</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Jam Mulai *</label>
                  <input
                    type="time"
                    required
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Jam Selesai *</label>
                  <input
                    type="time"
                    required
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Ruang Kuliah</label>
                <input
                  type="text"
                  value={scheduleRoom}
                  onChange={(e) => setScheduleRoom(e.target.value)}
                  placeholder="Gedung FH R.301"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700"
                >
                  Simpan Jadwal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
