import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Settings,
  Bell,
  Moon,
  Sun,
  ShieldCheck,
  User,
  LogOut,
  CheckCircle2,
  Cpu
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { user, logout } = useAuth();
  const [pushStatus, setPushStatus] = useState<string>('idle');
  const [isDarkMode, setIsDarkMode] = useState(() => document.documentElement.classList.contains('dark'));

  const toggleDarkMode = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      setIsDarkMode(true);
    }
  };

  const handleSubscribePush = async () => {
    try {
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
        alert('Browser Anda tidak mendukung Web Push Notifications.');
        return;
      }

      setPushStatus('subscribing');

      const registration = await navigator.serviceWorker.ready;
      const keyRes = await fetch('/api/push/vapid-key');
      const { publicKey } = await keyRes.json();

      if (!publicKey) {
        alert('VAPID public key belum dikonfigurasi di server.');
        setPushStatus('idle');
        return;
      }

      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: publicKey,
      });

      await fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subscription),
      });

      setPushStatus('subscribed');
    } catch (e) {
      console.error('Push error:', e);
      setPushStatus('error');
    }
  };

  return (
    <div className="max-w-3xl space-y-6 pb-12">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="h-6 w-6 text-blue-600" /> Pengaturan Sistem
        </h1>
        <p className="text-xs text-slate-500">Atur preferensi akun, notifikasi Web Push, dan tema aplikasi</p>
      </div>

      {/* Profile Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
          <User className="h-4 w-4 text-blue-600" /> Profil Mahasiswa
        </h2>

        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-800">
          <div>
            <p className="font-bold text-base text-slate-900 dark:text-white">{user?.displayName || user?.username}</p>
            <p className="text-xs text-slate-500">Username: @{user?.username}</p>
          </div>
          <button
            onClick={logout}
            className="px-3.5 py-1.5 bg-red-50 hover:bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 font-semibold rounded-xl text-xs flex items-center gap-1.5 transition"
          >
            <LogOut className="h-3.5 w-3.5" /> Keluar Akun
          </button>
        </div>
      </div>

      {/* Web Push Notifications */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <Bell className="h-4 w-4 text-blue-600" /> Web Push & Pengingat Kuliah
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Terima notifikasi pengingat jadwal kuliah (240 m, 120 m, 60 m sebelum kelas) & deadline tugas.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="space-y-0.5">
            <p className="text-xs font-bold text-slate-900 dark:text-white">Status Notifikasi Browser</p>
            <p className="text-[11px] text-slate-500">
              {pushStatus === 'subscribed' ? 'Aktif dan Terhubung dengan QStash Scheduler' : 'Belum Diaktifkan'}
            </p>
          </div>

          <button
            onClick={handleSubscribePush}
            disabled={pushStatus === 'subscribed' || pushStatus === 'subscribing'}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
              pushStatus === 'subscribed'
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 cursor-default'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {pushStatus === 'subscribed' ? (
              <>
                <CheckCircle2 className="h-4 w-4" /> Push Aktif
              </>
            ) : pushStatus === 'subscribing' ? (
              'Mengaktifkan...'
            ) : (
              'Aktifkan Web Push'
            )}
          </button>
        </div>
      </div>

      {/* Theme Setting */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
          {isDarkMode ? <Moon className="h-4 w-4 text-blue-600" /> : <Sun className="h-4 w-4 text-amber-500" />}
          Tema Tampilan
        </h2>

        <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-xs font-bold text-slate-900 dark:text-white">Mode Gelap (Dark Mode)</p>
            <p className="text-[11px] text-slate-500">Kurangi kelelahan mata saat belajar malam hari</p>
          </div>

          <button
            onClick={toggleDarkMode}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white font-semibold rounded-xl text-xs"
          >
            {isDarkMode ? 'Nonaktifkan' : 'Aktifkan'}
          </button>
        </div>
      </div>

      {/* Infrastructure Status */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-3 text-xs">
        <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
          <Cpu className="h-4 w-4 text-blue-600" /> Infrastruktur Backend & AI
        </h2>

        <div className="grid grid-cols-2 gap-3 text-slate-600 dark:text-slate-400">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
            <span className="font-bold text-slate-900 dark:text-white block">Database Engine</span>
            <span>Turso / libSQL (Drizzle ORM)</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
            <span className="font-bold text-slate-900 dark:text-white block">AI Central Routing</span>
            <span>Groq GPT-OSS 120B / Ollama</span>
          </div>
        </div>
      </div>
    </div>
  );
};
