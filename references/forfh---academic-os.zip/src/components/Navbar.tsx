import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  CheckSquare,
  Calendar,
  FileText,
  Scale,
  MoreHorizontal,
  Plus,
  Settings,
  LogOut,
  Bell,
  Search,
  BookOpen
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenQuickCapture: () => void;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenQuickCapture,
  onOpenSettings,
}) => {
  const { user, logout } = useAuth();

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'Tugas', icon: CheckSquare },
    { id: 'schedules', label: 'Jadwal MK', icon: Calendar },
    { id: 'notes', label: 'Catatan', icon: FileText },
    { id: 'pasal', label: 'Pasal.id', icon: Scale },
    { id: 'secondary', label: 'Akademik', icon: MoreHorizontal },
  ];

  return (
    <>
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 dark:text-white tracking-tight text-base sm:text-lg">
                ForFH <span className="text-blue-600 font-medium text-xs sm:text-sm">Academic OS</span>
              </span>
              <p className="text-[10px] text-slate-500 hidden sm:block">Sistem Operasi Akademik Mahasiswa</p>
            </div>
          </div>

          {/* Quick Capture & User Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onOpenQuickCapture}
              className="px-3 py-1.5 sm:px-4 sm:py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-xl text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Quick Capture</span>
              <span className="sm:hidden">Tambah</span>
            </button>

            <button
              onClick={onOpenSettings}
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Pengaturan"
            >
              <Settings className="h-5 w-5" />
            </button>

            <div className="hidden sm:flex items-center pl-2 border-l border-slate-200 dark:border-slate-800 gap-2">
              <div className="text-right">
                <p className="text-xs font-semibold text-slate-900 dark:text-white">{user?.displayName || user?.username}</p>
                <p className="text-[10px] text-slate-500">Mahasiswa Hukum</p>
              </div>
              <button
                onClick={logout}
                className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg transition"
                title="Keluar"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Desktop Navigation Tabs (Horizontal Top Bar under header on larger screens) */}
      <nav className="hidden md:block bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6">
        <div className="max-w-7xl mx-auto flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`py-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition ${
                  isActive
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                    : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Mobile Bottom Bar Navigation (Thumb-friendly) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-2 py-1.5 flex items-center justify-around shadow-lg">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center py-1 px-2 rounded-lg transition ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-[10px] mt-0.5">{item.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => setActiveTab('secondary')}
          className={`flex flex-col items-center py-1 px-2 rounded-lg transition ${
            activeTab === 'secondary'
              ? 'text-blue-600 dark:text-blue-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <MoreHorizontal className="h-5 w-5" />
          <span className="text-[10px] mt-0.5">Lainnya</span>
        </button>
      </div>
    </>
  );
};
