import React, { useState } from 'react';
import { Course } from '../types';
import { Sparkles, Calendar, Clock, AlertCircle, CheckCircle, X, Tag } from 'lucide-react';

interface QuickCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  courses: Course[];
  onTaskCreated: () => void;
}

export const QuickCaptureModal: React.FC<QuickCaptureModalProps> = ({
  isOpen,
  onClose,
  courses,
  onTaskCreated,
}) => {
  const [rawText, setRawText] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Proposal State
  const [proposal, setProposal] = useState<{
    title: string;
    courseId: string | null;
    type: string;
    dueAt: number | null;
    priority: 'low' | 'medium' | 'high' | 'urgent';
    estimatedMinutes: number;
    description: string;
  } | null>(null);

  const [isSaving, setIsSaving] = useState(false);

  if (!isOpen) return null;

  const handleAiParse = async () => {
    if (!rawText.trim()) return;
    setIsParsing(true);
    setError(null);

    try {
      const res = await fetch('/api/ai/quick-capture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal mengurai teks.');

      setProposal({
        title: data.proposed.title || rawText,
        courseId: data.proposed.courseId || null,
        type: data.proposed.type || 'assignment',
        dueAt: data.proposed.dueAt || null,
        priority: data.proposed.priority || 'medium',
        estimatedMinutes: data.proposed.estimatedMinutes || 60,
        description: data.proposed.description || '',
      });
    } catch (err: any) {
      setError(err.message);
      // Fallback proposal
      setProposal({
        title: rawText,
        courseId: null,
        type: 'assignment',
        dueAt: null,
        priority: 'medium',
        estimatedMinutes: 60,
        description: '',
      });
    } finally {
      setIsParsing(false);
    }
  };

  const handleSave = async () => {
    if (!proposal || !proposal.title.trim()) return;
    setIsSaving(true);
    setError(null);

    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: proposal.title,
          courseId: proposal.courseId,
          type: proposal.type,
          dueAt: proposal.dueAt,
          priority: proposal.priority,
          estimatedMinutes: proposal.estimatedMinutes,
          description: proposal.description,
          source: 'quick_capture',
        }),
      });

      if (!res.ok) throw new Error('Gagal menyimpan tugas.');

      setRawText('');
      setProposal(null);
      onTaskCreated();
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const dateValueForInput = proposal?.dueAt
    ? new Date(proposal.dueAt - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16)
    : '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 my-8">
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">Quick Capture</h2>
              <p className="text-xs text-slate-500">Tulis instruksi tugas dengan bahasa bebas</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="mt-4 space-y-4">
          <div>
            <textarea
              rows={3}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Contoh: Senin depan tugas Hukum Pidana analisis putusan MA, deadline jam 9 malam..."
              className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-xs text-slate-400">Tekan 'Urai AI' untuk mendeteksi tanggal & mata kuliah</span>
              <button
                type="button"
                onClick={handleAiParse}
                disabled={isParsing || !rawText.trim()}
                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
              >
                <Sparkles className="h-3.5 w-3.5" />
                {isParsing ? 'Mengurai...' : 'Urai dengan AI'}
              </button>
            </div>
          </div>

          {proposal && (
            <div className="p-4 rounded-xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/50 space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-700 dark:text-blue-400 uppercase tracking-wider">
                <CheckCircle className="h-4 w-4" /> Konfirmasi Hasil Ekstraksi
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Judul Tugas</label>
                <input
                  type="text"
                  value={proposal.title}
                  onChange={(e) => setProposal({ ...proposal, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Mata Kuliah</label>
                  <select
                    value={proposal.courseId || ''}
                    onChange={(e) => setProposal({ ...proposal, courseId: e.target.value || null })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                  >
                    <option value="">- Tidak Terikat MK -</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Jenis Tugas</label>
                  <select
                    value={proposal.type}
                    onChange={(e) => setProposal({ ...proposal, type: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                  >
                    <option value="assignment">Tugas Biasa</option>
                    <option value="essay">Essay / Makalah</option>
                    <option value="paper">Paper Hukum</option>
                    <option value="presentation">Presentasi</option>
                    <option value="reading">Bahan Bacaan</option>
                    <option value="quiz">Kuis / Latihan</option>
                    <option value="administrative">Administratif</option>
                    <option value="other">Lainnya</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" /> Tanggal Deadline
                  </label>
                  <input
                    type="datetime-local"
                    value={dateValueForInput}
                    onChange={(e) => {
                      const val = e.target.value ? new Date(e.target.value).getTime() : null;
                      setProposal({ ...proposal, dueAt: val });
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
                    <Tag className="h-3.5 w-3.5" /> Prioritas
                  </label>
                  <select
                    value={proposal.priority}
                    onChange={(e) => setProposal({ ...proposal, priority: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm"
                  >
                    <option value="low">Rendah</option>
                    <option value="medium">Sedang</option>
                    <option value="high">Tinggi</option>
                    <option value="urgent">Mendesak (Urgent)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setProposal(null)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={isSaving}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition disabled:opacity-50"
                >
                  {isSaving ? 'Menyimpan...' : 'Simpan Tugas'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
