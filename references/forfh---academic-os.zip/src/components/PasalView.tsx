import React, { useState, useEffect } from 'react';
import { LegalBookmark } from '../types';
import {
  Scale,
  Search,
  Bookmark,
  Sparkles,
  BookOpen,
  ExternalLink,
  Trash2,
  X,
  FileText,
  AlertCircle
} from 'lucide-react';

export const PasalView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'SEARCH' | 'BOOKMARKS'>('SEARCH');
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Bookmarks state
  const [bookmarks, setBookmarks] = useState<LegalBookmark[]>([]);

  // Selected Regulation Detail & AI Explanation Modal
  const [selectedLaw, setSelectedLaw] = useState<any | null>(null);
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [isExplaining, setIsExplaining] = useState(false);

  const fetchBookmarks = async () => {
    try {
      const res = await fetch('/api/pasal/bookmarks');
      if (res.ok) {
        const data = await res.json();
        setBookmarks(data);
      }
    } catch (e) {}
  };

  useEffect(() => {
    fetchBookmarks();
  }, []);

  // Handle Search Pasal.id
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchError(null);

    try {
      const res = await fetch(`/api/pasal/search?q=${encodeURIComponent(searchQuery.trim())}`);
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || 'Gagal mencari peraturan.');
      setSearchResults(data.data || data.laws || data.results || []);
    } catch (err: any) {
      setSearchError(err.message);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // Add Bookmark
  const handleAddBookmark = async (law: any) => {
    try {
      await fetch('/api/pasal/bookmarks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          frbrUri: law.frbr_uri || law.uri || law.id,
          title: law.title || law.name,
          type: law.type || null,
          number: law.number || null,
          year: law.year || null,
        }),
      });
      fetchBookmarks();
    } catch (e) {}
  };

  // Remove Bookmark
  const handleRemoveBookmark = async (bookmarkId: string) => {
    await fetch(`/api/pasal/bookmarks/${bookmarkId}`, { method: 'DELETE' });
    fetchBookmarks();
  };

  // Ask AI Grounded Explanation
  const handleAskAiExplanation = async () => {
    if (!aiQuestion.trim()) return;
    setIsExplaining(true);
    setAiExplanation(null);

    try {
      const res = await fetch('/api/ai/legal-explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: aiQuestion,
          frbrUri: selectedLaw?.frbr_uri || selectedLaw?.uri || null,
        }),
      });

      const data = await res.json();
      setAiExplanation(data.explanation || 'Penjelasan tidak tersedia.');
    } catch (e) {
      setAiExplanation('Gagal memproses penjelasan AI.');
    } finally {
      setIsExplaining(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Scale className="h-6 w-6 text-blue-600" /> Penjelajah Law & Pasal.id
          </h1>
          <p className="text-xs text-slate-500">Riset perundang-undangan dan penjelasan AI grounded resmi</p>
        </div>

        <div className="flex border border-slate-200 dark:border-slate-800 rounded-xl p-1 bg-white dark:bg-slate-900">
          <button
            onClick={() => setActiveTab('SEARCH')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              activeTab === 'SEARCH' ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Pencarian Hukum
          </button>
          <button
            onClick={() => setActiveTab('BOOKMARKS')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition ${
              activeTab === 'BOOKMARKS' ? 'bg-blue-600 text-white' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Tersimpan ({bookmarks.length})
          </button>
        </div>
      </div>

      {activeTab === 'SEARCH' && (
        <div className="space-y-6">
          {/* Search Box */}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari kata kunci peraturan (misal: 'KUHP', 'Pidana', 'Pajak', 'Hak Cipta')..."
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs sm:text-sm shadow-sm transition disabled:opacity-50"
            >
              {isSearching ? 'Mencari...' : 'Cari Pasal.id'}
            </button>
          </form>

          {searchError && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{searchError}</span>
            </div>
          )}

          {/* Results List */}
          <div className="space-y-3">
            {searchResults.length === 0 && !isSearching && (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400 space-y-1">
                <Scale className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-sm font-semibold">Gunakan bilah pencarian untuk menemukan peraturan</p>
                <p className="text-xs">Database terhubung langsung dengan REST API resmi Pasal.id</p>
              </div>
            )}

            {searchResults.map((law, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 hover:border-blue-300 dark:hover:border-blue-800 transition shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    {law.type || 'Peraturan'} #{law.number || ''} Tahun {law.year || ''}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">{law.title || law.name}</h3>
                  <p className="text-xs text-slate-500 font-mono">{law.frbr_uri || law.uri}</p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleAddBookmark(law)}
                    className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition"
                    title="Simpan Bookmark"
                  >
                    <Bookmark className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setSelectedLaw(law)}
                    className="px-3.5 py-2 bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-semibold rounded-xl text-xs flex items-center gap-1.5 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition"
                  >
                    <Sparkles className="h-3.5 w-3.5" /> Analisis AI
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'BOOKMARKS' && (
        <div className="space-y-3">
          {bookmarks.length === 0 ? (
            <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
              <Bookmark className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
              <p className="text-sm font-semibold">Belum ada peraturan tersimpan</p>
            </div>
          ) : (
            bookmarks.map((b) => (
              <div
                key={b.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">{b.title}</h3>
                  <p className="text-xs text-slate-500 font-mono">{b.frbrUri}</p>
                </div>

                <button
                  onClick={() => handleRemoveBookmark(b.id)}
                  className="p-2 text-slate-400 hover:text-red-600 transition"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))
          )}
        </div>
      )}

      {/* AI LEGAL EXPLANATION MODAL */}
      {selectedLaw && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 my-8 space-y-4">
            <div className="flex items-start justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-[10px] font-bold text-blue-600 uppercase">Analisis AI Grounded Pasal.id</span>
                <h2 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">{selectedLaw.title || selectedLaw.name}</h2>
              </div>
              <button onClick={() => setSelectedLaw(null)} className="p-1 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Pertanyaan Akademik Hukum
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiQuestion}
                    onChange={(e) => setAiQuestion(e.target.value)}
                    placeholder="Misal: Jelaskan unsur-unsur pasal ini dan relevansinya dalam hukum pidana..."
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
                  />
                  <button
                    onClick={handleAskAiExplanation}
                    disabled={isExplaining || !aiQuestion.trim()}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition disabled:opacity-50"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    {isExplaining ? 'Proses...' : 'Jelaskan'}
                  </button>
                </div>
              </div>

              {aiExplanation && (
                <div className="p-4 rounded-xl bg-blue-50/50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 space-y-2">
                  <h4 className="text-xs font-bold text-blue-700 dark:text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" /> Penjelasan Dosen AI
                  </h4>
                  <p className="text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
                    {aiExplanation}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
