import React, { useState, useEffect } from 'react';
import { Task, ClassSchedule, Course } from '../types';
import {
  Sparkles,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  ArrowRight,
  BookOpen,
  Plus,
  RefreshCw,
  MapPin,
  ExternalLink
} from 'lucide-react';

interface DashboardViewProps {
  tasks: Task[];
  schedules: ClassSchedule[];
  courses: Course[];
  onOpenQuickCapture: () => void;
  onNavigateTab: (tab: string) => void;
  onTaskStatusToggle: (taskId: string, currentStatus: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  tasks,
  schedules,
  courses,
  onOpenQuickCapture,
  onNavigateTab,
  onTaskStatusToggle,
}) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  // Fetch AI Today Insight
  const fetchInsight = async () => {
    setLoadingInsight(true);
    try {
      const res = await fetch('/api/ai/today-insight');
      if (res.ok) {
        const data = await res.json();
        setInsight(data.insight);
      }
    } catch (e) {
      setInsight('Fokus hari ini pada tugas dengan deadline terdekat dan kelas kuliah pekan ini.');
    } finally {
      setLoadingInsight(false);
    }
  };

  useEffect(() => {
    fetchInsight();
  }, [tasks.length, schedules.length]);

  const now = new Date();
  const currentDay = now.getDay(); // 0 = Sun, 1 = Mon...
  const nowTimestamp = now.getTime();

  // Filter Today's Schedules
  const todaySchedules = schedules
    .filter((s) => s.dayOfWeek === currentDay)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Determine Next Class
  const nextClass = todaySchedules.find((s) => {
    const [h, m] = s.startTime.split(':').map(Number);
    const classTime = new Date(now);
    classTime.setHours(h, m, 0, 0);
    return classTime.getTime() > nowTimestamp;
  });

  // Tasks Statistics
  const overdueTasks = tasks.filter((t) => t.status !== 'DONE' && t.dueAt && t.dueAt < nowTimestamp);
  const activeTasks = tasks.filter((t) => t.status !== 'DONE').sort((a, b) => (a.dueAt || 9999999999999) - (b.dueAt || 9999999999999));
  const doneCount = tasks.filter((t) => t.status === 'DONE').length;

  const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const todayName = dayNames[currentDay];
  const dateFormatted = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome & Primary Focus Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 rounded-2xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold text-blue-100">
            <Calendar className="h-3.5 w-3.5" />
            <span>{todayName}, {dateFormatted}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Sekarang Aku Harus Ngapain?
          </h1>

          {/* AI Insight Card */}
          <div className="p-4 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-blue-200">
              <span className="flex items-center gap-1.5">
                <Sparkles className="h-4 w-4 text-yellow-300" /> Executive AI Insight
              </span>
              <button
                onClick={fetchInsight}
                disabled={loadingInsight}
                className="hover:text-white transition"
                title="Muat Ulang AI Insight"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loadingInsight ? 'animate-spin' : ''}`} />
              </button>
            </div>
            <p className="text-sm font-medium leading-relaxed text-blue-50">
              {loadingInsight ? 'Menganalisis jadwal & tugasmu...' : insight || 'Gunakan waktu hari ini untuk menyelesaikan prioritas utama.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={onOpenQuickCapture}
              className="px-4 py-2 bg-white text-blue-700 hover:bg-blue-50 font-semibold rounded-xl text-xs sm:text-sm shadow-sm transition flex items-center gap-2"
            >
              <Plus className="h-4 w-4" /> Quick Capture Tugas Baru
            </button>
            <button
              onClick={() => onNavigateTab('tasks')}
              className="px-4 py-2 bg-blue-800/60 hover:bg-blue-800 text-white font-medium rounded-xl text-xs sm:text-sm transition flex items-center gap-1.5"
            >
              Lihat Semua Tugas <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Overdue Warning Alert */}
      {overdueTasks.length > 0 && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-900 dark:text-red-200 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs sm:text-sm">
            <p className="font-bold">Ada {overdueTasks.length} tugas yang telah terlewat (overdue)!</p>
            <p className="text-red-700 dark:text-red-300 mt-0.5">
              Segera periksa tugas: <span className="font-semibold">{overdueTasks[0].title}</span>
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('tasks')}
            className="px-3 py-1 bg-red-600 text-white text-xs font-semibold rounded-lg hover:bg-red-700 transition shrink-0"
          >
            Tinjau
          </button>
        </div>
      )}

      {/* Grid Summary Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Schedule Today & Next Class */}
        <div className="lg:col-span-1 space-y-6">
          {/* Next Class Highlight */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-600" /> Kuliah Berikutnya
              </h2>
              <span className="text-[10px] bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-semibold px-2 py-0.5 rounded-full">
                {todayName}
              </span>
            </div>

            {nextClass ? (
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: nextClass.courseColor || '#2563eb' }} />
                  <span className="font-bold text-slate-900 dark:text-white text-base">{nextClass.courseName}</span>
                </div>
                <div className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-4 pt-1">
                  <span className="flex items-center gap-1 font-semibold text-blue-600 dark:text-blue-400">
                    <Clock className="h-3.5 w-3.5" /> {nextClass.startTime} - {nextClass.endTime} WIB
                  </span>
                  {nextClass.room && (
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" /> {nextClass.room}
                    </span>
                  )}
                </div>
                {nextClass.onlineUrl && (
                  <a
                    href={nextClass.onlineUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 inline-flex items-center gap-1 text-xs text-blue-600 hover:underline font-semibold"
                  >
                    Buka Link Kuliah Online <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-500 py-4 text-center">
                {todaySchedules.length > 0 ? 'Semua kuliah hari ini telah selesai.' : 'Tidak ada jadwal perkuliahan hari ini.'}
              </p>
            )}
          </div>

          {/* Today's Full Schedule List */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Jadwal Kuliah Hari Ini ({todaySchedules.length})
              </h2>
              <button
                onClick={() => onNavigateTab('schedules')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Lihat Minggu
              </button>
            </div>

            {todaySchedules.length === 0 ? (
              <div className="text-center py-6 text-slate-400 space-y-1">
                <BookOpen className="h-8 w-8 mx-auto text-slate-300 dark:text-slate-700" />
                <p className="text-xs">Hari libur perkuliahan</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {todaySchedules.map((s) => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.courseColor || '#2563eb' }} />
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{s.courseName}</p>
                        <p className="text-slate-500">{s.room || 'Ruang belum diatur'}</p>
                      </div>
                    </div>
                    <span className="font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                      {s.startTime} - {s.endTime}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Active Tasks & Priorities */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  Tugas Prioritas Mendatang ({activeTasks.length})
                </h2>
                <p className="text-xs text-slate-500">Selesaikan tugas sesuai urutan tenggat waktu</p>
              </div>
              <button
                onClick={() => onNavigateTab('tasks')}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
              >
                Kelola Tugas
              </button>
            </div>

            {activeTasks.length === 0 ? (
              <div className="text-center py-10 text-slate-400 space-y-2 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                <CheckCircle2 className="h-10 w-10 mx-auto text-emerald-500" />
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">Semua tugas telah selesai!</p>
                <p className="text-xs">Klik 'Quick Capture' untuk menambahkan tugas baru.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {activeTasks.slice(0, 5).map((t) => {
                  const isOverdue = t.dueAt && t.dueAt < nowTimestamp;
                  const dueString = t.dueAt
                    ? new Date(t.dueAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
                    : 'Tanpa Deadline';

                  return (
                    <div
                      key={t.id}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition bg-white dark:bg-slate-800/60 flex items-start justify-between gap-3"
                    >
                      <div className="flex items-start gap-3 min-w-0">
                        <button
                          onClick={() => onTaskStatusToggle(t.id, t.status)}
                          className="mt-0.5 text-slate-300 hover:text-emerald-600 transition"
                          title="Tandai Selesai"
                        >
                          <CheckCircle2 className="h-5 w-5" />
                        </button>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{t.title}</p>
                          <div className="flex flex-wrap items-center gap-2 mt-1 text-xs">
                            {t.courseName && (
                              <span className="px-2 py-0.5 rounded-md font-semibold text-[10px] bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                {t.courseName}
                              </span>
                            )}
                            <span className={`font-medium flex items-center gap-1 ${isOverdue ? 'text-red-600 font-bold' : 'text-slate-500 dark:text-slate-400'}`}>
                              <Clock className="h-3 w-3" /> {dueString}
                            </span>
                          </div>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-full shrink-0 ${
                          t.priority === 'urgent'
                            ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                            : t.priority === 'high'
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                            : 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
