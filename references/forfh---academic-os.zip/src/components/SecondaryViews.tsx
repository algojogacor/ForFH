import React, { useState, useEffect } from 'react';
import { Exam, Course, FileItem } from '../types';
import {
  GraduationCap,
  BookOpen,
  CheckCircle2,
  HardDrive,
  Plus,
  Trash2,
  X,
  Upload,
  Calendar,
  Clock,
  MapPin,
  Tag
} from 'lucide-react';

interface SecondaryViewsProps {
  courses: Course[];
}

export const SecondaryViews: React.FC<SecondaryViewsProps> = ({ courses }) => {
  const [subTab, setSubTab] = useState<'EXAMS' | 'READINGS' | 'ATTENDANCE' | 'GPA' | 'FILES'>('EXAMS');

  // EXAMS State
  const [examsList, setExamsList] = useState<Exam[]>([]);
  const [isExamModalOpen, setIsExamModalOpen] = useState(false);
  const [examCourseId, setExamCourseId] = useState('');
  const [examName, setExamName] = useState('');
  const [examType, setExamType] = useState<'UTS' | 'UAS' | 'QUIZ' | 'OTHER'>('UTS');
  const [examDate, setExamDate] = useState('');
  const [examLocation, setExamLocation] = useState('');

  // READINGS State
  const [readingsList, setReadingsList] = useState<any[]>([]);
  const [isReadingModalOpen, setIsReadingModalOpen] = useState(false);
  const [readingTitle, setReadingTitle] = useState('');
  const [readingAuthor, setReadingAuthor] = useState('');
  const [readingCourseId, setReadingCourseId] = useState('');

  // ATTENDANCE State
  const [attendanceList, setAttendanceList] = useState<any[]>([]);
  const [isAttendanceModalOpen, setIsAttendanceModalOpen] = useState(false);
  const [attCourseId, setAttCourseId] = useState('');
  const [attStatus, setAttStatus] = useState<'HADIR' | 'IZIN' | 'SAKIT' | 'ALPA'>('HADIR');

  // FILES State
  const [filesData, setFilesData] = useState<{ files: FileItem[]; storageUsedBytes: number; storageQuotaBytes: number }>({
    files: [],
    storageUsedBytes: 0,
    storageQuotaBytes: 524288000,
  });

  // Fetch Methods
  const fetchExams = async () => {
    try {
      const res = await fetch('/api/exams');
      if (res.ok) setExamsList(await res.json());
    } catch (e) {}
  };

  const fetchReadings = async () => {
    try {
      const res = await fetch('/api/readings');
      if (res.ok) setReadingsList(await res.json());
    } catch (e) {}
  };

  const fetchAttendance = async () => {
    try {
      const res = await fetch('/api/attendance');
      if (res.ok) setAttendanceList(await res.json());
    } catch (e) {}
  };

  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/files');
      if (res.ok) setFilesData(await res.json());
    } catch (e) {}
  };

  useEffect(() => {
    fetchExams();
    fetchReadings();
    fetchAttendance();
    fetchFiles();
  }, []);

  // Save Exam
  const handleSaveExam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!examCourseId || !examName || !examDate) return;

    await fetch('/api/exams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        courseId: examCourseId,
        name: examName.trim(),
        type: examType,
        examAt: new Date(examDate).getTime(),
        location: examLocation.trim() || null,
      }),
    });

    setIsExamModalOpen(false);
    fetchExams();
  };

  // Toggle Exam Topic
  const handleToggleTopic = async (topicId: string, currentVal: boolean) => {
    await fetch(`/api/exam-topics/${topicId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !currentVal }),
    });
    fetchExams();
  };

  // Save Reading
  const handleSaveReading = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!readingTitle) return;

    await fetch('/api/readings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: readingTitle.trim(),
        author: readingAuthor.trim() || null,
        courseId: readingCourseId || null,
      }),
    });

    setIsReadingModalOpen(false);
    fetchReadings();
  };

  // Save Attendance
  const handleSaveAttendance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!attCourseId) return;

    await fetch('/api/attendance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        courseId: attCourseId,
        classDate: new Date().toISOString().split('T')[0],
        status: attStatus,
      }),
    });

    setIsAttendanceModalOpen(false);
    fetchAttendance();
  };

  // Handle Upload File Metadata Session
  const handleUploadFileSession = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    await fetch('/api/files/upload-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: file.name,
        mimeType: file.type,
        sizeBytes: file.size,
        category: 'document',
      }),
    });

    fetchFiles();
  };

  const usedMB = (filesData.storageUsedBytes / (1024 * 1024)).toFixed(1);
  const quotaMB = (filesData.storageQuotaBytes / (1024 * 1024)).toFixed(0);

  return (
    <div className="space-y-6 pb-12">
      {/* Subtab Bar */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2 overflow-x-auto pb-2">
        {[
          { id: 'EXAMS', label: 'Modul Ujian (UTS/UAS)', icon: GraduationCap },
          { id: 'READINGS', label: 'Bahan Bacaan', icon: BookOpen },
          { id: 'ATTENDANCE', label: 'Presensi Kehadiran', icon: CheckCircle2 },
          { id: 'FILES', label: 'Google Drive Storage', icon: HardDrive },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SUBTAB 1: EXAMS */}
      {subTab === 'EXAMS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Jadwal Ujian & Mode Persiapan</h2>
            <button
              onClick={() => setIsExamModalOpen(true)}
              className="px-3.5 py-2 bg-blue-600 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5"
            >
              <Plus className="h-4 w-4" /> Tambah Ujian
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {examsList.length === 0 ? (
              <div className="col-span-full text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <GraduationCap className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-sm font-semibold">Belum ada ujian dijadwalkan</p>
              </div>
            ) : (
              examsList.map((exam) => (
                <div key={exam.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                        {exam.type}
                      </span>
                      <h3 className="font-bold text-base text-slate-900 dark:text-white mt-1">{exam.name}</h3>
                      <p className="text-xs text-slate-500 font-medium">{exam.courseName}</p>
                    </div>
                  </div>

                  <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1">
                    <div className="flex items-center gap-1.5 font-semibold text-blue-600 dark:text-blue-400">
                      <Clock className="h-3.5 w-3.5" />
                      <span>{new Date(exam.examAt).toLocaleString('id-ID', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    {exam.location && (
                      <div className="flex items-center gap-1.5 text-slate-500">
                        <MapPin className="h-3.5 w-3.5" /> {exam.location}
                      </div>
                    )}
                  </div>

                  {exam.topics && exam.topics.length > 0 && (
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                      <p className="text-[10px] font-bold uppercase text-slate-400">Topik Kisi-Kisi ({exam.topics.filter(t => t.completed).length}/{exam.topics.length})</p>
                      {exam.topics.map((top) => (
                        <div key={top.id} className="flex items-center gap-2 text-xs">
                          <input
                            type="checkbox"
                            checked={top.completed}
                            onChange={() => handleToggleTopic(top.id, top.completed)}
                            className="rounded text-blue-600"
                          />
                          <span className={top.completed ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}>
                            {top.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 2: READINGS */}
      {subTab === 'READINGS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Pelacak Bahan Bacaan & Literatur</h2>
            <button
              onClick={() => setIsReadingModalOpen(true)}
              className="px-3.5 py-2 bg-blue-600 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5"
            >
              <Plus className="h-4 w-4" /> Bacaan Baru
            </button>
          </div>

          <div className="space-y-3">
            {readingsList.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <BookOpen className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-sm font-semibold">Belum ada daftar bahan bacaan</p>
              </div>
            ) : (
              readingsList.map((r) => (
                <div key={r.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">{r.title}</h3>
                    <p className="text-xs text-slate-500">{r.author || 'Penulis tidak dicantumkan'}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 3: ATTENDANCE */}
      {subTab === 'ATTENDANCE' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Log Presensi Kehadiran Kuliah</h2>
            <button
              onClick={() => setIsAttendanceModalOpen(true)}
              className="px-3.5 py-2 bg-blue-600 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5"
            >
              <Plus className="h-4 w-4" /> Catat Kehadiran
            </button>
          </div>

          <div className="space-y-2">
            {attendanceList.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <CheckCircle2 className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-sm font-semibold">Belum ada catatan presensi</p>
              </div>
            ) : (
              attendanceList.map((att) => (
                <div key={att.id} className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{att.courseName}</p>
                    <p className="text-slate-500">{att.classDate}</p>
                  </div>
                  <span className="font-bold px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                    {att.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 4: FILES / DRIVE */}
      {subTab === 'FILES' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Google Drive Central Storage</h2>
                <p className="text-xs text-slate-500">Penyimpanan tersentralisasi khusus pengguna ForFH</p>
              </div>
              <label className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs cursor-pointer flex items-center gap-1.5">
                <Upload className="h-4 w-4" /> Unggah Berkas
                <input type="file" onChange={handleUploadFileSession} className="hidden" />
              </label>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400 font-semibold">
                <span>Penggunaan Ruang Penyimpanan</span>
                <span>{usedMB} MB / {quotaMB} MB</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-blue-600 rounded-full"
                  style={{ width: `${Math.min(100, (filesData.storageUsedBytes / filesData.storageQuotaBytes) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            {filesData.files.length === 0 ? (
              <div className="text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
                <HardDrive className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
                <p className="text-sm font-semibold">Belum ada berkas terunggah</p>
              </div>
            ) : (
              filesData.files.map((file) => (
                <div key={file.id} className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">{file.name}</p>
                    <p className="text-slate-500">{(file.sizeBytes / 1024).toFixed(0)} KB</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* CREATE EXAM MODAL */}
      {isExamModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">Tambah Jadwal Ujian</h2>
              <button onClick={() => setIsExamModalOpen(false)}><X className="h-5 w-5 text-slate-400" /></button>
            </div>
            <form onSubmit={handleSaveExam} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Mata Kuliah *</label>
                <select
                  required
                  value={examCourseId}
                  onChange={(e) => setExamCourseId(e.target.value)}
                  className="w-full p-2 border rounded-xl dark:bg-slate-800"
                >
                  <option value="">-- Pilih MK --</option>
                  {courses.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold mb-1">Nama Ujian *</label>
                <input
                  type="text"
                  required
                  value={examName}
                  onChange={(e) => setExamName(e.target.value)}
                  placeholder="UTS Hukum Pidana"
                  className="w-full p-2 border rounded-xl dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Tanggal & Waktu Ujian *</label>
                <input
                  type="datetime-local"
                  required
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                  className="w-full p-2 border rounded-xl dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsExamModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Batal</button>
                <button type="submit" className="px-3 py-1.5 bg-blue-600 text-white rounded-xl font-semibold">Simpan Ujian</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
