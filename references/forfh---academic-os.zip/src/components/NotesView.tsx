import React, { useState } from 'react';
import { Note, Course } from '../types';
import ReactMarkdown from 'react-markdown';
import {
  Plus,
  Pin,
  Search,
  FileText,
  Trash2,
  Edit2,
  X,
  BookOpen,
  Calendar
} from 'lucide-react';

interface NotesViewProps {
  notes: Note[];
  courses: Course[];
  onRefreshNotes: () => void;
}

export const NotesView: React.FC<NotesViewProps> = ({
  notes,
  courses,
  onRefreshNotes,
}) => {
  const [selectedCourse, setSelectedCourse] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Selected / Editing Note State
  const [activeNote, setActiveNote] = useState<Note | null>(null);

  // New Note Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [courseId, setCourseId] = useState('');
  const [content, setContent] = useState('');
  const [pinned, setPinned] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const filteredNotes = notes.filter((n) => {
    if (selectedCourse !== 'ALL' && n.courseId !== selectedCourse) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q);
    }
    return true;
  });

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setIsSaving(true);

    try {
      const isEdit = Boolean(activeNote?.id);
      const url = isEdit ? `/api/notes/${activeNote!.id}` : '/api/notes';
      const method = isEdit ? 'PUT' : 'POST';

      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          courseId: courseId || null,
          content,
          pinned,
        }),
      });

      setIsModalOpen(false);
      setActiveNote(null);
      setTitle('');
      setContent('');
      onRefreshNotes();
    } catch (e) {
      console.error('Gagal menyimpan catatan', e);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTogglePin = async (note: Note) => {
    await fetch(`/api/notes/${note.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pinned: !note.pinned }),
    });
    onRefreshNotes();
  };

  const handleDeleteNote = async (noteId: string) => {
    if (!confirm('Hapus catatan ini?')) return;
    await fetch(`/api/notes/${noteId}`, { method: 'DELETE' });
    if (activeNote?.id === noteId) setActiveNote(null);
    onRefreshNotes();
  };

  const openEditModal = (note: Note) => {
    setActiveNote(note);
    setTitle(note.title);
    setCourseId(note.courseId || '');
    setContent(note.content);
    setPinned(note.pinned);
    setIsModalOpen(true);
  };

  const openNewModal = () => {
    setActiveNote(null);
    setTitle('');
    setCourseId('');
    setContent('');
    setPinned(false);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Catatan Akademik</h1>
          <p className="text-xs text-slate-500">Rangkuman materi perkuliahan, jurnal, dan jurisprudensi</p>
        </div>

        <button
          onClick={openNewModal}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" /> Catatan Baru
        </button>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={selectedCourse}
            onChange={(e) => setSelectedCourse(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white"
          >
            <option value="ALL">Semua Mata Kuliah</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari kata kunci catatan..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredNotes.length === 0 ? (
          <div className="col-span-full text-center py-12 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-400">
            <FileText className="h-10 w-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-sm font-semibold">Tidak ada catatan ditemukan</p>
          </div>
        ) : (
          filteredNotes.map((note) => (
            <div
              key={note.id}
              className={`bg-white dark:bg-slate-900 rounded-2xl border p-5 space-y-3 relative group transition shadow-xs flex flex-col justify-between ${
                note.pinned ? 'border-amber-300 dark:border-amber-800/60 bg-amber-50/20' : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white line-clamp-2">{note.title}</h3>
                  <button
                    onClick={() => handleTogglePin(note)}
                    className={`p-1 rounded-lg transition ${note.pinned ? 'text-amber-500' : 'text-slate-300 hover:text-slate-500'}`}
                    title={note.pinned ? 'Lepas Pin' : 'Sematkan di atas'}
                  >
                    <Pin className="h-4 w-4 fill-current" />
                  </button>
                </div>

                {note.courseName && (
                  <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    {note.courseName}
                  </span>
                )}

                <div className="text-xs text-slate-600 dark:text-slate-400 line-clamp-4 prose dark:prose-invert max-w-none text-left">
                  <ReactMarkdown>{note.content || '*Tanpa isi*'}</ReactMarkdown>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
                <span>{new Date(note.updatedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEditModal(note)}
                    className="p-1 hover:text-blue-600 transition"
                    title="Edit"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => handleDeleteNote(note.id)}
                    className="p-1 hover:text-red-600 transition"
                    title="Hapus"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* CREATE / EDIT NOTE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 my-8 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {activeNote ? 'Edit Catatan' : 'Tambah Catatan Baru'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="p-1 text-slate-400">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Judul Catatan *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Misal: Asas Legalitas dalam Hukum Pidana"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Mata Kuliah</label>
                  <select
                    value={courseId}
                    onChange={(e) => setCourseId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="">- Tidak Terikat MK -</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={pinned}
                      onChange={(e) => setPinned(e.target.checked)}
                      className="rounded text-amber-500 focus:ring-amber-500"
                    />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">Sematkan Catatan (Pin)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Isi Catatan (Mendukung Markdown)</label>
                <textarea
                  rows={10}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Tulis rangkuman perkuliahan di sini... Anda bisa menggunakan Markdown (# Judul, **tebal**, - poin)"
                  className="w-full p-3.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700"
                >
                  {isSaving ? 'Menyimpan...' : 'Simpan Catatan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
