import { createClient } from '@libsql/client';
import { drizzle } from 'drizzle-orm/libsql';
import * as schema from './schema';

const url = process.env.TURSO_DATABASE_URL || 'file:local.db';
const authToken = process.env.TURSO_AUTH_TOKEN;

export const libsqlClient = createClient({
  url,
  authToken: authToken || undefined,
});

export const db = drizzle(libsqlClient, { schema });
