import { sqliteTable, text, integer, primaryKey, index, uniqueIndex } from 'drizzle-orm/sqlite-core';

// 1. Users
export const users = sqliteTable('users', {
  id: text('id').primaryKey(),
  username: text('username').notNull(),
  usernameNormalized: text('username_normalized').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  displayName: text('display_name'),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
}, (table) => [
  uniqueIndex('idx_users_username_normalized').on(table.usernameNormalized),
]);

// 2. Sessions
export const sessions = sqliteTable('sessions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text('token_hash').notNull().unique(),
  createdAt: integer('created_at').notNull(),
  expiresAt: integer('expires_at').notNull(),
  lastSeenAt: integer('last_seen_at').notNull(),
}, (table) => [
  uniqueIndex('idx_sessions_token_hash').on(table.tokenHash),
  index('idx_sessions_user_id').on(table.userId),
]);

// 3. User Settings
export const userSettings = sqliteTable('user_settings', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().unique().references(() => users.id, { onDelete: 'cascade' }),
  timezone: text('timezone').notNull().default('Asia/Jakarta'),
  locale: text('locale').notNull().default('id-ID'),
  theme: text('theme').notNull().default('system'), // system | light | dark
  defaultTaskReminders: text('default_task_reminders').notNull().default('10080,4320,1440,360,60'), // minutes before due
  defaultClassReminders: text('default_class_reminders').notNull().default('120,90,60,30,20'),
  primaryClassAlertMinutes: integer('primary_class_alert_minutes').notNull().default(240),
  deadlineBufferMinutes: integer('deadline_buffer_minutes').notNull().default(1440),
  aiEnabled: integer('ai_enabled', { mode: 'boolean' }).notNull().default(true),
  storageUsedBytes: integer('storage_used_bytes').notNull().default(0),
  storageQuotaBytes: integer('storage_quota_bytes').notNull().default(524288000), // 500MB
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});

// 4. Academic Terms
export const academicTerms = sqliteTable('academic_terms', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  name: text('name').notNull(), // e.g. "Semester 3 2026/2027"
  startDate: text('start_date').notNull(),
  endDate: text('end_date').notNull(),
  isActive: integer('is_active', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
}, (table) => [
  index('idx_academic_terms_user').on(table.userId),
]);

// 5. Courses
export const courses = sqliteTable('courses', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  academicTermId: text('academic_term_id').references(() => academicTerms.id, { onDelete: 'set null' }),
  name: text('name').notNull(),
  code: text('code'),
  lecturer: text('lecturer'),
  credits: integer('credits'),
  color: text('color').default('#2563eb'),
  defaultRoom: text('default_room'),
  onlineUrl: text('online_url'),
  notes: text('notes'),
  archived: integer('archived', { mode: 'boolean' }).notNull().default(false),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
}, (table) => [
  index('idx_courses_user').on(table.userId),
]);

// 6. Class Schedules
export const classSchedules = sqliteTable('class_schedules', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').notNull().references(() => courses.id, { onDelete: 'cascade' }),
  dayOfWeek: integer('day_of_week').notNull(), // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  startTime: text('start_time').notNull(), // HH:mm
  endTime: text('end_time').notNull(), // HH:mm
  room: text('room'),
  onlineUrl: text('online_url'),
  validFrom: text('valid_from'),
  validUntil: text('valid_until'),
  enabled: integer('enabled', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
}, (table) => [
  index('idx_class_schedules_user').on(table.userId),
  index('idx_class_schedules_course').on(table.courseId),
  index('idx_class_schedules_day').on(table.dayOfWeek),
]);

// 7. Tasks
export const tasks = sqliteTable('tasks', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').references(() => courses.id, { onDelete: 'set null' }),
  title: text('title').notNull(),
  description: text('description'),
  type: text('type').notNull().default('assignment'), // assignment | essay | paper | presentation | reading | quiz | practice | administrative | other
  dueAt: integer('due_at'),
  internalTargetAt: integer('internal_target_at'),
  priority: text('priority').notNull().default('medium'), // low | medium | high | urgent
  estimatedMinutes: integer('estimated_minutes'),
  status: text('status').notNull().default('NOT_STARTED'), // NOT_STARTED | IN_PROGRESS | REVISION | DONE | OVERDUE
  progress: integer('progress').notNull().default(0), // 0-100
  source: text('source').notNull().default('manual'), // manual | ai | quick_capture
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
  completedAt: integer('completed_at'),
  deletedAt: integer('deleted_at'),
  version: integer('version').notNull().default(1),
}, (table) => [
  index('idx_tasks_user').on(table.userId),
  index('idx_tasks_course').on(table.courseId),
  index('idx_tasks_due').on(table.dueAt),
  index('idx_tasks_status').on(table.status),
]);

// 8. Subtasks
export const subtasks = sqliteTable('subtasks', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  taskId: text('task_id').notNull().references(() => tasks.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  completed: integer('completed', { mode: 'boolean' }).notNull().default(false),
  orderIndex: integer('order_index').notNull().default(0),
  estimatedMinutes: integer('estimated_minutes'),
  dueAt: integer('due_at'),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
  deletedAt: integer('deleted_at'),
  version: integer('version').notNull().default(1),
}, (table) => [
  index('idx_subtasks_task').on(table.taskId),
]);

// 9. Task Reminders
export const taskReminders = sqliteTable('task_reminders', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  taskId: text('task_id').notNull().references(() => tasks.id, { onDelete: 'cascade' }),
  offsetMinutes: integer('offset_minutes').notNull(),
  enabled: integer('enabled', { mode: 'boolean' }).notNull().default(true),
  createdAt: integer('created_at').notNull(),
});

// 10. Notes
export const notes = sqliteTable('notes', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').references(() => courses.id, { onDelete: 'set null' }),
  title: text('title').notNull(),
  content: text('content').notNull().default(''),
  format: text('format').notNull().default('markdown'),
  pinned: integer('pinned', { mode: 'boolean' }).notNull().default(false),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
  deletedAt: integer('deleted_at'),
  version: integer('version').notNull().default(1),
}, (table) => [
  index('idx_notes_user').on(table.userId),
  index('idx_notes_course').on(table.courseId),
]);

// 11. Readings
export const readings = sqliteTable('readings', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').references(() => courses.id, { onDelete: 'set null' }),
  fileId: text('file_id'),
  type: text('type').notNull().default('book'), // book | journal | law | case | module | ppt | other
  title: text('title').notNull(),
  author: text('author'),
  sourceUrl: text('source_url'),
  startPage: integer('start_page'),
  endPage: integer('end_page'),
  currentPage: integer('current_page'),
  status: text('status').notNull().default('NOT_STARTED'), // NOT_STARTED | READING | DONE
  deadline: integer('deadline'),
  notes: text('notes'),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});

// 12. Exams
export const exams = sqliteTable('exams', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').notNull().references(() => courses.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  type: text('type').notNull().default('UTS'), // UTS | UAS | QUIZ | OTHER
  examAt: integer('exam_at').notNull(),
  location: text('location'),
  notes: text('notes'),
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});

// 13. Exam Topics
export const examTopics = sqliteTable('exam_topics', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  examId: text('exam_id').notNull().references(() => exams.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  completed: integer('completed', { mode: 'boolean' }).notNull().default(false),
  orderIndex: integer('order_index').notNull().default(0),
});

// 14. Attendance
export const attendance = sqliteTable('attendance', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').notNull().references(() => courses.id, { onDelete: 'cascade' }),
  classDate: text('class_date').notNull(), // YYYY-MM-DD
  status: text('status').notNull().default('PRESENT'), // PRESENT | PERMIT | SICK | ABSENT
  notes: text('notes'),
  createdAt: integer('created_at').notNull(),
});

// 15. Grades
export const grades = sqliteTable('grades', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').notNull().references(() => courses.id, { onDelete: 'cascade' }),
  componentName: text('component_name').notNull(), // e.g., Tugas 1, UTS, UAS
  weight: integer('weight'), // Percentage weight
  score: integer('score'), // Score out of 100
  letterGrade: text('letter_grade'), // A, B+, B, etc.
  gradePoint: integer('grade_point'), // 400 = 4.0, 350 = 3.5 multiplied by 100
  createdAt: integer('created_at').notNull(),
  updatedAt: integer('updated_at').notNull(),
});

// 16. Files
export const files = sqliteTable('files', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').references(() => courses.id, { onDelete: 'set null' }),
  driveFileId: text('drive_file_id').notNull(),
  driveParentFolderId: text('drive_parent_folder_id'),
  name: text('name').notNull(),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  category: text('category').notNull().default('other'), // assignment | note | reading | course_material | other
  createdAt: integer('created_at').notNull(),
  deletedAt: integer('deleted_at'),
}, (table) => [
  index('idx_files_user').on(table.userId),
]);

// 17. Push Subscriptions
export const pushSubscriptions = sqliteTable('push_subscriptions', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  endpoint: text('endpoint').notNull().unique(),
  p256dh: text('p256dh').notNull(),
  auth: text('auth').notNull(),
  createdAt: integer('created_at').notNull(),
  lastUsedAt: integer('last_seen_at').notNull(),
}, (table) => [
  uniqueIndex('idx_push_sub_endpoint').on(table.endpoint),
  index('idx_push_sub_user').on(table.userId),
]);

// 18. Notification Deliveries (Idempotency)
export const notificationDeliveries = sqliteTable('notification_deliveries', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  entityType: text('entity_type').notNull(), // class | task | exam
  entityId: text('entity_id').notNull(),
  occurrenceAt: text('occurrence_at').notNull(), // string timestamp key
  offsetMinutes: integer('offset_minutes').notNull(),
  channel: text('channel').notNull().default('push'),
  status: text('status').notNull().default('SENT'),
  sentAt: integer('sent_at').notNull(),
}, (table) => [
  uniqueIndex('idx_notif_deliv_dedupe').on(table.userId, table.entityType, table.entityId, table.occurrenceAt, table.offsetMinutes),
]);

// 19. Legal Bookmarks
export const legalBookmarks = sqliteTable('legal_bookmarks', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: text('course_id').references(() => courses.id, { onDelete: 'set null' }),
  frbrUri: text('frbr_uri').notNull(),
  title: text('title').notNull(),
  type: text('type'),
  number: text('number'),
  year: text('year'),
  userNote: text('user_note'),
  createdAt: integer('created_at').notNull(),
});

// 20. AI Usage Tracking
export const aiUsage = sqliteTable('ai_usage', {
  id: text('id').primaryKey(),
  userId: text('user_id'),
  provider: text('provider').notNull(), // groq | ollama | minimax
  accountSlot: integer('account_slot').notNull().default(1),
  model: text('model').notNull(),
  requestType: text('request_type').notNull(), // quick_capture | breakdown | smart_deadline | insight | legal
  status: text('status').notNull(), // success | failure | fallback
  httpStatus: integer('http_status'),
  inputTokens: integer('input_tokens'),
  outputTokens: integer('output_tokens'),
  latencyMs: integer('latency_ms'),
  errorClass: text('error_class'),
  createdAt: integer('created_at').notNull(),
}, (table) => [
  index('idx_ai_usage_created').on(table.createdAt),
]);

// 21. Rate Limits
export const authRateLimits = sqliteTable('auth_rate_limits', {
  keyHash: text('key_hash').primaryKey(),
  windowStart: integer('window_start').notNull(),
  attemptCount: integer('attempt_count').notNull(),
  blockedUntil: integer('blocked_until'),
});

// 22. App Config
export const appConfig = sqliteTable('app_config', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  updatedAt: integer('updated_at').notNull(),
});
