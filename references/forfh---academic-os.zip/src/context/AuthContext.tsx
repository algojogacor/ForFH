import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserSettings } from '../types';

interface AuthContextType {
  user: User | null;
  settings: UserSettings | null;
  loading: boolean;
  isAuthenticated: boolean;
  login: (data: { user: User; settings?: UserSettings }) => void;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setSettings(data.settings);
      } else {
        setUser(null);
        setSettings(null);
      }
    } catch (e) {
      setUser(null);
      setSettings(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = (data: { user: User; settings?: UserSettings }) => {
    setUser(data.user);
    if (data.settings) setSettings(data.settings);
    else refreshUser();
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {}
    setUser(null);
    setSettings(null);
  };

  return (
    <AuthContext.Provider value={{ user, settings, loading, isAuthenticated: Boolean(user), login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
