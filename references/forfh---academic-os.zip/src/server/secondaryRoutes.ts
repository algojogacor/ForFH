import { Router } from 'express';
import { requireAuth } from './authRoutes';
import { db } from '../db/client';
import { exams, examTopics, readings, attendance, grades, courses, tasks, notes, legalBookmarks } from '../db/schema';
import { eq, and, isNull, desc, like, or } from 'drizzle-orm';
import crypto from 'node:crypto';

export const secondaryRouter = Router();
secondaryRouter.use(requireAuth);

// ------------------------------------
// EXAMS & EXAM MODE
// ------------------------------------
secondaryRouter.get('/exams', async (req: any, res) => {
  const userId = req.user.userId;

  const userExams = await db
    .select({
      id: exams.id,
      userId: exams.userId,
      courseId: exams.courseId,
      courseName: courses.name,
      courseColor: courses.color,
      name: exams.name,
      type: exams.type,
      examAt: exams.examAt,
      location: exams.location,
      notes: exams.notes,
      createdAt: exams.createdAt,
    })
    .from(exams)
    .innerJoin(courses, eq(exams.courseId, courses.id))
    .where(eq(exams.userId, userId))
    .orderBy(exams.examAt);

  const userTopics = await db.select().from(examTopics).where(eq(examTopics.userId, userId));

  const topicsByExamId: Record<string, any[]> = {};
  for (const t of userTopics) {
    if (!topicsByExamId[t.examId]) topicsByExamId[t.examId] = [];
    topicsByExamId[t.examId].push(t);
  }

  const result = userExams.map((e) => ({
    ...e,
    topics: topicsByExamId[e.id] || [],
  }));

  return res.json(result);
});

secondaryRouter.post('/exams', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, name, type, examAt, location, notes, topics: initialTopics } = req.body;

  if (!courseId || !name || !examAt) {
    return res.status(400).json({ error: 'Mata kuliah, nama ujian, dan tanggal ujian wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(exams).values({
    id,
    userId,
    courseId,
    name: name.trim(),
    type: type || 'UTS',
    examAt: Number(examAt),
    location: location?.trim() || null,
    notes: notes?.trim() || null,
    createdAt: now,
    updatedAt: now,
  });

  if (Array.isArray(initialTopics)) {
    for (let i = 0; i < initialTopics.length; i++) {
      const topTitle = typeof initialTopics[i] === 'string' ? initialTopics[i] : initialTopics[i].title;
      if (topTitle) {
        await db.insert(examTopics).values({
          id: crypto.randomUUID(),
          userId,
          examId: id,
          title: topTitle.trim(),
          completed: false,
          orderIndex: i,
        });
      }
    }
  }

  const [exam] = await db.select().from(exams).where(and(eq(exams.id, id), eq(exams.userId, userId)));
  const createdTopics = await db.select().from(examTopics).where(and(eq(examTopics.examId, id), eq(examTopics.userId, userId)));

  return res.json({ ...exam, topics: createdTopics });
});

secondaryRouter.put('/exam-topics/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { completed } = req.body;

  await db.update(examTopics).set({
    completed: Boolean(completed),
  }).where(and(eq(examTopics.id, id), eq(examTopics.userId, userId)));

  const [updated] = await db.select().from(examTopics).where(and(eq(examTopics.id, id), eq(examTopics.userId, userId)));
  return res.json(updated);
});

secondaryRouter.delete('/exams/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;

  await db.delete(exams).where(and(eq(exams.id, id), eq(exams.userId, userId)));
  return res.json({ message: 'Ujian berhasil dihapus.' });
});

// ------------------------------------
// READINGS TRACKER
// ------------------------------------
secondaryRouter.get('/readings', async (req: any, res) => {
  const userId = req.user.userId;

  const list = await db
    .select({
      id: readings.id,
      userId: readings.userId,
      courseId: readings.courseId,
      courseName: courses.name,
      type: readings.type,
      title: readings.title,
      author: readings.author,
      sourceUrl: readings.sourceUrl,
      startPage: readings.startPage,
      endPage: readings.endPage,
      currentPage: readings.currentPage,
      status: readings.status,
      deadline: readings.deadline,
      notes: readings.notes,
      createdAt: readings.createdAt,
    })
    .from(readings)
    .leftJoin(courses, eq(readings.courseId, courses.id))
    .where(eq(readings.userId, userId))
    .orderBy(desc(readings.createdAt));

  return res.json(list);
});

secondaryRouter.post('/readings', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, title, type, author, sourceUrl, startPage, endPage, currentPage, status, deadline, notes } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Judul bahan bacaan wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(readings).values({
    id,
    userId,
    courseId: courseId || null,
    title: title.trim(),
    type: type || 'book',
    author: author?.trim() || null,
    sourceUrl: sourceUrl?.trim() || null,
    startPage: startPage ? Number(startPage) : null,
    endPage: endPage ? Number(endPage) : null,
    currentPage: currentPage ? Number(currentPage) : 0,
    status: status || 'NOT_STARTED',
    deadline: deadline ? Number(deadline) : null,
    notes: notes?.trim() || null,
    createdAt: now,
    updatedAt: now,
  });

  const [created] = await db.select().from(readings).where(and(eq(readings.id, id), eq(readings.userId, userId)));
  return res.json(created);
});

secondaryRouter.put('/readings/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { currentPage, status, notes } = req.body;

  const now = Date.now();

  await db.update(readings).set({
    currentPage: currentPage !== undefined ? Number(currentPage) : undefined,
    status: status || undefined,
    notes: notes !== undefined ? notes.trim() : undefined,
    updatedAt: now,
  }).where(and(eq(readings.id, id), eq(readings.userId, userId)));

  const [updated] = await db.select().from(readings).where(and(eq(readings.id, id), eq(readings.userId, userId)));
  return res.json(updated);
});

secondaryRouter.delete('/readings/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  await db.delete(readings).where(and(eq(readings.id, id), eq(readings.userId, userId)));
  return res.json({ message: 'Bahan bacaan berhasil dihapus.' });
});

// ------------------------------------
// ATTENDANCE
// ------------------------------------
secondaryRouter.get('/attendance', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select({
      id: attendance.id,
      courseId: attendance.courseId,
      courseName: courses.name,
      classDate: attendance.classDate,
      status: attendance.status,
      notes: attendance.notes,
    })
    .from(attendance)
    .innerJoin(courses, eq(attendance.courseId, courses.id))
    .where(eq(attendance.userId, userId))
    .orderBy(desc(attendance.classDate));

  return res.json(list);
});

secondaryRouter.post('/attendance', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, classDate, status, notes } = req.body;

  if (!courseId || !classDate || !status) {
    return res.status(400).json({ error: 'Mata kuliah, tanggal, dan status kehadiran wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(attendance).values({
    id,
    userId,
    courseId,
    classDate,
    status,
    notes: notes?.trim() || null,
    createdAt: now,
  });

  const [record] = await db.select().from(attendance).where(and(eq(attendance.id, id), eq(attendance.userId, userId)));
  return res.json(record);
});

// ------------------------------------
// GRADES & GPA SIMULATION
// ------------------------------------
secondaryRouter.get('/grades', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select({
      id: grades.id,
      courseId: grades.courseId,
      courseName: courses.name,
      courseCredits: courses.credits,
      componentName: grades.componentName,
      weight: grades.weight,
      score: grades.score,
      letterGrade: grades.letterGrade,
      gradePoint: grades.gradePoint,
    })
    .from(grades)
    .innerJoin(courses, eq(courses.id, grades.courseId))
    .where(eq(grades.userId, userId))
    .orderBy(desc(grades.createdAt));

  return res.json(list);
});

secondaryRouter.post('/grades', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, componentName, weight, score, letterGrade, gradePoint } = req.body;

  if (!courseId || !componentName) {
    return res.status(400).json({ error: 'Mata kuliah dan komponen nilai wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(grades).values({
    id,
    userId,
    courseId,
    componentName: componentName.trim(),
    weight: weight ? Number(weight) : null,
    score: score ? Number(score) : null,
    letterGrade: letterGrade?.trim() || null,
    gradePoint: gradePoint ? Number(gradePoint) : null,
    createdAt: now,
    updatedAt: now,
  });

  const [grade] = await db.select().from(grades).where(and(eq(grades.id, id), eq(grades.userId, userId)));
  return res.json(grade);
});

// ------------------------------------
// UNIVERSAL SEARCH
// ------------------------------------
secondaryRouter.get('/search', async (req: any, res) => {
  const userId = req.user.userId;
  const { q } = req.query;

  if (!q || !q.toString().trim()) {
    return res.json({ courses: [], tasks: [], notes: [], readings: [], bookmarks: [] });
  }

  const queryStr = `%${q.toString().trim()}%`;

  const foundCourses = await db.select().from(courses).where(and(eq(courses.userId, userId), like(courses.name, queryStr)));
  const foundTasks = await db.select().from(tasks).where(and(eq(tasks.userId, userId), isNull(tasks.deletedAt), or(like(tasks.title, queryStr), like(tasks.description, queryStr))));
  const foundNotes = await db.select().from(notes).where(and(eq(notes.userId, userId), isNull(notes.deletedAt), or(like(notes.title, queryStr), like(notes.content, queryStr))));
  const foundReadings = await db.select().from(readings).where(and(eq(readings.userId, userId), like(readings.title, queryStr)));
  const foundBookmarks = await db.select().from(legalBookmarks).where(and(eq(legalBookmarks.userId, userId), like(legalBookmarks.title, queryStr)));

  return res.json({
    courses: foundCourses,
    tasks: foundTasks,
    notes: foundNotes,
    readings: foundReadings,
    bookmarks: foundBookmarks,
  });
});
