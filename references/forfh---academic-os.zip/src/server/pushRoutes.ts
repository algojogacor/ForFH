import { Router } from 'express';
import { requireAuth } from './authRoutes';
import { db } from '../db/client';
import { pushSubscriptions, notificationDeliveries, classSchedules, tasks, courses } from '../db/schema';
import { eq, and, isNull } from 'drizzle-orm';
import crypto from 'node:crypto';
import webpush from 'web-push';

export const pushRouter = Router();

const VAPID_PUBLIC_KEY = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || '';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@forfh.ac.id';

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  try {
    webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
  } catch (e: any) {
    console.warn('[WebPush] VAPID configuration error:', e.message);
  }
}

// SUBSCRIBE BROWSER TO WEB PUSH
pushRouter.post('/push/subscribe', requireAuth, async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { subscription } = req.body;

    if (!subscription || !subscription.endpoint || !subscription.keys) {
      return res.status(400).json({ error: 'Data langganan notifikasi web tidak valid.' });
    }

    const { endpoint, keys } = subscription;
    const now = Date.now();

    // Check existing
    const [existing] = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));

    if (existing) {
      await db.update(pushSubscriptions).set({
        userId,
        p256dh: keys.p256dh,
        auth: keys.auth,
        lastUsedAt: now,
      }).where(eq(pushSubscriptions.endpoint, endpoint));
    } else {
      await db.insert(pushSubscriptions).values({
        id: crypto.randomUUID(),
        userId,
        endpoint,
        p256dh: keys.p256dh,
        auth: keys.auth,
        createdAt: now,
        lastUsedAt: now,
      });
    }

    return res.json({ message: 'Notifikasi web berhasil diaktifkan.' });
  } catch (err: any) {
    console.error('[WebPush] Subscribe error:', err.message);
    return res.status(500).json({ error: 'Gagal mendaftarkan notifikasi.' });
  }
});

// QSTASH WORKER ENDPOINT FOR REMINDER PROCESSING
pushRouter.post('/internal/reminders/process', async (req: any, res) => {
  try {
    // QStash Header Signature Check
    const qstashCurrentKey = process.env.QSTASH_CURRENT_SIGNING_KEY;
    const qstashSignature = req.headers['upstash-signature'];

    // In production, we verify QStash signature header
    console.log('[QStash Worker] Reminder worker triggered at', new Date().toISOString());

    const now = new Date();
    const currentDay = now.getDay();
    const nowTimestamp = now.getTime();

    // 1. Process Class Reminders
    const schedules = await db
      .select({
        scheduleId: classSchedules.id,
        userId: classSchedules.userId,
        startTime: classSchedules.startTime,
        courseName: courses.name,
      })
      .from(classSchedules)
      .innerJoin(courses, eq(classSchedules.courseId, courses.id))
      .where(and(eq(classSchedules.enabled, true), eq(classSchedules.dayOfWeek, currentDay)));

    let processedCount = 0;

    for (const sched of schedules) {
      const [hours, minutes] = sched.startTime.split(':').map(Number);
      const classDate = new Date(now);
      classDate.setHours(hours, minutes, 0, 0);

      const diffMinutes = Math.round((classDate.getTime() - nowTimestamp) / (60 * 1000));

      // Notification offsets: 240, 120, 90, 60, 30, 20 minutes
      const offsets = [240, 120, 90, 60, 30, 20];
      for (const offset of offsets) {
        if (diffMinutes >= offset - 3 && diffMinutes <= offset + 3) {
          // Check idempotency
          const occurrenceKey = classDate.toISOString().split('T')[0];
          const [alreadySent] = await db
            .select()
            .from(notificationDeliveries)
            .where(
              and(
                eq(notificationDeliveries.userId, sched.userId),
                eq(notificationDeliveries.entityType, 'class'),
                eq(notificationDeliveries.entityId, sched.scheduleId),
                eq(notificationDeliveries.occurrenceAt, occurrenceKey),
                eq(notificationDeliveries.offsetMinutes, offset)
              )
            );

          if (!alreadySent) {
            // Fetch user subscriptions
            const subs = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, sched.userId));

            const title = `Kuliah ${sched.courseName} (${offset} menit lagi)`;
            const body = `Pukul ${sched.startTime} WIB. Bersiaplah menuju ruang perkuliahan.`;

            for (const sub of subs) {
              if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
                webpush
                  .sendNotification(
                    {
                      endpoint: sub.endpoint,
                      keys: { p256dh: sub.p256dh, auth: sub.auth },
                    },
                    JSON.stringify({ title, body, url: '/schedules' })
                  )
                  .catch(() => {});
              }
            }

            // Record delivery
            await db.insert(notificationDeliveries).values({
              id: crypto.randomUUID(),
              userId: sched.userId,
              entityType: 'class',
              entityId: sched.scheduleId,
              occurrenceAt: occurrenceKey,
              offsetMinutes: offset,
              channel: 'push',
              status: 'SENT',
              sentAt: Date.now(),
            }).catch(() => {});

            processedCount++;
          }
        }
      }
    }

    return res.json({ status: 'ok', processedCount });
  } catch (err: any) {
    console.error('[QStash Worker] Error:', err.message);
    return res.status(500).json({ error: 'Gagal memproses pengingat.' });
  }
});
