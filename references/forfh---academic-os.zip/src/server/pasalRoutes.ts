import { Router } from 'express';
import { requireAuth } from './authRoutes';
import { db } from '../db/client';
import { legalBookmarks } from '../db/schema';
import { eq, and, desc } from 'drizzle-orm';
import crypto from 'node:crypto';
import { executeAIRequest } from '../lib/ai/router';

export const pasalRouter = Router();
pasalRouter.use(requireAuth);

const PASAL_BASE_URL = process.env.PASAL_API_BASE_URL || 'https://pasal.id/api/v1';
const PASAL_TOKEN = process.env.PASAL_API_TOKEN || '';

// Helper for Pasal.id API fetch
async function pasalFetch(path: string, queryParams: Record<string, string> = {}) {
  const url = new URL(`${PASAL_BASE_URL}${path.startsWith('/') ? path : '/' + path}`);
  for (const [k, v] of Object.entries(queryParams)) {
    if (v !== undefined && v !== null && v !== '') {
      url.searchParams.append(k, v);
    }
  }

  const res = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${PASAL_TOKEN}`,
      Accept: 'application/json',
    },
  });

  if (!res.ok) {
    throw new Error(`Pasal.id API HTTP ${res.status}`);
  }

  return res.json();
}

// 1. SEARCH LEGAL REGULATIONS
pasalRouter.get('/pasal/search', async (req: any, res) => {
  try {
    const { q, type, limit } = req.query;

    if (!q || !q.toString().trim()) {
      return res.status(400).json({ error: 'Kata kunci pencarian hukum (q) wajib diisi.' });
    }

    const data = await pasalFetch('/search', {
      q: q.toString().trim(),
      type: type?.toString() || '',
      limit: limit?.toString() || '15',
    });

    return res.json(data);
  } catch (err: any) {
    console.error('[Pasal.id] Search error:', err.message);
    return res.status(500).json({ error: 'Gagal mencari peraturan pada database Pasal.id.' });
  }
});

// 2. GET LAW DETAIL BY FRBR URI
pasalRouter.get('/pasal/law/*', async (req: any, res) => {
  try {
    // Extract frbr_uri from params
    const rawPath = req.params[0] || '';
    if (!rawPath) {
      return res.status(400).json({ error: 'FRBR URI peraturan wajib diisi.' });
    }

    const cleanUri = rawPath.replace(/^\//, '');
    const data = await pasalFetch(`/laws/${cleanUri}`);

    return res.json(data);
  } catch (err: any) {
    console.error('[Pasal.id] Detail error:', err.message);
    return res.status(500).json({ error: 'Gagal mengambil rincian pasal/peraturan.' });
  }
});

// 3. LEGAL BOOKMARKS
pasalRouter.get('/pasal/bookmarks', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select()
    .from(legalBookmarks)
    .where(eq(legalBookmarks.userId, userId))
    .orderBy(desc(legalBookmarks.createdAt));
  return res.json(list);
});

pasalRouter.post('/pasal/bookmarks', async (req: any, res) => {
  const userId = req.user.userId;
  const { frbrUri, title, type, number, year, courseId, userNote } = req.body;

  if (!frbrUri || !title) {
    return res.status(400).json({ error: 'FRBR URI dan judul wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(legalBookmarks).values({
    id,
    userId,
    courseId: courseId || null,
    frbrUri,
    title: title.trim(),
    type: type || null,
    number: number || null,
    year: year || null,
    userNote: userNote?.trim() || null,
    createdAt: now,
  });

  const [bookmark] = await db.select().from(legalBookmarks).where(and(eq(legalBookmarks.id, id), eq(legalBookmarks.userId, userId)));
  return res.json(bookmark);
});

pasalRouter.delete('/pasal/bookmarks/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  await db.delete(legalBookmarks).where(and(eq(legalBookmarks.id, id), eq(legalBookmarks.userId, userId)));
  return res.json({ message: 'Bookmark hukum berhasil dihapus.' });
});

// 4. AI GROUNDED LEGAL EXPLANATION
pasalRouter.post('/ai/legal-explain', async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { query, frbrUri } = req.body;

    if (!query) {
      return res.status(400).json({ error: 'Pertanyaan hukum wajib diisi.' });
    }

    let legalContext = 'Tidak ada peraturan spesifik yang dilampirkan.';

    // Fetch law detail if frbrUri provided
    if (frbrUri) {
      try {
        const cleanUri = frbrUri.replace(/^\//, '');
        const detailData = await pasalFetch(`/laws/${cleanUri}`);
        legalContext = `Peraturan: ${detailData.work?.title || detailData.title || cleanUri}.
Status: ${detailData.status || detailData.work?.status || 'berlaku'}.
Isi/Pasal Ringkasan:
${JSON.stringify(detailData.articles?.slice(0, 10) || detailData.detail || 'Terlampir')}`;
      } catch (err: any) {
        console.warn('[Pasal AI] Failed to fetch context:', err.message);
      }
    }

    const systemPrompt = `Kamu adalah dosen pengampu dan pakar ilmu hukum Indonesia.
Jelaskan pertanyaan hukum mahasiswa secara akademis, sistematis, dan mudah dipahami dalam bahasa Indonesia.

PENTING:
Gunakan data resmi dari Pasal.id yang diberikan sebagai konteks utama. Jangan mengarang nomor pasal jika tidak ada pada konteks.
Pemberitahuan: Penjelasan ini bertujuan untuk bantuan studi akademik, bukan nasihat hukum profesional.

Konteks Peraturan Resmi:
${legalContext}`;

    const aiRes = await executeAIRequest(userId, 'legal', systemPrompt, query, false);

    return res.json({
      explanation: aiRes?.text || 'Penjelasan AI tidak dapat dimuat saat ini. Silakan periksa rincian peraturan secara langsung.',
    });
  } catch (err: any) {
    console.error('[Pasal AI] Explain error:', err.message);
    return res.status(500).json({ error: 'Gagal memproses penjelasan hukum.' });
  }
});
