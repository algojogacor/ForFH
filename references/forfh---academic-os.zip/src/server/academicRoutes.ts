import { Router } from 'express';
import { db } from '../db/client';
import { academicTerms, courses, classSchedules } from '../db/schema';
import { eq, and, desc } from 'drizzle-orm';
import crypto from 'node:crypto';
import { requireAuth } from './authRoutes';

export const academicRouter = Router();
academicRouter.use(requireAuth);

// ------------------------------------
// ACADEMIC TERMS (SEMESTERS)
// ------------------------------------
academicRouter.get('/terms', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select()
    .from(academicTerms)
    .where(eq(academicTerms.userId, userId))
    .orderBy(desc(academicTerms.createdAt));
  return res.json(list);
});

academicRouter.post('/terms', async (req: any, res) => {
  const userId = req.user.userId;
  const { name, startDate, endDate, isActive } = req.body;

  if (!name || !startDate || !endDate) {
    return res.status(400).json({ error: 'Nama semester, tanggal mulai, dan selesai wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  if (isActive) {
    // Set other terms isActive = false
    await db.update(academicTerms).set({ isActive: false }).where(eq(academicTerms.userId, userId));
  }

  await db.insert(academicTerms).values({
    id,
    userId,
    name: name.trim(),
    startDate,
    endDate,
    isActive: isActive !== undefined ? Boolean(isActive) : true,
    createdAt: now,
    updatedAt: now,
  });

  const [term] = await db.select().from(academicTerms).where(and(eq(academicTerms.id, id), eq(academicTerms.userId, userId)));
  return res.json(term);
});

academicRouter.put('/terms/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { name, startDate, endDate, isActive } = req.body;

  const now = Date.now();
  if (isActive) {
    await db.update(academicTerms).set({ isActive: false }).where(eq(academicTerms.userId, userId));
  }

  await db.update(academicTerms).set({
    name: name?.trim(),
    startDate,
    endDate,
    isActive: isActive !== undefined ? Boolean(isActive) : undefined,
    updatedAt: now,
  }).where(and(eq(academicTerms.id, id), eq(academicTerms.userId, userId)));

  const [updated] = await db.select().from(academicTerms).where(and(eq(academicTerms.id, id), eq(academicTerms.userId, userId)));
  return res.json(updated);
});

// ------------------------------------
// COURSES
// ------------------------------------
academicRouter.get('/courses', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select()
    .from(courses)
    .where(and(eq(courses.userId, userId), eq(courses.archived, false)))
    .orderBy(courses.name);
  return res.json(list);
});

academicRouter.post('/courses', async (req: any, res) => {
  const userId = req.user.userId;
  const { academicTermId, name, code, lecturer, credits, color, defaultRoom, onlineUrl, notes } = req.body;

  if (!name) {
    return res.status(400).json({ error: 'Nama mata kuliah wajib diisi.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(courses).values({
    id,
    userId,
    academicTermId: academicTermId || null,
    name: name.trim(),
    code: code?.trim() || null,
    lecturer: lecturer?.trim() || null,
    credits: credits ? Number(credits) : null,
    color: color || '#2563eb',
    defaultRoom: defaultRoom?.trim() || null,
    onlineUrl: onlineUrl?.trim() || null,
    notes: notes?.trim() || null,
    archived: false,
    createdAt: now,
    updatedAt: now,
  });

  const [course] = await db.select().from(courses).where(and(eq(courses.id, id), eq(courses.userId, userId)));
  return res.json(course);
});

academicRouter.put('/courses/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { academicTermId, name, code, lecturer, credits, color, defaultRoom, onlineUrl, notes, archived } = req.body;

  const now = Date.now();
  await db.update(courses).set({
    academicTermId: academicTermId || null,
    name: name?.trim(),
    code: code?.trim() || null,
    lecturer: lecturer?.trim() || null,
    credits: credits !== undefined ? Number(credits) : undefined,
    color,
    defaultRoom: defaultRoom?.trim() || null,
    onlineUrl: onlineUrl?.trim() || null,
    notes: notes?.trim() || null,
    archived: archived !== undefined ? Boolean(archived) : undefined,
    updatedAt: now,
  }).where(and(eq(courses.id, id), eq(courses.userId, userId)));

  const [updated] = await db.select().from(courses).where(and(eq(courses.id, id), eq(courses.userId, userId)));
  return res.json(updated);
});

academicRouter.delete('/courses/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  await db.delete(courses).where(and(eq(courses.id, id), eq(courses.userId, userId)));
  return res.json({ message: 'Mata kuliah berhasil dihapus.' });
});

// ------------------------------------
// CLASS SCHEDULES
// ------------------------------------
academicRouter.get('/schedules', async (req: any, res) => {
  const userId = req.user.userId;
  const list = await db
    .select({
      id: classSchedules.id,
      userId: classSchedules.userId,
      courseId: classSchedules.courseId,
      courseName: courses.name,
      courseColor: courses.color,
      dayOfWeek: classSchedules.dayOfWeek,
      startTime: classSchedules.startTime,
      endTime: classSchedules.endTime,
      room: classSchedules.room,
      onlineUrl: classSchedules.onlineUrl,
      enabled: classSchedules.enabled,
    })
    .from(classSchedules)
    .innerJoin(courses, eq(classSchedules.courseId, courses.id))
    .where(and(eq(classSchedules.userId, userId), eq(classSchedules.enabled, true)))
    .orderBy(classSchedules.dayOfWeek, classSchedules.startTime);

  return res.json(list);
});

academicRouter.post('/schedules', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, dayOfWeek, startTime, endTime, room, onlineUrl } = req.body;

  if (!courseId || dayOfWeek === undefined || !startTime || !endTime) {
    return res.status(400).json({ error: 'Mata kuliah, hari, jam mulai, dan jam selesai wajib diisi.' });
  }

  // Verify course ownership
  const [course] = await db.select().from(courses).where(and(eq(courses.id, courseId), eq(courses.userId, userId)));
  if (!course) {
    return res.status(404).json({ error: 'Mata kuliah tidak ditemukan.' });
  }

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(classSchedules).values({
    id,
    userId,
    courseId,
    dayOfWeek: Number(dayOfWeek),
    startTime,
    endTime,
    room: room?.trim() || course.defaultRoom || null,
    onlineUrl: onlineUrl?.trim() || course.onlineUrl || null,
    enabled: true,
    createdAt: now,
    updatedAt: now,
  });

  const [sched] = await db.select().from(classSchedules).where(and(eq(classSchedules.id, id), eq(classSchedules.userId, userId)));
  return res.json(sched);
});

academicRouter.put('/schedules/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { dayOfWeek, startTime, endTime, room, onlineUrl, enabled } = req.body;

  const now = Date.now();
  await db.update(classSchedules).set({
    dayOfWeek: dayOfWeek !== undefined ? Number(dayOfWeek) : undefined,
    startTime,
    endTime,
    room: room?.trim(),
    onlineUrl: onlineUrl?.trim(),
    enabled: enabled !== undefined ? Boolean(enabled) : undefined,
    updatedAt: now,
  }).where(and(eq(classSchedules.id, id), eq(classSchedules.userId, userId)));

  const [updated] = await db.select().from(classSchedules).where(and(eq(classSchedules.id, id), eq(classSchedules.userId, userId)));
  return res.json(updated);
});

academicRouter.delete('/schedules/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  await db.delete(classSchedules).where(and(eq(classSchedules.id, id), eq(classSchedules.userId, userId)));
  return res.json({ message: 'Jadwal kuliah berhasil dihapus.' });
});
