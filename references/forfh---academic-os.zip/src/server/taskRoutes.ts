import { Router } from 'express';
import { db } from '../db/client';
import { tasks, subtasks, courses, taskReminders } from '../db/schema';
import { eq, and, isNull, desc, asc } from 'drizzle-orm';
import crypto from 'node:crypto';
import { requireAuth } from './authRoutes';

export const taskRouter = Router();
taskRouter.use(requireAuth);

// GET ALL TASKS
taskRouter.get('/tasks', async (req: any, res) => {
  const userId = req.user.userId;

  const userTasks = await db
    .select({
      id: tasks.id,
      userId: tasks.userId,
      courseId: tasks.courseId,
      courseName: courses.name,
      courseColor: courses.color,
      title: tasks.title,
      description: tasks.description,
      type: tasks.type,
      dueAt: tasks.dueAt,
      internalTargetAt: tasks.internalTargetAt,
      priority: tasks.priority,
      estimatedMinutes: tasks.estimatedMinutes,
      status: tasks.status,
      progress: tasks.progress,
      source: tasks.source,
      createdAt: tasks.createdAt,
      updatedAt: tasks.updatedAt,
      completedAt: tasks.completedAt,
    })
    .from(tasks)
    .leftJoin(courses, eq(tasks.courseId, courses.id))
    .where(and(eq(tasks.userId, userId), isNull(tasks.deletedAt)))
    .orderBy(desc(tasks.createdAt));

  // Fetch subtasks for all tasks
  const userSubtasks = await db
    .select()
    .from(subtasks)
    .where(and(eq(subtasks.userId, userId), isNull(subtasks.deletedAt)))
    .orderBy(asc(subtasks.orderIndex));

  const subtasksByTaskId: Record<string, any[]> = {};
  for (const st of userSubtasks) {
    if (!subtasksByTaskId[st.taskId]) subtasksByTaskId[st.taskId] = [];
    subtasksByTaskId[st.taskId].push(st);
  }

  const result = userTasks.map((t) => ({
    ...t,
    subtasks: subtasksByTaskId[t.id] || [],
  }));

  return res.json(result);
});

// CREATE TASK
taskRouter.post('/tasks', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, title, description, type, dueAt, internalTargetAt, priority, estimatedMinutes, subtasks: initialSubtasks, source } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Judul tugas wajib diisi.' });
  }

  const taskId = crypto.randomUUID();
  const now = Date.now();

  await db.insert(tasks).values({
    id: taskId,
    userId,
    courseId: courseId || null,
    title: title.trim(),
    description: description?.trim() || null,
    type: type || 'assignment',
    dueAt: dueAt ? Number(dueAt) : null,
    internalTargetAt: internalTargetAt ? Number(internalTargetAt) : null,
    priority: priority || 'medium',
    estimatedMinutes: estimatedMinutes ? Number(estimatedMinutes) : null,
    status: 'NOT_STARTED',
    progress: 0,
    source: source || 'manual',
    createdAt: now,
    updatedAt: now,
    version: 1,
  });

  // Create subtasks if provided
  if (Array.isArray(initialSubtasks) && initialSubtasks.length > 0) {
    for (let i = 0; i < initialSubtasks.length; i++) {
      const st = initialSubtasks[i];
      const stTitle = typeof st === 'string' ? st : st.title;
      if (stTitle) {
        await db.insert(subtasks).values({
          id: crypto.randomUUID(),
          userId,
          taskId,
          title: stTitle.trim(),
          completed: false,
          orderIndex: i,
          createdAt: now,
          updatedAt: now,
        });
      }
    }
  }

  const [created] = await db.select().from(tasks).where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)));
  const createdSubtasks = await db.select().from(subtasks).where(and(eq(subtasks.taskId, taskId), isNull(subtasks.deletedAt)));

  return res.json({
    ...created,
    subtasks: createdSubtasks,
  });
});

// UPDATE TASK
taskRouter.put('/tasks/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { courseId, title, description, type, dueAt, internalTargetAt, priority, estimatedMinutes, status, progress } = req.body;

  const now = Date.now();

  let completedAtVal = undefined;
  if (status === 'DONE') {
    completedAtVal = now;
  }

  await db.update(tasks).set({
    courseId: courseId !== undefined ? (courseId || null) : undefined,
    title: title?.trim(),
    description: description !== undefined ? (description?.trim() || null) : undefined,
    type,
    dueAt: dueAt !== undefined ? (dueAt ? Number(dueAt) : null) : undefined,
    internalTargetAt: internalTargetAt !== undefined ? (internalTargetAt ? Number(internalTargetAt) : null) : undefined,
    priority,
    estimatedMinutes: estimatedMinutes !== undefined ? (estimatedMinutes ? Number(estimatedMinutes) : null) : undefined,
    status,
    progress: progress !== undefined ? Number(progress) : undefined,
    completedAt: completedAtVal,
    updatedAt: now,
  }).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));

  const [updated] = await db.select().from(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
  const currentSubtasks = await db.select().from(subtasks).where(and(eq(subtasks.taskId, id), isNull(subtasks.deletedAt)));

  return res.json({
    ...updated,
    subtasks: currentSubtasks,
  });
});

// DELETE TASK (Soft Delete)
taskRouter.delete('/tasks/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const now = Date.now();

  await db.update(tasks).set({ deletedAt: now, updatedAt: now }).where(and(eq(tasks.id, id), eq(tasks.userId, userId)));
  return res.json({ message: 'Tugas berhasil dihapus.' });
});

// SUBTASKS: ADD TO TASK
taskRouter.post('/tasks/:id/subtasks', async (req: any, res) => {
  const userId = req.user.userId;
  const { id: taskId } = req.params;
  const { title } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Judul subtask wajib diisi.' });
  }

  // Verify task ownership
  const [task] = await db.select().from(tasks).where(and(eq(tasks.id, taskId), eq(tasks.userId, userId)));
  if (!task) return res.status(404).json({ error: 'Tugas tidak ditemukan.' });

  const now = Date.now();
  const stId = crypto.randomUUID();

  await db.insert(subtasks).values({
    id: stId,
    userId,
    taskId,
    title: title.trim(),
    completed: false,
    orderIndex: 99,
    createdAt: now,
    updatedAt: now,
  });

  const [newSubtask] = await db.select().from(subtasks).where(and(eq(subtasks.id, stId), eq(subtasks.userId, userId)));
  return res.json(newSubtask);
});

// SUBTASKS: TOGGLE / UPDATE
taskRouter.put('/subtasks/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { title, completed } = req.body;

  const now = Date.now();

  const [st] = await db.select().from(subtasks).where(and(eq(subtasks.id, id), eq(subtasks.userId, userId)));
  if (!st) return res.status(404).json({ error: 'Subtask tidak ditemukan.' });

  await db.update(subtasks).set({
    title: title !== undefined ? title.trim() : undefined,
    completed: completed !== undefined ? Boolean(completed) : undefined,
    updatedAt: now,
  }).where(and(eq(subtasks.id, id), eq(subtasks.userId, userId)));

  // Recalculate parent task progress
  const allSubtasks = await db.select().from(subtasks).where(and(eq(subtasks.taskId, st.taskId), isNull(subtasks.deletedAt)));
  if (allSubtasks.length > 0) {
    const completedCount = allSubtasks.filter((s) => s.id === id ? Boolean(completed) : s.completed).length;
    const progressPercent = Math.round((completedCount / allSubtasks.length) * 100);
    const newStatus = progressPercent === 100 ? 'DONE' : progressPercent > 0 ? 'IN_PROGRESS' : 'NOT_STARTED';

    await db.update(tasks).set({
      progress: progressPercent,
      status: newStatus,
      completedAt: newStatus === 'DONE' ? now : null,
      updatedAt: now,
    }).where(and(eq(tasks.id, st.taskId), eq(tasks.userId, userId)));
  }

  const [updatedSt] = await db.select().from(subtasks).where(and(eq(subtasks.id, id), eq(subtasks.userId, userId)));
  return res.json(updatedSt);
});

// SUBTASKS: DELETE
taskRouter.delete('/subtasks/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const now = Date.now();

  await db.update(subtasks).set({ deletedAt: now, updatedAt: now }).where(and(eq(subtasks.id, id), eq(subtasks.userId, userId)));
  return res.json({ message: 'Subtask dihapus.' });
});
