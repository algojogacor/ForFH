import { Router } from 'express';
import { db } from '../db/client';
import { users, userSettings, academicTerms } from '../db/schema';
import { eq } from 'drizzle-orm';
import crypto from 'node:crypto';
import { hashPassword, verifyPassword, createSession, getSessionUser, destroySession } from '../lib/auth';
import { checkRateLimit, clearRateLimit } from '../lib/rateLimit';
import { parseCookie, stringifySetCookie } from 'cookie';

export const authRouter = Router();

// Middleware to extract authenticated user
export async function authenticateUser(req: any, res: any, next: any) {
  const cookies = parseCookie(req.headers.cookie || '');
  const rawToken = cookies.forfh_session || cookies['__Host-forfh-session'];
  
  if (!rawToken) {
    req.user = null;
    return next();
  }

  const sessionUser = await getSessionUser(rawToken);
  req.user = sessionUser;
  next();
}

export function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ error: 'Sesi telah berakhir. Silakan login kembali.' });
  }
  next();
}

// REGISTER
authRouter.post('/register', async (req, res) => {
  try {
    const { username, password, confirmPassword, displayName } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username dan password wajib diisi.' });
    }

    if (username.length < 3 || username.length > 32) {
      return res.status(400).json({ error: 'Username harus antara 3 hingga 32 karakter.' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'Password minimal 8 karakter.' });
    }

    if (confirmPassword && password !== confirmPassword) {
      return res.status(400).json({ error: 'Konfirmasi password tidak cocok.' });
    }

    const usernameNormalized = username.trim().toLowerCase();

    // Check rate limit
    const ipKey = req.ip || 'unknown';
    const rateCheck = await checkRateLimit(`register:${ipKey}`, 10, 15 * 60 * 1000);
    if (!rateCheck.allowed) {
      return res.status(429).json({ error: 'Coba lagi nanti. Terlalu banyak percobaan pendaftaran.' });
    }

    // Check uniqueness
    const [existing] = await db.select().from(users).where(eq(users.usernameNormalized, usernameNormalized));
    if (existing) {
      return res.status(400).json({ error: 'Username sudah digunakan. Silakan pilih username lain.' });
    }

    const userId = crypto.randomUUID();
    const now = Date.now();
    const { hash, salt } = hashPassword(password);
    const passwordHashCombined = `${salt}:${hash}`;

    // 1. Insert User
    await db.insert(users).values({
      id: userId,
      username: username.trim(),
      usernameNormalized,
      passwordHash: passwordHashCombined,
      displayName: displayName?.trim() || username.trim(),
      createdAt: now,
      updatedAt: now,
    });

    // 2. Insert User Settings
    await db.insert(userSettings).values({
      id: crypto.randomUUID(),
      userId,
      timezone: 'Asia/Jakarta',
      locale: 'id-ID',
      theme: 'system',
      defaultTaskReminders: '10080,4320,1440,360,60',
      defaultClassReminders: '120,90,60,30,20',
      primaryClassAlertMinutes: 240,
      deadlineBufferMinutes: 1440,
      aiEnabled: true,
      storageUsedBytes: 0,
      storageQuotaBytes: 524288000, // 500MB
      createdAt: now,
      updatedAt: now,
    });

    // 3. Create initial Default Academic Term
    await db.insert(academicTerms).values({
      id: crypto.randomUUID(),
      userId,
      name: 'Semester 1 2026/2027',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      isActive: true,
      createdAt: now,
      updatedAt: now,
    });

    // 4. Create Session
    const { rawToken, expiresAt } = await createSession(userId);

    const isProd = process.env.NODE_ENV === 'production';
    const cookieHeader = stringifySetCookie({
      name: 'forfh_session',
      value: rawToken,
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 60 * 60,
    });

    res.setHeader('Set-Cookie', cookieHeader);
    return res.json({
      message: 'Pendaftaran berhasil.',
      user: {
        userId,
        username: username.trim(),
        displayName: displayName?.trim() || username.trim(),
      },
    });
  } catch (err: any) {
    console.error('[Auth] Register error:', err);
    return res.status(500).json({ error: 'Gagal mendaftar. Silakan coba lagi.' });
  }
});

// LOGIN
authRouter.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username dan password wajib diisi.' });
    }

    const usernameNormalized = username.trim().toLowerCase();

    // Check rate limit
    const rateCheck = await checkRateLimit(`login:${usernameNormalized}`, 5, 15 * 60 * 1000);
    if (!rateCheck.allowed) {
      return res.status(429).json({ error: 'Terlalu banyak percobaan gagal. Silakan coba lagi dalam beberapa menit.' });
    }

    const [user] = await db.select().from(users).where(eq(users.usernameNormalized, usernameNormalized));

    if (!user) {
      return res.status(400).json({ error: 'Username atau password salah.' });
    }

    const [salt, hash] = user.passwordHash.split(':');
    const isValid = verifyPassword(password, hash, salt);

    if (!isValid) {
      return res.status(400).json({ error: 'Username atau password salah.' });
    }

    await clearRateLimit(`login:${usernameNormalized}`);

    const { rawToken } = await createSession(user.id);

    const isProd = process.env.NODE_ENV === 'production';
    const cookieHeader = stringifySetCookie({
      name: 'forfh_session',
      value: rawToken,
      httpOnly: true,
      secure: isProd,
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 60 * 60,
    });

    res.setHeader('Set-Cookie', cookieHeader);
    return res.json({
      message: 'Login berhasil.',
      user: {
        userId: user.id,
        username: user.username,
        displayName: user.displayName || user.username,
      },
    });
  } catch (err: any) {
    console.error('[Auth] Login error:', err);
    return res.status(500).json({ error: 'Gagal login. Silakan coba lagi.' });
  }
});

// LOGOUT
authRouter.post('/logout', async (req, res) => {
  const cookies = parseCookie(req.headers.cookie || '');
  const rawToken = cookies.forfh_session || cookies['__Host-forfh-session'];
  if (rawToken) {
    await destroySession(rawToken);
  }

  const cookieHeader = stringifySetCookie({
    name: 'forfh_session',
    value: '',
    httpOnly: true,
    expires: new Date(0),
    path: '/',
  });

  res.setHeader('Set-Cookie', cookieHeader);
  return res.json({ message: 'Logout berhasil.' });
});

// ME (CURRENT USER & SETTINGS)
authRouter.get('/me', requireAuth, async (req: any, res) => {
  try {
    const userId = req.user.userId;

    const [user] = await db.select().from(users).where(eq(users.id, userId));
    const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));

    return res.json({
      user: {
        userId: user.id,
        username: user.username,
        displayName: user.displayName || user.username,
        createdAt: user.createdAt,
      },
      settings: settings || {
        timezone: 'Asia/Jakarta',
        locale: 'id-ID',
        theme: 'system',
        defaultTaskReminders: '10080,4320,1440,360,60',
        defaultClassReminders: '120,90,60,30,20',
        primaryClassAlertMinutes: 240,
        deadlineBufferMinutes: 1440,
        aiEnabled: true,
        storageUsedBytes: 0,
        storageQuotaBytes: 524288000,
      },
    });
  } catch (err: any) {
    console.error('[Auth] Me error:', err);
    return res.status(500).json({ error: 'Gagal mengambil data profil.' });
  }
});

// UPDATE SETTINGS
authRouter.put('/settings', requireAuth, async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { timezone, theme, defaultTaskReminders, defaultClassReminders, primaryClassAlertMinutes, deadlineBufferMinutes, aiEnabled, displayName } = req.body;

    const now = Date.now();

    if (displayName) {
      await db.update(users).set({ displayName: displayName.trim(), updatedAt: now }).where(eq(users.id, userId));
    }

    const updateFields: any = { updatedAt: now };
    if (timezone) updateFields.timezone = timezone;
    if (theme) updateFields.theme = theme;
    if (defaultTaskReminders !== undefined) updateFields.defaultTaskReminders = defaultTaskReminders;
    if (defaultClassReminders !== undefined) updateFields.defaultClassReminders = defaultClassReminders;
    if (primaryClassAlertMinutes !== undefined) updateFields.primaryClassAlertMinutes = Number(primaryClassAlertMinutes);
    if (deadlineBufferMinutes !== undefined) updateFields.deadlineBufferMinutes = Number(deadlineBufferMinutes);
    if (aiEnabled !== undefined) updateFields.aiEnabled = Boolean(aiEnabled);

    await db.update(userSettings).set(updateFields).where(eq(userSettings.userId, userId));

    const [updatedSettings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));

    return res.json({ message: 'Pengaturan berhasil diperbarui.', settings: updatedSettings });
  } catch (err: any) {
    console.error('[Auth] Settings error:', err);
    return res.status(500).json({ error: 'Gagal memperbarui pengaturan.' });
  }
});
