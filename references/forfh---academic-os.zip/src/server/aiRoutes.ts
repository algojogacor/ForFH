import { Router } from 'express';
import { executeAIRequest, cleanJsonOutput } from '../lib/ai/router';
import { requireAuth } from './authRoutes';
import { db } from '../db/client';
import { courses, tasks, classSchedules } from '../db/schema';
import { eq, and, isNull } from 'drizzle-orm';

export const aiRouter = Router();
aiRouter.use(requireAuth);

// 1. QUICK CAPTURE PARSER
aiRouter.post('/ai/quick-capture', async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { rawText } = req.body;

    if (!rawText || !rawText.trim()) {
      return res.status(400).json({ error: 'Teks input wajib diisi.' });
    }

    // Fetch user courses for course matching
    const userCourses = await db.select().from(courses).where(and(eq(courses.userId, userId), eq(courses.archived, false)));
    const courseNamesList = userCourses.map((c) => c.name).join(', ');

    const nowIso = new Date().toISOString();
    const currentDateStr = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    const systemPrompt = `Kamu adalah asisten pengurai tugas akademik mahasiswa Indonesia.
Tanggal dan waktu saat ini (WIB): ${currentDateStr} (${nowIso}).
Daftar mata kuliah mahasiswa: [${courseNamesList || 'Tidak ada mata kuliah terdaftar'}].

Instruksi:
Ekstrak informasi tugas dari teks bahasa Indonesia menjadi JSON murni tanpa markdown fence dengan atribut berikut:
{
  "title": "Judul tugas yang ringkas dan jelas",
  "courseName": "Nama mata kuliah yang paling cocok dari daftar di atas, atau null",
  "type": "assignment" | "essay" | "paper" | "presentation" | "reading" | "quiz" | "practice" | "administrative" | "other",
  "dueDateIso": "Format ISO8601 YYYY-MM-DDTHH:mm:ss jika ada tanggal/jam (misal 'besok jam 9 malam' = besok 21:00:00), atau null",
  "priority": "low" | "medium" | "high" | "urgent",
  "estimatedMinutes": estimasi menit angka bulat (misal 60),
  "description": "Catatan ringkas tambahan dari input"
}`;

    const aiRes = await executeAIRequest(userId, 'quick_capture', systemPrompt, rawText, true);

    if (!aiRes) {
      return res.json({
        fallback: true,
        proposed: {
          title: rawText.trim(),
          courseId: null,
          type: 'assignment',
          dueAt: null,
          priority: 'medium',
          estimatedMinutes: 60,
          description: '',
        },
        message: 'AI tidak dapat merespons saat ini. Data dasar dibuat otomatis.',
      });
    }

    const cleaned = cleanJsonOutput(aiRes.text);
    let parsed: any = {};
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = { title: rawText.trim() };
    }

    // Match courseId if courseName matched
    let matchedCourseId = null;
    if (parsed.courseName) {
      const match = userCourses.find((c) => c.name.toLowerCase().includes(parsed.courseName.toLowerCase()) || parsed.courseName.toLowerCase().includes(c.name.toLowerCase()));
      if (match) matchedCourseId = match.id;
    }

    let dueAtTimestamp = null;
    if (parsed.dueDateIso) {
      const d = new Date(parsed.dueDateIso);
      if (!isNaN(d.getTime())) dueAtTimestamp = d.getTime();
    }

    return res.json({
      fallback: false,
      proposed: {
        title: parsed.title || rawText.trim(),
        courseId: matchedCourseId,
        type: parsed.type || 'assignment',
        dueAt: dueAtTimestamp,
        priority: parsed.priority || 'medium',
        estimatedMinutes: parsed.estimatedMinutes || 60,
        description: parsed.description || '',
      },
    });
  } catch (err: any) {
    console.error('[AI] Quick Capture error:', err);
    return res.status(500).json({ error: 'Gagal mengurai teks tugas dengan AI.' });
  }
});

// 2. TASK BREAKDOWN
aiRouter.post('/ai/task-breakdown', async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { title, description } = req.body;

    if (!title) {
      return res.status(400).json({ error: 'Judul tugas wajib diisi.' });
    }

    const systemPrompt = `Kamu adalah pakar perencanaan akademik perguruan tinggi.
Hasilkan breakdown sub-langkah pengerjaan tugas dalam bahasa Indonesia yang konkret dan realistis.

Kembalikan JSON murni tanpa markdown fence dengan format:
{
  "subtasks": [
    { "title": "Langkah 1...", "estimatedMinutes": 30 },
    { "title": "Langkah 2...", "estimatedMinutes": 45 }
  ]
}`;

    const aiRes = await executeAIRequest(userId, 'breakdown', systemPrompt, `Tugas: ${title}. Deskripsi: ${description || '-'}`, true);

    if (!aiRes) {
      return res.json({
        subtasks: [
          { title: 'Persiapkan referensi & materi', estimatedMinutes: 30 },
          { title: 'Pahami instruksi dan buat draft awal', estimatedMinutes: 45 },
          { title: 'Selesaikan pengerjaan dan tinjau ulang', estimatedMinutes: 30 },
        ],
      });
    }

    const cleaned = cleanJsonOutput(aiRes.text);
    const parsed = JSON.parse(cleaned);
    return res.json(parsed);
  } catch (err: any) {
    console.error('[AI] Breakdown error:', err);
    return res.json({
      subtasks: [
        { title: 'Cari referensi', estimatedMinutes: 30 },
        { title: 'Kerjakan draft', estimatedMinutes: 60 },
        { title: 'Pemeriksaan akhir', estimatedMinutes: 30 },
      ],
    });
  }
});

// 3. SMART DEADLINE PLANNING
aiRouter.post('/ai/smart-deadline', async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { title, dueAt, estimatedMinutes } = req.body;

    if (!title || !dueAt) {
      return res.status(400).json({ error: 'Judul dan deadline tugas wajib diisi.' });
    }

    const dueDateStr = new Date(Number(dueAt)).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const systemPrompt = `Kamu adalah perencana target akademik pintar.
Buatkan rencana pengerjaan bertahap (milestone workplan) sebelum tanggal deadline agar mahasiswa tidak kewalahan di hari H.

Deadline tugas: ${dueDateStr}.
Estimasi waktu total: ${estimatedMinutes || 120} menit.

Kembalikan JSON murni tanpa markdown fence:
{
  "milestones": [
    { "title": "Target 1: Riset awal", "recommendedDaysBeforeDue": 3, "estimatedMinutes": 30 },
    { "title": "Target 2: Draf bagian utama", "recommendedDaysBeforeDue": 2, "estimatedMinutes": 60 },
    { "title": "Target 3: Finisihing & Revisi", "recommendedDaysBeforeDue": 1, "estimatedMinutes": 30 }
  ]
}`;

    const aiRes = await executeAIRequest(userId, 'smart_deadline', systemPrompt, `Tugas: ${title}`, true);

    if (!aiRes) {
      return res.json({
        milestones: [
          { title: 'Riset awal & kumpulkan referensi', recommendedDaysBeforeDue: 3, estimatedMinutes: 30 },
          { title: 'Tulis bagian utama', recommendedDaysBeforeDue: 2, estimatedMinutes: 60 },
          { title: 'Rapikan & pengecekan akhir', recommendedDaysBeforeDue: 1, estimatedMinutes: 30 },
        ],
      });
    }

    const cleaned = cleanJsonOutput(aiRes.text);
    const parsed = JSON.parse(cleaned);
    return res.json(parsed);
  } catch (err: any) {
    return res.json({
      milestones: [
        { title: 'Persiapan materi', recommendedDaysBeforeDue: 2, estimatedMinutes: 45 },
        { title: 'Pengerjaan utama', recommendedDaysBeforeDue: 1, estimatedMinutes: 60 },
      ],
    });
  }
});

// 4. TODAY AI INSIGHT FOR DASHBOARD
aiRouter.get('/ai/today-insight', async (req: any, res) => {
  try {
    const userId = req.user.userId;

    const userTasks = await db.select().from(tasks).where(and(eq(tasks.userId, userId), isNull(tasks.deletedAt)));
    const activeSchedules = await db.select().from(classSchedules).where(and(eq(classSchedules.userId, userId), eq(classSchedules.enabled, true)));

    const now = Date.now();
    const todayDay = new Date().getDay(); // 0 = Sun, 1 = Mon

    const todayClasses = activeSchedules.filter((s) => s.dayOfWeek === todayDay);
    const upcomingTasks = userTasks.filter((t) => t.status !== 'DONE' && t.dueAt && t.dueAt > now).sort((a, b) => (a.dueAt || 0) - (b.dueAt || 0));
    const overdueCount = userTasks.filter((t) => t.status !== 'DONE' && t.dueAt && t.dueAt < now).length;

    const summaryContext = `Hari ini ada ${todayClasses.length} kelas kuliah.
Jumlah tugas aktif mendatang: ${upcomingTasks.length}.
Jumlah tugas terlewat (overdue): ${overdueCount}.
Tugas paling dekat: ${upcomingTasks[0]?.title || 'Tidak ada'}.`;

    const systemPrompt = `Kamu adalah asisten penasihat akademik universitas Indonesia.
Berikan ringkasan arahan singkat (2 kalimat saja dalam bahasa Indonesia) yang sangat praktis dan memotivasi untuk pertanyaan "Sekarang aku harus ngapain?".
Jawab langsung dalam teks singkat tanpa awalan 'Tentu' atau kata pengantar.`;

    const aiRes = await executeAIRequest(userId, 'insight', systemPrompt, summaryContext, false);

    const defaultInsight = overdueCount > 0
      ? `Perhatikan ada ${overdueCount} tugas yang sudah melewati deadline. Mulai selesaikan yang paling penting lebih awal hari ini.`
      : upcomingTasks.length > 0
      ? `Fokus hari ini pada tugas ${upcomingTasks[0].title}. Selesaikan pengerjaan awal sebelum jadwal kuliah dimulai.`
      : `Jadwalmu hari ini cukup terkendali. Gunakan waktu luang untuk membaca materi perkuliahan pekan ini.`;

    return res.json({
      insight: aiRes?.text?.trim() || defaultInsight,
    });
  } catch (err: any) {
    return res.json({
      insight: 'Gunakan waktu hari ini untuk memeriksa jadwal kuliah dan menyelesaikan tugas dengan deadline terdekat.',
    });
  }
});
