import { Router } from 'express';
import { requireAuth } from './authRoutes';
import { db } from '../db/client';
import { files, userSettings, courses } from '../db/schema';
import { eq, and, isNull, desc } from 'drizzle-orm';
import crypto from 'node:crypto';

export const fileRouter = Router();
fileRouter.use(requireAuth);

const GOOGLE_CLIENT_ID = process.env.GOOGLE_DRIVE_CLIENT_ID || '';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_DRIVE_CLIENT_SECRET || '';
const GOOGLE_REFRESH_TOKEN = process.env.GOOGLE_DRIVE_REFRESH_TOKEN || '';

// Obtain short-lived Google OAuth Access Token
async function getGoogleAccessToken(): Promise<string | null> {
  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !GOOGLE_REFRESH_TOKEN) {
    console.warn('[Drive] Missing Google Drive credentials.');
    return null;
  }

  try {
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        refresh_token: GOOGLE_REFRESH_TOKEN,
        grant_type: 'refresh_token',
      }),
    });

    if (!res.ok) {
      console.error('[Drive] Refresh token failed HTTP', res.status);
      return null;
    }

    const data = await res.json();
    return data.access_token || null;
  } catch (err: any) {
    console.error('[Drive] Access token error:', err.message);
    return null;
  }
}

// 1. GET USER FILES LIST
fileRouter.get('/files', async (req: any, res) => {
  const userId = req.user.userId;

  const userFiles = await db
    .select({
      id: files.id,
      userId: files.userId,
      courseId: files.courseId,
      courseName: courses.name,
      driveFileId: files.driveFileId,
      name: files.name,
      mimeType: files.mimeType,
      sizeBytes: files.sizeBytes,
      category: files.category,
      createdAt: files.createdAt,
    })
    .from(files)
    .leftJoin(courses, eq(files.courseId, courses.id))
    .where(and(eq(files.userId, userId), isNull(files.deletedAt)))
    .orderBy(desc(files.createdAt));

  const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));

  return res.json({
    files: userFiles,
    storageUsedBytes: settings?.storageUsedBytes || 0,
    storageQuotaBytes: settings?.storageQuotaBytes || 524288000,
  });
});

// 2. CREATE RESUMABLE UPLOAD SESSION OR METADATA ENTRY
fileRouter.post('/files/upload-session', async (req: any, res) => {
  try {
    const userId = req.user.userId;
    const { name, mimeType, sizeBytes, category, courseId } = req.body;

    if (!name || !sizeBytes) {
      return res.status(400).json({ error: 'Nama file dan ukuran file (bytes) wajib diisi.' });
    }

    const sizeNum = Number(sizeBytes);

    // Check user quota
    const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    const currentUsed = settings?.storageUsedBytes || 0;
    const quota = settings?.storageQuotaBytes || 524288000;

    if (currentUsed + sizeNum > quota) {
      return res.status(400).json({ error: 'Kapasitas penyimpanan Google Drive Anda telah penuh.' });
    }

    const accessToken = await getGoogleAccessToken();

    if (!accessToken) {
      // Fallback virtual file metadata entry if Drive credentials not yet configured
      const fileId = crypto.randomUUID();
      const mockDriveId = `local_drive_${fileId}`;
      const now = Date.now();

      await db.insert(files).values({
        id: fileId,
        userId,
        courseId: courseId || null,
        driveFileId: mockDriveId,
        name: name.trim(),
        mimeType: mimeType || 'application/octet-stream',
        sizeBytes: sizeNum,
        category: category || 'other',
        createdAt: now,
      });

      await db.update(userSettings).set({ storageUsedBytes: currentUsed + sizeNum }).where(eq(userSettings.userId, userId));

      return res.json({
        fileId,
        driveFileId: mockDriveId,
        uploadUrl: null,
        message: 'File metadata berhasil didaftarkan.',
      });
    }

    // Google Drive Resumable Upload Session Creation
    const driveRes = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: `${userId}_${name.trim()}`,
        mimeType: mimeType || 'application/octet-stream',
      }),
    });

    if (!driveRes.ok) {
      throw new Error(`Google Drive API HTTP ${driveRes.status}`);
    }

    const uploadUrl = driveRes.headers.get('location');
    const fileId = crypto.randomUUID();
    const now = Date.now();

    await db.insert(files).values({
      id: fileId,
      userId,
      courseId: courseId || null,
      driveFileId: `pending_${fileId}`,
      name: name.trim(),
      mimeType: mimeType || 'application/octet-stream',
      sizeBytes: sizeNum,
      category: category || 'other',
      createdAt: now,
    });

    await db.update(userSettings).set({ storageUsedBytes: currentUsed + sizeNum }).where(eq(userSettings.userId, userId));

    return res.json({
      fileId,
      uploadUrl,
    });
  } catch (err: any) {
    console.error('[Drive Upload] Error:', err.message);
    return res.status(500).json({ error: 'Gagal membuat sesi unggah berkas.' });
  }
});

// 3. DELETE FILE METADATA
fileRouter.delete('/files/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const now = Date.now();

  const [file] = await db.select().from(files).where(and(eq(files.id, id), eq(files.userId, userId)));
  if (!file) {
    return res.status(404).json({ error: 'Berkas tidak ditemukan.' });
  }

  await db.update(files).set({ deletedAt: now }).where(and(eq(files.id, id), eq(files.userId, userId)));

  // Deduct storage
  const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
  if (settings) {
    const newUsed = Math.max(0, settings.storageUsedBytes - file.sizeBytes);
    await db.update(userSettings).set({ storageUsedBytes: newUsed }).where(eq(userSettings.userId, userId));
  }

  return res.json({ message: 'Berkas berhasil dihapus.' });
});
