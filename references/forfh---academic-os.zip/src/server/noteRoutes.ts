import { Router } from 'express';
import { db } from '../db/client';
import { notes, courses } from '../db/schema';
import { eq, and, isNull, desc } from 'drizzle-orm';
import crypto from 'node:crypto';
import { requireAuth } from './authRoutes';

export const noteRouter = Router();
noteRouter.use(requireAuth);

// GET ALL NOTES
noteRouter.get('/notes', async (req: any, res) => {
  const userId = req.user.userId;

  const list = await db
    .select({
      id: notes.id,
      userId: notes.userId,
      courseId: notes.courseId,
      courseName: courses.name,
      title: notes.title,
      content: notes.content,
      format: notes.format,
      pinned: notes.pinned,
      createdAt: notes.createdAt,
      updatedAt: notes.updatedAt,
    })
    .from(notes)
    .leftJoin(courses, eq(notes.courseId, courses.id))
    .where(and(eq(notes.userId, userId), isNull(notes.deletedAt)))
    .orderBy(desc(notes.pinned), desc(notes.updatedAt));

  return res.json(list);
});

// CREATE NOTE
noteRouter.post('/notes', async (req: any, res) => {
  const userId = req.user.userId;
  const { courseId, title, content, format, pinned } = req.body;

  const id = crypto.randomUUID();
  const now = Date.now();

  await db.insert(notes).values({
    id,
    userId,
    courseId: courseId || null,
    title: title?.trim() || 'Catatan Tanpa Judul',
    content: content || '',
    format: format || 'markdown',
    pinned: pinned !== undefined ? Boolean(pinned) : false,
    createdAt: now,
    updatedAt: now,
    version: 1,
  });

  const [note] = await db.select().from(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
  return res.json(note);
});

// UPDATE NOTE
noteRouter.put('/notes/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const { courseId, title, content, format, pinned } = req.body;

  const now = Date.now();

  await db.update(notes).set({
    courseId: courseId !== undefined ? (courseId || null) : undefined,
    title: title !== undefined ? title.trim() : undefined,
    content: content !== undefined ? content : undefined,
    format: format !== undefined ? format : undefined,
    pinned: pinned !== undefined ? Boolean(pinned) : undefined,
    updatedAt: now,
  }).where(and(eq(notes.id, id), eq(notes.userId, userId)));

  const [updated] = await db.select().from(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
  return res.json(updated);
});

// DELETE NOTE
noteRouter.delete('/notes/:id', async (req: any, res) => {
  const userId = req.user.userId;
  const { id } = req.params;
  const now = Date.now();

  await db.update(notes).set({ deletedAt: now, updatedAt: now }).where(and(eq(notes.id, id), eq(notes.userId, userId)));
  return res.json({ message: 'Catatan berhasil dihapus.' });
});
