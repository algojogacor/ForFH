export interface User {
  userId: string;
  username: string;
  displayName: string;
}

export interface UserSettings {
  timezone: string;
  locale: string;
  theme: 'system' | 'light' | 'dark';
  defaultTaskReminders: string;
  defaultClassReminders: string;
  primaryClassAlertMinutes: number;
  deadlineBufferMinutes: number;
  aiEnabled: boolean;
  storageUsedBytes: number;
  storageQuotaBytes: number;
}

export interface AcademicTerm {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

export interface Course {
  id: string;
  academicTermId?: string | null;
  name: string;
  code?: string | null;
  lecturer?: string | null;
  credits?: number | null;
  color?: string | null;
  defaultRoom?: string | null;
  onlineUrl?: string | null;
  notes?: string | null;
  archived?: boolean;
}

export interface ClassSchedule {
  id: string;
  courseId: string;
  courseName?: string;
  courseColor?: string;
  dayOfWeek: number; // 0=Sun, 1=Mon...
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  room?: string | null;
  onlineUrl?: string | null;
  enabled?: boolean;
}

export interface Subtask {
  id: string;
  taskId: string;
  title: string;
  completed: boolean;
  orderIndex: number;
  estimatedMinutes?: number | null;
}

export interface Task {
  id: string;
  courseId?: string | null;
  courseName?: string | null;
  courseColor?: string | null;
  title: string;
  description?: string | null;
  type: 'assignment' | 'essay' | 'paper' | 'presentation' | 'reading' | 'quiz' | 'practice' | 'administrative' | 'other';
  dueAt?: number | null;
  internalTargetAt?: number | null;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  estimatedMinutes?: number | null;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'REVISION' | 'DONE' | 'OVERDUE';
  progress: number;
  subtasks?: Subtask[];
  createdAt: number;
  completedAt?: number | null;
}

export interface Note {
  id: string;
  courseId?: string | null;
  courseName?: string | null;
  title: string;
  content: string;
  format: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface LegalBookmark {
  id: string;
  frbrUri: string;
  title: string;
  type?: string | null;
  number?: string | null;
  year?: string | null;
  userNote?: string | null;
  createdAt: number;
}

export interface ExamTopic {
  id: string;
  examId: string;
  title: string;
  completed: boolean;
  orderIndex: number;
}

export interface Exam {
  id: string;
  courseId: string;
  courseName?: string;
  courseColor?: string;
  name: string;
  type: 'UTS' | 'UAS' | 'QUIZ' | 'OTHER';
  examAt: number;
  location?: string | null;
  notes?: string | null;
  topics?: ExamTopic[];
}

export interface FileItem {
  id: string;
  courseId?: string | null;
  courseName?: string | null;
  driveFileId: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  category: string;
  createdAt: number;
}
