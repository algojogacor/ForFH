# ForFH System Architecture

## Core Tech Stack
- **Framework**: Next.js App Router / Express + Vite Fullstack Engine
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS
- **Database**: Turso / libSQL
- **ORM**: Drizzle ORM
- **Authentication**: Username + Password (scrypt hashing, session tokens, HttpOnly cookies)
- **AI Routing**: Multi-slot Groq & Ollama Cloud router with circuit breakers & JSON schema validation
- **Notifications**: Web Push (VAPID) + Upstash QStash 5-min recurring scheduler
- **Storage**: Centralized Google Drive with user UUID isolation & quota management
- **Legal Data**: Pasal.id REST API proxy
