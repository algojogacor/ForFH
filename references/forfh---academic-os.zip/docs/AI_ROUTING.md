# AI Routing Strategy

## Slots Configuration
1. **Groq Slot 1**: `GROQ_API_KEY_1` -> `openai/gpt-oss-120b`
2. **Groq Slot 2**: `GROQ_API_KEY_2` -> `openai/gpt-oss-120b`
3. **Ollama Slot 1**: `OLLAMA_API_KEY_1` -> `gpt-oss:120b-cloud` (or `gpt-oss:120b`)
4. **Ollama Slot 2**: `OLLAMA_API_KEY_2` -> `gpt-oss:120b-cloud` (or `gpt-oss:120b`)
5. **Last Resort Model**: `minimax-m3` on Ollama Cloud

## Failover Policy
- Round-robin load balancing across healthy Groq slots.
- 429/5xx error places candidate slot in 60s cooldown.
- Automatic failover from Groq to Ollama Cloud.
- Structured JSON output validated using Zod with markdown fence removal.
- Non-AI app features remain 100% functional even during complete AI outage.
