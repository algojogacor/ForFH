# Environment Variables Reference

All secret environment variables are managed securely.

## Required Variables
- `NEXT_PUBLIC_APP_URL`: Base URL for the app
- `SESSION_SECRET`: Secret key for cookie session signing
- `PASSWORD_PEPPER`: Secret pepper for password scrypt hashing
- `TURSO_DATABASE_URL`: Turso / libSQL Database connection URL
- `TURSO_AUTH_TOKEN`: Turso Auth Token
- `GROQ_API_KEY_1`: Primary Groq API Key Slot 1
- `GROQ_API_KEY_2`: Secondary Groq API Key Slot 2
- `GROQ_MODEL`: Default Groq model identifier
- `OLLAMA_API_KEY_1`: Primary Ollama Cloud API Key Slot 1
- `OLLAMA_API_KEY_2`: Secondary Ollama Cloud API Key Slot 2
- `OLLAMA_MODEL`: Default Ollama model identifier
- `OLLAMA_LAST_RESORT_MODEL`: Fallback model identifier
- `PASAL_API_BASE_URL`: Base URL for Pasal.id REST API
- `PASAL_API_TOKEN`: Access token for Pasal.id API
- `QSTASH_URL`: Upstash QStash URL
- `QSTASH_TOKEN`: Upstash QStash Auth Token
- `QSTASH_CURRENT_SIGNING_KEY`: Current QStash signing key
- `QSTASH_NEXT_SIGNING_KEY`: Next QStash signing key
- `GOOGLE_DRIVE_CLIENT_ID`: Central Google Drive OAuth Client ID
- `GOOGLE_DRIVE_CLIENT_SECRET`: Central Google Drive OAuth Client Secret
- `GOOGLE_DRIVE_REFRESH_TOKEN`: Central Google Drive Refresh Token
- `GOOGLE_DRIVE_ROOT_FOLDER_ID`: Storage Root Folder ID on Google Drive
- `NEXT_PUBLIC_VAPID_PUBLIC_KEY`: Public key for Web Push
- `VAPID_PRIVATE_KEY`: Private key for Web Push
- `VAPID_SUBJECT`: Contact URI for Web Push
