# ForFH Project Plan

## Overview
ForFH is a real production-grade Academic Operating System / College OS for university students, optimized initially for Indonesian undergraduate law students.

## Implementation Phases
- [x] Phase A: Architecture, Database & Environment Foundation
- [ ] Phase B: Authentication, Sessions & User Isolation
- [ ] Phase C: Academic Terms, Courses & Schedule Engine
- [ ] Phase D: Task Management, Subtasks, Priorities & Progress
- [ ] Phase E: Dashboard ("Sekarang Aku Harus Ngapain?") & Calendar View
- [ ] Phase F: Quick Capture & Notes Management
- [ ] Phase G: Resilient AI Router (Groq Slot 1/2 -> Ollama Slot 1/2 -> MiniMax Fallback) & AI Parsing
- [ ] Phase H: Web Push Notifications & QStash Scheduler Processing
- [ ] Phase I: Centralized Google Drive Attachments & User Quota Management
- [ ] Phase J: PWA Manifest, Service Worker & Offline Sync Outbox
- [ ] Phase K: Legal Research Integration (Pasal.id API Proxy & Bookmarks)
- [ ] Phase L: Secondary Academic Modules (Reading Tracker, Exams, Attendance, GPA Simulator)
